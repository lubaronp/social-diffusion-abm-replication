# Article 2 — Experimento principal, T=120

Autorizado el 25 de septiembre de 2026 (America/Bogota). Modelo v0.1.0, reglas de la especificación v0.1 y horizonte T=120 seleccionado tras el piloto y su extensión temporal. El protocolo fechado está en main_v01_T120_plan.json.

400 ejecuciones: 100 repeticiones independientes, cada una evaluada en A–D con red, roles y sorteos comunes. Semillas nuevas, bloque 200000; no se incorporan observaciones del piloto. Todas las repeticiones se conservan, incluidas redes desconectadas y compras pendientes en T=120. Se auditan exportaciones y emparejamiento.

Gini entre los diez vendedores como indicador central; contrastes emparejados C−A y D−B. Comparaciones secundarias B−A, D−C e interacción. Se reportan cobertura, compras pendientes, compras en los últimos diez periodos, cuota del mayor vendedor y oportunidades de elección/proximidad. T=60 se conserva como diagnóstico dentro de las trayectorias del principal, sin agregar unidades independientes.

Intervalos percentiles de bootstrap sobre las 100 repeticiones completas, 10000 remuestreos y semilla 260926. Los mismos índices se usan en todos los escenarios y contrastes. Intervalos marginales sin ajuste por multiplicidad; describen incertidumbre Monte Carlo bajo reglas fijas, no incertidumbre empírica.

No se modifican reglas, no se calibra con datos reales y no se ejecutan sensibilidades adicionales de parámetros en esta etapa. La red comercial de estrellas es consecuencia estructural del modelo; el fenómeno analizado es la concentración de clientes.
