# Article 2 — Guía para interpretar el experimento principal

Ya están disponibles 400 simulaciones: 100 repeticiones por cuatro escenarios, con 120 periodos. El estudiante conserva el liderazgo de la interpretación y la escritura. Este material sirve para construir el argumento a partir de las reglas y los resultados.

## 1. Reconstruir la pregunta y las reglas

Explicar por qué se distinguen la red social, la difusión de información y los enlaces comerciales. Identificar qué cambia entre A–D y qué permanece común. Describir la compra única, los roles fijos, la actualización sincrónica y el uso de clientes del periodo anterior al elegir. El horizonte es abstracto: no llamarlo 120 meses.

Para métodos: usar la especificación v0.1, las decisiones de implementación v0.1.0 y la configuración principal T=120. Distinguir el piloto de 80 ejecuciones y su extensión temporal del principal de 400. La extensión del piloto no añade repeticiones independientes. Registrar las semillas y describir la ausencia de calibración real.

## 2. Explicar la concentración

Abrir `scenario_summary.csv` y la figura de concentración. Comparar media, mediana y dispersión del Gini; añadir la participación del vendedor mayor. Preguntarse si una media representa bien todas las repeticiones o si hay heterogeneidad. Los diez vendedores, incluidos los que tienen cero clientes, entran al Gini.

El Gini medio observado fue A=0,2934, B=0,2908, C=0,3662 y D=0,3635. Interpretar estas diferencias en términos de reparto de clientes, sin traducirlas automáticamente a ingresos o éxito de empresas reales.

## 3. Comparar mecanismos con pares

Usar `paired_contrast_summary.csv` para describir C−A y D−B: diferencias medias 0,0728 y 0,0727. Consultar `paired_gini_differences.csv` para conservar y discutir los casos inversos. No sustituir el emparejamiento por una prueba que trate A y C como muestras independientes. La unidad es la repetición completa, no cada consumidor ni cada periodo.

La pregunta interpretativa es: ¿cuánto agrega la preferencia explícita por éxito al proceso de recomendaciones que ya funciona en A? El escenario aleatorio también puede acumular ventaja mediante difusión. B−A, D−C e interacción son análisis secundarios; sus intervalos son marginales y no están ajustados por multiplicidad.

## 4. Leer la difusión y el horizonte

La cobertura media en T=120 fue 99,986 %; 93 de 100 repeticiones completaron las compras. Informar los casos restantes, sin descartarlos. Explicar por qué A–D tienen iguales tiempos de adopción: es una consecuencia de que las tasas de recomendación y compra no dependen del vendedor elegido.

Usar `horizon_contrasts.csv` para describir el cambio desde T=60 dentro de las mismas trayectorias. Los resultados corresponden al horizonte fijado; un periodo sin compras no prueba que el sistema haya terminado. Los percentiles 5–95 de las curvas expresan variación entre repeticiones, no incertidumbre de la media.

## 5. Acotar la interpretación de proximidad y redes

Consultar `mixed_proximity_share`: cuenta compras que realmente permiten elegir entre un vendedor directo y otro indirecto. Relacionar esta disponibilidad con los contrastes de proximidad. Evitar concluir que las relaciones sociales son irrelevantes, pues sostienen toda la difusión.

La forma comercial de estrellas está impuesta por una compra por consumidor y roles separados. El resultado a interpretar es cómo se distribuyen sus tamaños. No afirmar que se generó una red libre de escala, una estructura completa de mercadeo multinivel o una validación empírica de una teoría.

## 6. Orden sugerido para comenzar resultados

1. Describir las redes sociales y la cobertura, con la convención de distancias en el mayor componente.
2. Presentar la concentración por escenario y los contrastes emparejados principales.
3. Examinar heterogeneidad entre repeticiones y oportunidades reales de elección.
4. Incorporar el diagnóstico temporal y separar las sensibilidades de parámetros aún pendientes.

Cada párrafo debería contener un resultado concreto, su comparación relevante y una interpretación vinculada con una regla del modelo. Reservar para discusión qué podría sugerir el mecanismo en otros contextos, dejando clara la necesidad de evidencia adicional. Las tablas describen resultados computacionales bajo supuestos; no estiman un mercado real.
