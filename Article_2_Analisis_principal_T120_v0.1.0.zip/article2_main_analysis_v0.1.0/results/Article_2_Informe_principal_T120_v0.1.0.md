# Article 2 — Resultados del experimento principal

**Fecha:** 25 de septiembre de 2026, America/Bogota. **Modelo:** v0.1.0. **Especificación de reglas:** v0.1. **Horizonte principal:** 120 periodos. **Estado:** 400 simulaciones completadas y auditadas.

El experimento principal compara la concentración de clientes entre vendedores bajo cuatro reglas de elección, manteniendo iguales la red social y los sorteos dentro de cada repetición. Los contrastes medios de Gini fueron C−A=0,0728 y D−B=0,0727. La cobertura media al periodo 120 fue 99,986 %. Estos resultados corresponden a un experimento computacional teórico sin calibración ni validación predictiva con datos reales.

## Diseño ejecutado

Se realizaron 100 repeticiones independientes, cada una con cuatro escenarios: A, elección aleatoria entre vendedores conocidos; B, preferencia por contacto social directo; C, preferencia por éxito acumulado; y D, combinación de ambas. Por tanto, hay 400 ejecuciones y 100 unidades independientes para los contrastes emparejados. No se incorporaron resultados del piloto.

| Elemento | Configuración principal |
|---|---|
| Personas y roles | 500 personas: 10 vendedores fijos y 490 consumidores |
| Red social | Watts–Strogatz, k=6, p_WS=0,10; estática, simple y no dirigida |
| Comunicación de vendedores | q_s=0,25 por contacto y periodo |
| Recomendación de clientes | q_r=0,20 por contacto y periodo; desde el periodo posterior a la compra |
| Compra | a=0,10 por periodo para consumidores informados; una compra permanente |
| Proximidad activa | α=ln(2): peso doble para un contacto social directo |
| Éxito activo | β=1: peso proporcional a clientes previos + 1 |
| Horizonte | T=120, estados desde t=0; selección basada en el piloto temporal |
| Semillas | Bloque 200000, repeticiones 1–100, cinco fuentes por repetición |
| Referencias sociales | Diez grafos G(N,M) por red; 1000 referencias en total |

No se solapan las 500 semillas de las cinco etapas del principal con las del piloto. El protocolo local se registró antes de iniciar la ejecución en `main_v01_T120_plan.json`; no constituye un prerregistro externo. El código, las reglas y los restantes parámetros permanecieron congelados. Se conservaron todas las repeticiones, incluyendo cobertura incompleta. El periodo es una unidad abstracta.

## Auditoría y trazabilidad

Las 400 simulaciones completaron el horizonte. La auditoría independiente aprobó 4,944,540 comprobaciones de integridad, contabilidad, alternativas válidas, procedencia de recomendaciones y probabilidades. Esa cantidad cuenta comprobaciones de filas y reglas; no es un tamaño de muestra estadístico.

Las exportaciones incluyen 48,400 filas de sistema, 484,000 filas de vendedores, 195,972 compras y 280,117 alternativas. Hubo 0 ejecuciones sin adopción. Las 400 verificaciones de emparejamiento pasaron: conocimiento y compra coinciden por persona y periodo entre A–D. La auditoría de CSV también confirmó las series agregadas de difusión.

La huella del código es `81e7fa14ba2700a2d5faef4acaaa024cc0a4cc3f10a342b5f3e581e94d2b7d1d`. Las 33 pruebas unitarias corresponden a la verificación previa de esta misma versión; no se presentan como pruebas nuevas. Las versiones de software, las cinco semillas por repetición y los parámetros están en los manifiestos. Python 3.12.14; `random.Random` / MT19937. Inicio UTC: 2026-09-26T02:35:24.398170+00:00; fin UTC: 2026-09-26T02:39:28.386733+00:00.

## Concentración y contrastes

El Gini se calcula entre los diez vendedores e incluye los vendedores con cero clientes. Se presenta sin normalización; su máximo posible con diez vendedores es 0,9. La cuota del mayor vendedor complementa el Gini. Las desviaciones estándar describen variación entre repeticiones.

| Escenario | Gini medio | DE | Mediana | Cuota media del mayor vendedor |
|---|---:|---:|---:|---:|
| A — Aleatorio | 0,2934 | 0,0759 | 0,2867 | 21,07 % |
| B — Proximidad | 0,2908 | 0,0729 | 0,2808 | 20,94 % |
| C — Éxito acumulado | 0,3662 | 0,0871 | 0,3512 | 25,04 % |
| D — Combinado | 0,3635 | 0,0885 | 0,3480 | 24,83 % |

Las diferencias se calculan dentro de cada repetición antes de resumirlas. C−A y D−B son los contrastes principales; los restantes son secundarios.

| Contraste | Diferencia media | IC bootstrap 95 % | Error Monte Carlo de la media | Pares + / 0 / − |
|---|---:|---:|---:|---:|
| C−A | 0,072776 | [0,067519; 0,078389] | 0,002840 | 100/0/0 |
| D−B | 0,072748 | [0,066928; 0,078891] | 0,003102 | 100/0/0 |
| B−A | -0,002666 | [-0,005629; -0,000045] | 0,001437 | 25/29/46 |
| D−C | -0,002693 | [-0,005639; -0,000196] | 0,001419 | 20/38/42 |
| (D−B)−(C−A) | -0,000028 | [-0,003454; 0,003349] | 0,001742 | 48/14/38 |

Se utilizaron 10000 remuestreos de las 100 repeticiones completas, con semilla 260926 y los mismos índices para todos los contrastes. Los intervalos son percentiles marginales del 95 %, sin ajuste por multiplicidad. Describen incertidumbre Monte Carlo bajo esta configuración, no incertidumbre sobre una población comercial observada. Los consumidores, vendedores y periodos de una ejecución no se consideran repeticiones independientes.

C−A fue positivo en 100 repeticiones y negativo en 0; D−B fue positivo en 100 y negativo en 0. Los resultados inversos y nulos se conservan en las tablas. A ya incorpora refuerzo mediante recomendaciones; C−A estima el aporte adicional de la preferencia explícita por éxito acumulado, no la presencia frente a la ausencia absoluta de ventaja acumulativa.

Los contrastes secundarios de proximidad muestran disminuciones medias pequeñas: B−A=-0,002666 y D−C=-0,002693. El extremo superior del intervalo marginal de B−A queda muy cerca de cero; no conviene convertir ese límite en una conclusión fuerte sobre la importancia de la proximidad. La interacción media es cercana a cero y su intervalo incluye ambos signos. Estas comparaciones requieren la cautela propia de los análisis secundarios y de la escasa disponibilidad de opciones directas e indirectas.

## Cobertura y horizonte

La difusión idéntica A–D es una propiedad de las reglas y del emparejamiento: la identidad del vendedor no altera las probabilidades de compra ni de recomendación. Los indicadores siguientes se cuentan una vez por repetición.

| Indicador | Resultado entre 100 repeticiones |
|---|---:|
| Cobertura media T=60 | 96,941 % |
| Cobertura media T=120 | 99,986 % |
| Cobertura mínima T=120 | 99,796 % |
| Consumidores pendientes, media T=120 | 0,07 |
| Cobertura completa en T=120 | 93/100 |
| Sin compras en los últimos diez periodos | 97/100 |
| Compras en los últimos diez periodos, media | 0,03 |
| Sin compras en el periodo 120 | 100/100 |
| Mediana del tiempo hasta 90 % de cobertura | 48,5 periodos |

Repeticiones con cobertura incompleta: 12 (1 pendiente), 17 (1 pendiente), 26 (1 pendiente), 34 (1 pendiente), 46 (1 pendiente), 85 (1 pendiente), 90 (1 pendiente). Entre las 93 que alcanzaron cobertura completa, el tiempo estuvo entre 67 y 118 periodos. Este rango está condicionado a completar las compras. Un periodo sin nuevas compras no basta para afirmar absorción; el resultado principal es una comparación al horizonte fijo de 120 periodos.

Como diagnóstico dentro del principal, C−A pasó de 0,0683 en T=60 a 0,0728 en T=120; D−B pasó de 0,0682 a 0,0727. Ambos horizontes proceden de las mismas trayectorias y no agregan unidades independientes. La tabla `horizon_contrasts.csv` conserva los cambios por repetición.

## Oportunidades de elección y proximidad

Para que la proximidad modifique probabilidades, el comprador debe conocer simultáneamente un vendedor directo y otro indirecto. Para que el éxito diferencie alternativas, estas deben tener distintos números de clientes previos. Las proporciones se calculan por repetición y luego se promedian.

| Escenario | Compras con ≥2 candidatos | Opciones directas e indirectas | Candidatos con distinto éxito previo |
|---|---:|---:|---:|
| A | 33,31 % | 1,52 % | 32,74 % |
| B | 33,33 % | 1,51 % | 32,76 % |
| C | 33,09 % | 1,53 % | 32,60 % |
| D | 33,08 % | 1,52 % | 32,58 % |

La tabla permite interpretar cuánto espacio efectivo tienen las reglas de elección. Un efecto pequeño de proximidad no demuestra que los vínculos sociales carezcan de importancia: toda la difusión usa esos vínculos. El contraste B−A representa una preferencia por el contacto directo cuando existen alternativas indirectas conocidas. No se cambiaron las reglas para aumentar ese efecto.

## Diagnósticos de la red social

De las 100 redes sociales, 100 fueron conexas. El agrupamiento medio fue 0,4445, frente a 0,0119 en las referencias. La distancia media en el mayor componente fue 5,423, frente a 3,663. Los cocientes medios emparejados fueron 37,49 para agrupamiento y 1,48 para distancia.

La menor proporción de nodos del mayor componente en las referencias fue 98,80 %. Las distancias se interpretan con esta convención; las redes desconectadas no fueron descartadas. Estos diagnósticos documentan la estructura social y sus referencias, sin aplicar automáticamente una etiqueta distributiva a la red comercial.

## Alcance y siguiente etapa

La red comercial es un conjunto de estrellas alrededor de vendedores por las reglas de roles separados y una compra por consumidor. La distribución del tamaño de esas estrellas y la concentración son resultados simulados. Diez vendedores no sostienen una conclusión sobre redes libres de escala. No se simulan ingresos, comisiones multinivel, satisfacción, capacidad limitada, cambio de vendedor ni comportamiento calibrado de una empresa real.

El experimento principal está completo. El estudiante puede comenzar resultados y discusión con las tablas y figuras, manteniendo las conclusiones condicionadas a los supuestos. La robustez frente a otros parámetros permanece pendiente: la especificación propone variar, de forma acotada, estructura social, recomendación, intensidad de éxito, número de vendedores y probabilidad de compra. La sensibilidad temporal ya se evaluó; no debe confundirse con esas sensibilidades adicionales.

## Archivos entregados

- `Article_2_Datos_principal_T120_v0.1.0.zip`: configuración, protocolo previo, resultados crudos y auditoría.
- `Article_2_Analisis_principal_T120_v0.1.0.zip`: scripts, tablas, resumen JSON, informe, guía y figuras PNG/SVG.
- `Article_2_Figuras_principal_T120_v0.1.0.zip`: las dos figuras en PNG y SVG, con notas de lectura.

La figura de concentración combina la distribución entre repeticiones y los intervalos de diferencias emparejadas. La figura dinámica muestra la cobertura común, el Gini medio y las oportunidades de elección. La banda percentil de cobertura representa dispersión entre repeticiones; no es un intervalo de confianza. Las cajas del Gini muestran cuartiles, mediana y bigotes de 1,5 veces el rango intercuartílico; los puntos incluyen todas las repeticiones.
