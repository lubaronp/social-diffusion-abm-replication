"""Generate the main experiment report and student guide from computed summaries."""
import csv
import hashlib
import json
from pathlib import Path
import sys


def build(out):
    s=json.loads((out/'main_summary.json').read_text())
    def f(v,d=4):
        return 'NA' if v is None else f'{v:.{d}f}'.replace('.',',')
    def m(sc,key):
        return s['scenarios'][sc][key]
    contrasts={r['contrast']:r for r in s['paired_contrasts']}
    gini_rows=[]
    for sc,label in [('A','Aleatorio'),('B','Proximidad'),('C','Éxito acumulado'),('D','Combinado')]:
        g=m(sc,'gini_final')
        gini_rows.append(f"| {sc} — {label} | {f(g['mean'])} | {f(g['sd'])} | {f(g['median'])} | {f(100*m(sc,'largest_share_final')['mean'],2)} % |")
    gini_table='\n'.join(gini_rows)
    contrast_rows=[]
    for key,label in [('C_minus_A','C−A'),('D_minus_B','D−B'),('B_minus_A','B−A'),('D_minus_C','D−C'),('interaction','(D−B)−(C−A)')]:
        r=contrasts[key]
        contrast_rows.append(f"| {label} | {f(r['mean'],6)} | [{f(r['bootstrap_ci95_low'],6)}; {f(r['bootstrap_ci95_high'],6)}] | {f(r['monte_carlo_se'],6)} | {r['positive_pairs']}/{r['zero_pairs']}/{r['negative_pairs']} |")
    contrast_table='\n'.join(contrast_rows)
    opportunity_rows=[]
    for sc in 'ABCD':
        opportunity_rows.append(f"| {sc} | {f(100*m(sc,'multi_choice_share')['mean'],2)} % | {f(100*m(sc,'mixed_proximity_share')['mean'],2)} % | {f(100*m(sc,'varied_success_share')['mean'],2)} % |")
    opportunity_table='\n'.join(opportunity_rows)
    sat=s['saturation']; nets=s['networks']; c,d=contrasts['C_minus_A'],contrasts['D_minus_B']
    incomplete=', '.join(f"{r['replicate_id']} ({r['remaining']} pendiente{'s' if r['remaining']!=1 else ''})" for r in sat['incomplete_replicates']) or 'ninguna'
    full=sat['full_adoption_periods_conditional']
    with (out/'network_diagnostics_summary.csv').open() as handle:
        network_rows=list(csv.DictReader(handle))
    connected=sum(float(r['social_lcc_share'])==1 for r in network_rows)
    report=f'''# Article 2 — Resultados del experimento principal

**Fecha:** 25 de septiembre de 2026, America/Bogota. **Modelo:** v0.1.0. **Especificación de reglas:** v0.1. **Horizonte principal:** 120 periodos. **Estado:** 400 simulaciones completadas y auditadas.

El experimento principal compara la concentración de clientes entre vendedores bajo cuatro reglas de elección, manteniendo iguales la red social y los sorteos dentro de cada repetición. Los contrastes medios de Gini fueron C−A={f(c['mean'])} y D−B={f(d['mean'])}. La cobertura media al periodo 120 fue {f(100*m('A','coverage_final')['mean'],3)} %. Estos resultados corresponden a un experimento computacional teórico sin calibración ni validación predictiva con datos reales.

## Diseño ejecutado

Se realizaron 100 repeticiones independientes, cada una con cuatro escenarios: A, elección aleatoria entre vendedores conocidos; B, preferencia por contacto social directo; C, preferencia por éxito acumulado; y D, combinación de ambas. Por tanto, hay 400 ejecuciones y 100 unidades independientes para los contrastes emparejados. No se incorporaron resultados del piloto.

| Elemento | Configuración principal |
|---|---|
| Personas y roles | 500 personas: 10 vendedores fijos y 490 consumidores |
| Red social | Watts–Strogatz, k=6, p_WS=0,10; estática, simple y no dirigida |
| Comunicación de vendedores | q_s=0,25 por contacto y periodo |
| Recomendación de clientes | q_r=0,20 por contacto y periodo; desde el periodo posterior a la compra |
| Compra | a=0,10 por periodo para consumidores informados; una compra permanente |
| Proximidad activa | α=ln(2): peso doble para un contacto social directo |
| Éxito activo | β=1: peso proporcional a clientes previos + 1 |
| Horizonte | T=120, estados desde t=0; selección basada en el piloto temporal |
| Semillas | Bloque 200000, repeticiones 1–100, cinco fuentes por repetición |
| Referencias sociales | Diez grafos G(N,M) por red; 1000 referencias en total |

No se solapan las 500 semillas de las cinco etapas del principal con las del piloto. El protocolo local se registró antes de iniciar la ejecución en `main_v01_T120_plan.json`; no constituye un prerregistro externo. El código, las reglas y los restantes parámetros permanecieron congelados. Se conservaron todas las repeticiones, incluyendo cobertura incompleta. El periodo es una unidad abstracta.

## Auditoría y trazabilidad

Las 400 simulaciones completaron el horizonte. La auditoría independiente aprobó {s['audit']['assertions_passed']:,} comprobaciones de integridad, contabilidad, alternativas válidas, procedencia de recomendaciones y probabilidades. Esa cantidad cuenta comprobaciones de filas y reglas; no es un tamaño de muestra estadístico.

Las exportaciones incluyen {s['audit']['system_rows']:,} filas de sistema, {s['audit']['seller_rows']:,} filas de vendedores, {s['audit']['commercial_rows']:,} compras y {s['audit']['candidate_rows']:,} alternativas. Hubo {s['no_adoption_runs']} ejecuciones sin adopción. Las 400 verificaciones de emparejamiento pasaron: conocimiento y compra coinciden por persona y periodo entre A–D. La auditoría de CSV también confirmó las series agregadas de difusión.

La huella del código es `{s['code_sha256']}`. Las 33 pruebas unitarias corresponden a la verificación previa de esta misma versión; no se presentan como pruebas nuevas. Las versiones de software, las cinco semillas por repetición y los parámetros están en los manifiestos. Python 3.12.14; `random.Random` / MT19937. Inicio UTC: {s['started_utc']}; fin UTC: {s['finished_utc']}.

## Concentración y contrastes

El Gini se calcula entre los diez vendedores e incluye los vendedores con cero clientes. Se presenta sin normalización; su máximo posible con diez vendedores es 0,9. La cuota del mayor vendedor complementa el Gini. Las desviaciones estándar describen variación entre repeticiones.

| Escenario | Gini medio | DE | Mediana | Cuota media del mayor vendedor |
|---|---:|---:|---:|---:|
{gini_table}

Las diferencias se calculan dentro de cada repetición antes de resumirlas. C−A y D−B son los contrastes principales; los restantes son secundarios.

| Contraste | Diferencia media | IC bootstrap 95 % | Error Monte Carlo de la media | Pares + / 0 / − |
|---|---:|---:|---:|---:|
{contrast_table}

Se utilizaron 10000 remuestreos de las 100 repeticiones completas, con semilla 260926 y los mismos índices para todos los contrastes. Los intervalos son percentiles marginales del 95 %, sin ajuste por multiplicidad. Describen incertidumbre Monte Carlo bajo esta configuración, no incertidumbre sobre una población comercial observada. Los consumidores, vendedores y periodos de una ejecución no se consideran repeticiones independientes.

C−A fue positivo en {c['positive_pairs']} repeticiones y negativo en {c['negative_pairs']}; D−B fue positivo en {d['positive_pairs']} y negativo en {d['negative_pairs']}. Los resultados inversos y nulos se conservan en las tablas. A ya incorpora refuerzo mediante recomendaciones; C−A estima el aporte adicional de la preferencia explícita por éxito acumulado, no la presencia frente a la ausencia absoluta de ventaja acumulativa.

Los contrastes secundarios de proximidad muestran disminuciones medias pequeñas: B−A={f(contrasts['B_minus_A']['mean'],6)} y D−C={f(contrasts['D_minus_C']['mean'],6)}. El extremo superior del intervalo marginal de B−A queda muy cerca de cero; no conviene convertir ese límite en una conclusión fuerte sobre la importancia de la proximidad. La interacción media es cercana a cero y su intervalo incluye ambos signos. Estas comparaciones requieren la cautela propia de los análisis secundarios y de la escasa disponibilidad de opciones directas e indirectas.

## Cobertura y horizonte

La difusión idéntica A–D es una propiedad de las reglas y del emparejamiento: la identidad del vendedor no altera las probabilidades de compra ni de recomendación. Los indicadores siguientes se cuentan una vez por repetición.

| Indicador | Resultado entre 100 repeticiones |
|---|---:|
| Cobertura media T=60 | {f(100*m('A','coverage_T60')['mean'],3)} % |
| Cobertura media T=120 | {f(100*m('A','coverage_final')['mean'],3)} % |
| Cobertura mínima T=120 | {f(100*m('A','coverage_final')['min'],3)} % |
| Consumidores pendientes, media T=120 | {f(m('A','remaining_consumers')['mean'],2)} |
| Cobertura completa en T=120 | {sat['full_adoption_replicates']}/100 |
| Sin compras en los últimos diez periodos | {sat['no_acquisitions_last10']}/100 |
| Compras en los últimos diez periodos, media | {f(m('A','new_customers_last10')['mean'],2)} |
| Sin compras en el periodo 120 | {s['diffusion_A_only']['zero_new_in_last_period']}/100 |
| Mediana del tiempo hasta 90 % de cobertura | {f(m('A','t90')['median'],1)} periodos |

Repeticiones con cobertura incompleta: {incomplete}. Entre las {full['n']} que alcanzaron cobertura completa, el tiempo estuvo entre {f(full['min'],0)} y {f(full['max'],0)} periodos. Este rango está condicionado a completar las compras. Un periodo sin nuevas compras no basta para afirmar absorción; el resultado principal es una comparación al horizonte fijo de 120 periodos.

Como diagnóstico dentro del principal, C−A pasó de {f(s['horizon_diagnostic']['C_minus_A']['T60']['mean'])} en T=60 a {f(c['mean'])} en T=120; D−B pasó de {f(s['horizon_diagnostic']['D_minus_B']['T60']['mean'])} a {f(d['mean'])}. Ambos horizontes proceden de las mismas trayectorias y no agregan unidades independientes. La tabla `horizon_contrasts.csv` conserva los cambios por repetición.

## Oportunidades de elección y proximidad

Para que la proximidad modifique probabilidades, el comprador debe conocer simultáneamente un vendedor directo y otro indirecto. Para que el éxito diferencie alternativas, estas deben tener distintos números de clientes previos. Las proporciones se calculan por repetición y luego se promedian.

| Escenario | Compras con ≥2 candidatos | Opciones directas e indirectas | Candidatos con distinto éxito previo |
|---|---:|---:|---:|
{opportunity_table}

La tabla permite interpretar cuánto espacio efectivo tienen las reglas de elección. Un efecto pequeño de proximidad no demuestra que los vínculos sociales carezcan de importancia: toda la difusión usa esos vínculos. El contraste B−A representa una preferencia por el contacto directo cuando existen alternativas indirectas conocidas. No se cambiaron las reglas para aumentar ese efecto.

## Diagnósticos de la red social

De las 100 redes sociales, {connected} fueron conexas. El agrupamiento medio fue {f(nets['social_clustering']['mean'])}, frente a {f(nets['reference_clustering_mean']['mean'])} en las referencias. La distancia media en el mayor componente fue {f(nets['social_path_lcc']['mean'],3)}, frente a {f(nets['reference_path_lcc_mean']['mean'],3)}. Los cocientes medios emparejados fueron {f(nets['clustering_ratio']['mean'],2)} para agrupamiento y {f(nets['path_ratio']['mean'],2)} para distancia.

La menor proporción de nodos del mayor componente en las referencias fue {f(100*nets['reference_min_lcc_share']['min'],2)} %. Las distancias se interpretan con esta convención; las redes desconectadas no fueron descartadas. Estos diagnósticos documentan la estructura social y sus referencias, sin aplicar automáticamente una etiqueta distributiva a la red comercial.

## Alcance y siguiente etapa

La red comercial es un conjunto de estrellas alrededor de vendedores por las reglas de roles separados y una compra por consumidor. La distribución del tamaño de esas estrellas y la concentración son resultados simulados. Diez vendedores no sostienen una conclusión sobre redes libres de escala. No se simulan ingresos, comisiones multinivel, satisfacción, capacidad limitada, cambio de vendedor ni comportamiento calibrado de una empresa real.

El experimento principal está completo. El estudiante puede comenzar resultados y discusión con las tablas y figuras, manteniendo las conclusiones condicionadas a los supuestos. La robustez frente a otros parámetros permanece pendiente: la especificación propone variar, de forma acotada, estructura social, recomendación, intensidad de éxito, número de vendedores y probabilidad de compra. La sensibilidad temporal ya se evaluó; no debe confundirse con esas sensibilidades adicionales.

## Archivos entregados

- `Article_2_Datos_principal_T120_v0.1.0.zip`: configuración, protocolo previo, resultados crudos y auditoría.
- `Article_2_Analisis_principal_T120_v0.1.0.zip`: scripts, tablas, resumen JSON, informe, guía y figuras PNG/SVG.
- `Article_2_Figuras_principal_T120_v0.1.0.zip`: las dos figuras en PNG y SVG, con notas de lectura.

La figura de concentración combina la distribución entre repeticiones y los intervalos de diferencias emparejadas. La figura dinámica muestra la cobertura común, el Gini medio y las oportunidades de elección. La banda percentil de cobertura representa dispersión entre repeticiones; no es un intervalo de confianza. Las cajas del Gini muestran cuartiles, mediana y bigotes de 1,5 veces el rango intercuartílico; los puntos incluyen todas las repeticiones.
'''
    (out/'Article_2_Informe_principal_T120_v0.1.0.md').write_text(report,encoding='utf-8')
    guide=f'''# Article 2 — Guía para interpretar el experimento principal

Ya están disponibles 400 simulaciones: 100 repeticiones por cuatro escenarios, con 120 periodos. El estudiante conserva el liderazgo de la interpretación y la escritura. Este material sirve para construir el argumento a partir de las reglas y los resultados.

## 1. Reconstruir la pregunta y las reglas

Explicar por qué se distinguen la red social, la difusión de información y los enlaces comerciales. Identificar qué cambia entre A–D y qué permanece común. Describir la compra única, los roles fijos, la actualización sincrónica y el uso de clientes del periodo anterior al elegir. El horizonte es abstracto: no llamarlo 120 meses.

Para métodos: usar la especificación v0.1, las decisiones de implementación v0.1.0 y la configuración principal T=120. Distinguir el piloto de 80 ejecuciones y su extensión temporal del principal de 400. La extensión del piloto no añade repeticiones independientes. Registrar las semillas y describir la ausencia de calibración real.

## 2. Explicar la concentración

Abrir `scenario_summary.csv` y la figura de concentración. Comparar media, mediana y dispersión del Gini; añadir la participación del vendedor mayor. Preguntarse si una media representa bien todas las repeticiones o si hay heterogeneidad. Los diez vendedores, incluidos los que tienen cero clientes, entran al Gini.

El Gini medio observado fue A={f(m('A','gini_final')['mean'])}, B={f(m('B','gini_final')['mean'])}, C={f(m('C','gini_final')['mean'])} y D={f(m('D','gini_final')['mean'])}. Interpretar estas diferencias en términos de reparto de clientes, sin traducirlas automáticamente a ingresos o éxito de empresas reales.

## 3. Comparar mecanismos con pares

Usar `paired_contrast_summary.csv` para describir C−A y D−B: diferencias medias {f(c['mean'])} y {f(d['mean'])}. Consultar `paired_gini_differences.csv` para conservar y discutir los casos inversos. No sustituir el emparejamiento por una prueba que trate A y C como muestras independientes. La unidad es la repetición completa, no cada consumidor ni cada periodo.

La pregunta interpretativa es: ¿cuánto agrega la preferencia explícita por éxito al proceso de recomendaciones que ya funciona en A? El escenario aleatorio también puede acumular ventaja mediante difusión. B−A, D−C e interacción son análisis secundarios; sus intervalos son marginales y no están ajustados por multiplicidad.

## 4. Leer la difusión y el horizonte

La cobertura media en T=120 fue {f(100*m('A','coverage_final')['mean'],3)} %; {sat['full_adoption_replicates']} de 100 repeticiones completaron las compras. Informar los casos restantes, sin descartarlos. Explicar por qué A–D tienen iguales tiempos de adopción: es una consecuencia de que las tasas de recomendación y compra no dependen del vendedor elegido.

Usar `horizon_contrasts.csv` para describir el cambio desde T=60 dentro de las mismas trayectorias. Los resultados corresponden al horizonte fijado; un periodo sin compras no prueba que el sistema haya terminado. Los percentiles 5–95 de las curvas expresan variación entre repeticiones, no incertidumbre de la media.

## 5. Acotar la interpretación de proximidad y redes

Consultar `mixed_proximity_share`: cuenta compras que realmente permiten elegir entre un vendedor directo y otro indirecto. Relacionar esta disponibilidad con los contrastes de proximidad. Evitar concluir que las relaciones sociales son irrelevantes, pues sostienen toda la difusión.

La forma comercial de estrellas está impuesta por una compra por consumidor y roles separados. El resultado a interpretar es cómo se distribuyen sus tamaños. No afirmar que se generó una red libre de escala, una estructura completa de mercadeo multinivel o una validación empírica de una teoría.

## 6. Orden sugerido para comenzar resultados

1. Describir las redes sociales y la cobertura, con la convención de distancias en el mayor componente.
2. Presentar la concentración por escenario y los contrastes emparejados principales.
3. Examinar heterogeneidad entre repeticiones y oportunidades reales de elección.
4. Incorporar el diagnóstico temporal y separar las sensibilidades de parámetros aún pendientes.

Cada párrafo debería contener un resultado concreto, su comparación relevante y una interpretación vinculada con una regla del modelo. Reservar para discusión qué podría sugerir el mecanismo en otros contextos, dejando clara la necesidad de evidencia adicional. Las tablas describen resultados computacionales bajo supuestos; no estiman un mercado real.
'''
    (out/'Article_2_Guia_estudiante_principal_v0.1.0.md').write_text(guide,encoding='utf-8')
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name!='analysis_checksums.json'}
    (out/'analysis_checksums.json').write_text(json.dumps(hashes,indent=2)+'\n')


if __name__=='__main__':
    build(Path(sys.argv[1]))
