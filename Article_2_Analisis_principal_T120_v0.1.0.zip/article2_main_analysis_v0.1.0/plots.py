"""Static scientific figures; all points represent complete simulation replicates."""
import statistics as st


def make_plot(out, runs, temporal, contrasts):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    scenarios=('A','B','C','D')
    colors=dict(A='#345779',B='#138985',C='#D27B30',D='#8555A0')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axes=plt.subplots(1,2,figsize=(12.4,5.2),layout='constrained')
    for x,s in enumerate(scenarios):
        rs=sorted([r for r in runs if r['scenario']==s],key=lambda r:r['replicate_id'])
        vals=[r['gini_final'] for r in rs]
        axes[0].boxplot([vals],positions=[x],widths=.46,showfliers=False,patch_artist=True,
            boxprops={'facecolor':colors[s],'alpha':.22},medianprops={'color':colors[s],'linewidth':2},
            whiskerprops={'color':colors[s]},capprops={'color':colors[s]})
        offsets=[(((r['replicate_id']*37)%101)/100-.5)*.35 for r in rs]
        axes[0].scatter([x+o for o in offsets],vals,s=13,color=colors[s],alpha=.50,zorder=3)
        axes[0].scatter([x],[st.mean(vals)],marker='D',s=40,color='#172535',zorder=4)
    axes[0].set(title='Concentración por escenario',xticks=range(4),xticklabels=scenarios,ylabel='Gini de clientes en T=120',ylim=(0,.9))
    axes[0].text(.02,.97,'Puntos: 100 repeticiones por escenario\nRombo: media · Línea de caja: mediana',transform=axes[0].transAxes,va='top',fontsize=8,color='#45515C')
    keys=['C_minus_A','D_minus_B','B_minus_A','D_minus_C','interaction']
    labels=['C−A: éxito','D−B: éxito con proximidad','B−A: proximidad','D−C: proximidad con éxito','Interacción']
    for i,k in enumerate(keys):
        r=next(r for r in contrasts if r['contrast']==k)
        mean,lo,hi=r['mean'],r['bootstrap_ci95_low'],r['bootstrap_ci95_high']
        col='#345779' if i<2 else '#7F8993'
        axes[1].plot([lo,hi],[i,i],color=col,lw=3)
        axes[1].scatter([mean],[i],color=col,s=40,zorder=3)
    axes[1].axvline(0,color='#888888',ls='--',lw=1)
    axes[1].set(title='Diferencias emparejadas',yticks=range(5),yticklabels=labels,xlabel='Diferencia media de Gini e IC 95 % bootstrap')
    axes[1].invert_yaxis()
    axes[1].grid(axis='x',alpha=.17)
    axes[0].grid(axis='y',alpha=.17)
    for ax in axes: ax.set_axisbelow(True)
    fig.suptitle('Article 2 · Experimento principal: 400 simulaciones',fontsize=15,fontweight='bold')
    fig.supxlabel('100 repeticiones emparejadas · Intervalos marginales, sin ajuste por multiplicidad · Evidencia simulada',fontsize=9)
    save(fig,out,'Article_2_Principal_concentracion_v0.1.0')
    plt.close(fig)

    fig,axes=plt.subplots(1,3,figsize=(14.5,4.8),layout='constrained')
    rows=[r for r in temporal if r['scenario']=='A' and r['metric']=='coverage']
    axes[0].fill_between([r['period'] for r in rows],[100*r['p05'] for r in rows],[100*r['p95'] for r in rows],color='#D6E7F1',label='Percentiles 5–95')
    axes[0].plot([r['period'] for r in rows],[100*r['mean'] for r in rows],color=colors['A'],lw=2,label='Media común a A–D')
    axes[0].set(title='Cobertura',xlabel='Periodo abstracto',ylabel='Consumidores que compraron (%)',xlim=(0,120),ylim=(0,103))
    axes[0].legend(loc='lower right',frameon=False,fontsize=8)
    for s in scenarios:
        rows=[r for r in temporal if r['scenario']==s and r['metric']=='customer_gini']
        axes[1].plot([r['period'] for r in rows],[r['mean'] for r in rows],color=colors[s],lw=2,label=s)
    axes[1].set(title='Concentración media',xlabel='Periodo abstracto',ylabel='Gini entre los 10 vendedores',xlim=(0,120),ylim=(0,.9))
    axes[1].legend(frameon=False,ncol=2,fontsize=9)
    for x,s in enumerate(scenarios):
        rs=[r for r in runs if r['scenario']==s]
        multi=100*st.mean(r['multi_choice_share'] for r in rs)
        mixed=100*st.mean(r['mixed_proximity_share'] for r in rs)
        axes[2].bar(x-.17,multi,width=.3,color='#345779',label='≥2 candidatos' if x==0 else None)
        axes[2].bar(x+.17,mixed,width=.3,color='#D27B30',label='Directo e indirecto disponibles' if x==0 else None)
        axes[2].text(x-.17,multi+.5,f'{multi:.1f}',ha='center',fontsize=8)
        axes[2].text(x+.17,mixed+.5,f'{mixed:.1f}',ha='center',fontsize=8)
    axes[2].set(title='Oportunidades de elección en T=120',xticks=range(4),xticklabels=scenarios,ylabel='Compras (%), media entre repeticiones',ylim=(0,42))
    axes[2].legend(frameon=False,fontsize=8,loc='upper left')
    for ax in axes[:2]: ax.axvline(60,color='#929BA4',ls='--',lw=1)
    for ax in axes:
        ax.grid(axis='y',alpha=.17)
        ax.set_axisbelow(True)
    fig.suptitle('Article 2 · Dinámica y disponibilidad de alternativas',fontsize=15,fontweight='bold')
    fig.supxlabel('A: aleatorio · B: proximidad · C: éxito acumulado · D: combinado | La banda de cobertura muestra dispersión entre repeticiones',fontsize=9)
    save(fig,out,'Article_2_Principal_dinamica_v0.1.0')
    plt.close(fig)


def save(fig,out,name):
    fig.savefig(out/(name+'.png'),dpi=180)
    fig.savefig(out/(name+'.svg'))
