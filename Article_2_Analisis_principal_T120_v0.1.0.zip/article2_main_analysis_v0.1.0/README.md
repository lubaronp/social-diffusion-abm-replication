# Article 2 — Análisis del experimento principal, v0.1.0

400 simulaciones, 100 repeticiones emparejadas de los escenarios A–D, T=120. Bloque nuevo 200000; sin datos del piloto. El código del modelo conserva la versión v0.1.0 y el horizonte se fija tras la sensibilidad temporal del piloto.

## Reproducción

Extraer en la misma carpeta `Article_2_Codigo_v0.1.0.zip`, `Article_2_Datos_principal_T120_v0.1.0.zip` y este paquete de análisis. La simulación usa exclusivamente la biblioteca estándar de Python 3.12.14. Para las figuras, matplotlib 3.10.8.

Desde `article2_model_v0.1.0`, para repetir el experimento en un destino nuevo:

```bash
python3 -m article2 --config configs/main_v01_T120.json --out outputs/main_reproduced --phase main --repetitions 100 --block 200000 --config-id main_v01_T120 --benchmarks 10
python3 audit_outputs.py outputs/main_reproduced --report outputs/main_reproduced_audit.json
```

Desde la carpeta que contiene los proyectos, para analizar los datos archivados:

```bash
python3 article2_main_analysis_v0.1.0/analyze_main.py --raw article2_model_v0.1.0/outputs/main_v01_T120 --audit article2_model_v0.1.0/outputs/main_v01_T120_audit.json --out article2_main_analysis_v0.1.0/results_reproduced
python3 article2_main_analysis_v0.1.0/build_report.py article2_main_analysis_v0.1.0/results_reproduced
```

Los directorios de resultados deben ser nuevos. Ajustar `--raw` y `--audit` si se utiliza la ejecución reproducida. El modelo y su auditor independiente están en el paquete de código original. `analyze_main.py` adapta el análisis ya utilizado en el piloto; no modifica el simulador.

## Tablas y definiciones

- `run_diagnostics.csv`: 400 filas; una por ejecución. El Gini y las participaciones son NA cuando no hay adopción. `t100` es NA cuando no se alcanza cobertura completa antes de T=120. Los tiempos hasta umbrales se interpretan condicionados a alcanzarlos y se acompaña su frecuencia.
- `scenario_summary.csv`: medias, desviaciones estándar muestrales, mediana, extremos y percentiles 5–95 entre las 100 repeticiones. No confundir la desviación entre repeticiones con el error Monte Carlo de la media.
- `paired_gini_differences.csv`: 100 filas, una por repetición, con C−A, D−B, B−A, D−C e interacción.
- `paired_contrast_summary.csv`: resúmenes de diferencias, signos, error Monte Carlo y bootstrap percentil del 95 %. La columna `normal_ci95_halfwidth` es una aproximación normal de precisión, no el intervalo bootstrap.
- `network_diagnostics_summary.csv`: una fila por red social; comparación con diez grafos G(N,M). Las distancias se miden en el mayor componente; registrar el tamaño de este componente al interpretar los cocientes.
- `choice_set_distribution.csv`: distribución agrupada de alternativas por compra. `pooled_share` pondera por número de compras; las proporciones medias de `scenario_summary.csv` ponderan por igual cada repetición.
- `temporal_summary.csv`: trayectorias y dispersión entre repeticiones. Las bandas percentiles no son intervalos de confianza. Cuando el Gini aún no está definido, `n` indica cuántas repeticiones contribuyen a la media.
- `horizon_contrasts.csv`: comparación T60/T120 dentro de las mismas trayectorias principales, como diagnóstico temporal. No añade repeticiones independientes.
- `seller_final_counts.csv`: clientes de los diez vendedores en cada ejecución, incluidos ceros. No se deben tratar los 4000 vendedores como unidades independientes.
- `main_summary.json`: resumen estructurado, cobertura incompleta, auditoría y trazabilidad.
- Informe, guía del estudiante y dos figuras en PNG/SVG.
- `analysis_checksums.json`: integridad de los resultados, incluido el informe y la guía. `CODE_SHA256SUMS.json`: integridad de los scripts y README de este paquete.

## Estadística y alcance

10000 remuestreos de las 100 repeticiones completas, semilla 260926. Se conservan juntos A–D en cada remuestreo y se usan los mismos índices para todos los contrastes. Intervalos marginales del 95 %, sin ajuste por comparaciones múltiples; principales C−A y D−B, secundarios B−A, D−C e interacción. La precisión describe aleatoriedad del experimento computacional bajo los supuestos fijados, no incertidumbre sobre un mercado real.

No se han ejecutado aquí las sensibilidades adicionales de parámetros. La red comercial de estrellas procede de las reglas; la concentración y el reparto de clientes son las salidas que se interpretan.
