"""Main experiment diagnostics: paired simulation units, no empirical calibration.

Uses Python standard library for tables/statistics and matplotlib for figures.
"""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import statistics as stats


SCENARIOS = {"A": "Aleatorio", "B": "Proximidad", "C": "Éxito acumulado", "D": "Combinado"}


def read_csv(path):
    with Path(path).open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows):
    if not rows:
        raise ValueError("No rows to export")
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]),lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({k:"NA" if v is None else v for k,v in row.items()})


def percentile(values,p):
    values=sorted(values)
    position=(len(values)-1)*p
    lo=math.floor(position)
    hi=math.ceil(position)
    return values[lo]+(values[hi]-values[lo])*(position-lo)


def describe(values):
    values=[v for v in values if v is not None]
    if not values:
        return {"n":0,"mean":None,"sd":None,"median":None,"min":None,"max":None,"p05":None,"p95":None}
    return {"n":len(values),"mean":stats.mean(values),"sd":stats.stdev(values) if len(values)>1 else 0,
            "median":stats.median(values),"min":min(values),"max":max(values),
            "p05":percentile(values,.05),"p95":percentile(values,.95)}


def analyze(raw,out,audit_path,bootstrap_seed=260926,b=10000):
    raw,out=Path(raw),Path(out)
    out.mkdir(parents=True,exist_ok=False)
    execution=json.loads((raw/"execution.json").read_text())
    audit=json.loads(Path(audit_path).read_text())
    if not (execution["phase"]=="main" and execution["status"]=="completed"
            and audit["status"]=="passed" and audit["runs"]==400):
        raise ValueError("Expected audited, completed 400-run main experiment")
    assert execution["parameters"]["T"]==120 and execution["random_block_id"]==200000
    assert execution["code_sha256"]=="81e7fa14ba2700a2d5faef4acaaa024cc0a4cc3f10a342b5f3e581e94d2b7d1d"
    manifest=read_csv(raw/"experiment_manifest.csv")
    assert {(int(m["replicate_id"]),m["scenario"]) for m in manifest}=={(r,s) for r in range(1,101) for s in SCENARIOS}
    systems=read_csv(raw/"system_timeseries.csv")
    edges=read_csv(raw/"commercial_edges.csv")
    candidate_rows=read_csv(raw/"choice_candidates.csv")
    networks=read_csv(raw/"social_diagnostics.csv")
    by_run=defaultdict(list)
    edge_groups=defaultdict(list)
    candidate_groups=defaultdict(lambda:defaultdict(list))
    for row in systems:
        by_run[row["run_id"]].append(row)
    for row in edges:
        edge_groups[row["run_id"]].append(row)
    for row in candidate_rows:
        candidate_groups[row["run_id"]][row["consumer_id"]].append(row)
    runs=[]
    for m in manifest:
        rows=sorted(by_run[m["run_id"]],key=lambda row:int(row["period"]))
        tmax=int(m["T"])
        assert [int(r["period"]) for r in rows]==list(range(tmax+1))
        last=rows[-1]
        def value(key):
            return None if last[key]=="NA" else float(last[key])
        def hit(target):
            return next((int(row["period"]) for row in rows if float(row["coverage"])>=target),None)
        k=[int(e["choice_set_size"]) for e in edge_groups[m["run_id"]]]
        option_groups=list(candidate_groups[m["run_id"]].values())
        mixed=sum(len({r["direct_tie"] for r in group})>1 for group in option_groups)
        varied=sum(len({r["previous_customers"] for r in group})>1 for group in option_groups)
        runs.append({"run_id":m["run_id"],"replicate_id":int(m["replicate_id"]),"scenario":m["scenario"],
                     "customers_final":int(last["customers"]),
                     "remaining_consumers":int(m["N"])-int(m["S"])-int(last["customers"]),
                     "gini_T60":float(rows[60]["customer_gini"]) if rows[60]["customer_gini"]!="NA" else None,
                     "coverage_T60":float(rows[60]["coverage"]),
                     "t100":hit(1.0),"coverage_final":value("coverage"),
                     "aware_share_final":value("aware_share"),"gini_final":value("customer_gini"),
                     "largest_share_final":value("largest_share"),"multi_choice_share":value("multi_choice_share"),
                     "direct_choice_share":value("direct_choice_share"),"mean_choice_set_size":stats.mean(k) if k else None,
                     "mixed_proximity_share":mixed/len(k) if k else None,
                     "varied_success_share":varied/len(k) if k else None,
                     "mixed_proximity_purchases":mixed,"varied_success_purchases":varied,
                     "max_choice_set_size":max(k) if k else None,"t50":hit(.5),"t90":hit(.9),"t95":hit(.95),
                     "new_customers_last10":int(last["customers"])-int(rows[tmax-10]["customers"]),
                     "coverage_gain_last10":float(last["coverage"])-float(rows[tmax-10]["coverage"]),
                     "new_customers_last_period":int(last["new_customers"]),
                     "gini_change_last10":None if last["customer_gini"]=="NA" or rows[tmax-10]["customer_gini"]=="NA" else float(last["customer_gini"])-float(rows[tmax-10]["customer_gini"])})
    assert len(runs)==400
    assert all(len([r for r in runs if r["scenario"]==s])==100 for s in SCENARIOS)
    write_csv(out/"run_diagnostics.csv",runs)
    metrics=["gini_final","largest_share_final","coverage_final","aware_share_final","multi_choice_share",
             "direct_choice_share","mean_choice_set_size","mixed_proximity_share","varied_success_share",
             "new_customers_last10","coverage_gain_last10","t50","t90","t95","gini_change_last10","remaining_consumers","gini_T60","coverage_T60"]
    scenario_summary=[]
    for scenario in SCENARIOS:
        for metric in metrics:
            scenario_summary.append({"scenario":scenario,"metric":metric,**describe([r[metric] for r in runs if r["scenario"]==scenario])})
    write_csv(out/"scenario_summary.csv",scenario_summary)
    paired=defaultdict(dict)
    for row in runs:
        paired[row["replicate_id"]][row["scenario"]]=row
    deltas=[]
    for rep,group in sorted(paired.items()):
        assert set(group)==set(SCENARIOS)
        g={s:group[s]["gini_final"] for s in SCENARIOS}
        assert len({tuple((r["period"],r["aware_agents"],r["customers"]) for r in by_run[group[s]["run_id"]]) for s in SCENARIOS})==1
        valid=all(v is not None for v in g.values())
        deltas.append({"replicate_id":rep,"C_minus_A":g["C"]-g["A"] if valid else None,
                       "D_minus_B":g["D"]-g["B"] if valid else None,"B_minus_A":g["B"]-g["A"] if valid else None,
                       "D_minus_C":g["D"]-g["C"] if valid else None,
                       "interaction":(g["D"]-g["B"])-(g["C"]-g["A"]) if valid else None})
    write_csv(out/"paired_gini_differences.csv",deltas)
    valid=[r for r in deltas if r["C_minus_A"] is not None]
    if not valid:
        raise ValueError("No pairs have defined Gini")
    contrasts=list(deltas[0])[1:]
    rng=random.Random(bootstrap_seed)
    boot={contrast:[] for contrast in contrasts}
    # The SAME resampled replicate IDs are used for every contrast in each draw.
    for _ in range(b):
        sample=[valid[rng.randrange(len(valid))] for _ in range(len(valid))]
        for contrast in contrasts:
            boot[contrast].append(sum(r[contrast] for r in sample)/len(sample))
    contrast_summary=[]
    for contrast in contrasts:
        values=[r[contrast] for r in valid]
        desc=describe(values)
        contrast_summary.append({"contrast":contrast,**desc,"positive_pairs":sum(v>0 for v in values),
                                 "zero_pairs":sum(v==0 for v in values),"negative_pairs":sum(v<0 for v in values),
                                 "bootstrap_ci95_low":percentile(boot[contrast],.025),
                                 "bootstrap_ci95_high":percentile(boot[contrast],.975),
                                 "monte_carlo_se":desc["sd"]/math.sqrt(len(values)),
                                 "normal_ci95_halfwidth":1.96*desc["sd"]/10})
    write_csv(out/"paired_contrast_summary.csv",contrast_summary)
    distribution=[]
    for scenario in SCENARIOS:
        run_ids={r["run_id"] for r in runs if r["scenario"]==scenario}
        counts=Counter(int(e["choice_set_size"]) for e in edges if e["run_id"] in run_ids)
        total=sum(counts.values())
        for size in sorted(counts):
            distribution.append({"scenario":scenario,"choice_set_size":size,"purchases":counts[size],"pooled_share":counts[size]/total})
    write_csv(out/"choice_set_distribution.csv",distribution)
    network_summary=[]
    for rep in sorted(paired):
        group=[r for r in networks if int(r["replicate_id"])==rep]
        social=[r for r in group if r["graph_type"]=="watts_strogatz"]
        refs=[r for r in group if r["graph_type"]=="gnm_reference"]
        assert len(social)==1 and len(refs)==10
        row=social[0]
        c_ref=stats.mean(float(r["mean_local_clustering"]) for r in refs)
        l_ref=stats.mean(float(r["mean_path_length_lcc"]) for r in refs)
        network_summary.append({"replicate_id":rep,"social_clustering":float(row["mean_local_clustering"]),
                                "social_path_lcc":float(row["mean_path_length_lcc"]),"social_lcc_share":float(row["largest_component_share"]),
                                "reference_clustering_mean":c_ref,"reference_path_lcc_mean":l_ref,
                                "clustering_ratio":float(row["mean_local_clustering"])/c_ref,
                                "path_ratio":float(row["mean_path_length_lcc"])/l_ref,
                                "reference_min_lcc_share":min(float(r["largest_component_share"]) for r in refs)})
    write_csv(out/"network_diagnostics_summary.csv",network_summary)
    temporal=[]
    for scenario in SCENARIOS:
        scenario_runs=[r for r in runs if r["scenario"]==scenario]
        for t in range(execution["parameters"]["T"]+1):
            rows=[by_run[r["run_id"]][t] for r in scenario_runs]
            for metric in ("coverage","customer_gini","multi_choice_share"):
                values=[float(r[metric]) for r in rows if r[metric]!="NA"]
                temporal.append({"scenario":scenario,"period":t,"metric":metric,**describe(values)})
    write_csv(out/"temporal_summary.csv",temporal)
    summary={"model_version":execution["model_version"],"spec_version":execution["spec_version"],
             "code_sha256":execution["code_sha256"],"main_runs":len(runs),"independent_replicates":100,
             "no_adoption_runs":sum(r["customers_final"]==0 for r in runs),"parameters":execution["parameters"],
             "scenarios":{s:{m:describe([r[m] for r in runs if r["scenario"]==s]) for m in metrics} for s in SCENARIOS},
             "paired_contrasts":contrast_summary,
             "diffusion_all_scenarios_identical":True,
             "diffusion_A_only":{"t90_reached":sum(r["t90"] is not None for r in runs if r["scenario"]=="A"),
                                 "t95_reached":sum(r["t95"] is not None for r in runs if r["scenario"]=="A"),
                                 "zero_new_in_last_period":sum(r["new_customers_last_period"]==0 for r in runs if r["scenario"]=="A")},
             "networks":{m:describe([r[m] for r in network_summary]) for m in list(network_summary[0])[1:]},
             "bootstrap":{"seed":bootstrap_seed,"resamples":b,"method":"paired replicate percentile bootstrap, common resamples for all contrasts"},
             "audit":audit,"started_utc":execution["started_utc"],"finished_utc":execution["finished_utc"]}
    summary["saturation"]={
        "full_adoption_replicates":sum(r["remaining_consumers"]==0 for r in runs if r["scenario"]=="A"),
        "no_acquisitions_last10":sum(r["new_customers_last10"]==0 for r in runs if r["scenario"]=="A"),
        "incomplete_replicates":[{"replicate_id":r["replicate_id"],"remaining":r["remaining_consumers"]} for r in runs if r["scenario"]=="A" and r["remaining_consumers"]>0],
        "full_adoption_periods_conditional":describe([r["t100"] for r in runs if r["scenario"]=="A" and r["t100"] is not None])}
    summary["phase"]="main"
    summary["pilot_included"]=False
    summary["random_block_id"]=200000
    horizon=[]
    for rep,group in sorted(paired.items()):
        g60={s:group[s]["gini_T60"] for s in SCENARIOS}
        g120={s:group[s]["gini_final"] for s in SCENARIOS}
        for label,left,right in [("C_minus_A","C","A"),("D_minus_B","D","B")]:
            x60,x120=g60[left]-g60[right],g120[left]-g120[right]
            horizon.append({"replicate_id":rep,"contrast":label,"T60":x60,"T120":x120,"change":x120-x60})
    write_csv(out/"horizon_contrasts.csv",horizon)
    summary["horizon_diagnostic"]={label:{k:describe([r[k] for r in horizon if r["contrast"]==label]) for k in ("T60","T120","change")} for label in ("C_minus_A","D_minus_B")}
    seller_final=[]
    manifest_by_id={m["run_id"]:m for m in manifest}
    for r in read_csv(raw/"seller_timeseries.csv"):
        if int(r["period"])==120:
            m=manifest_by_id[r["run_id"]]
            seller_final.append({"run_id":r["run_id"],"replicate_id":int(m["replicate_id"]),"scenario":m["scenario"],"seller_id":int(r["seller_id"]),"customers":int(r["customers"])})
    write_csv(out/"seller_final_counts.csv",seller_final)
    assert len(seller_final)==4000
    (out/"main_summary.json").write_text(json.dumps(summary,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    make_plot(out,runs,temporal,contrast_summary)
    checksums={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file()}
    (out/"analysis_checksums.json").write_text(json.dumps(checksums,indent=2)+"\n")
    return summary


from plots import make_plot

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--raw",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--audit",type=Path,required=True)
    args=parser.parse_args()
    result=analyze(args.raw,args.out,args.audit)
    print(json.dumps({"runs":result["main_runs"],"no_adoption_runs":result["no_adoption_runs"],
                      "gini_means":{s:result["scenarios"][s]["gini_final"]["mean"] for s in SCENARIOS},
                      "contrasts":result["paired_contrasts"]},indent=2))
