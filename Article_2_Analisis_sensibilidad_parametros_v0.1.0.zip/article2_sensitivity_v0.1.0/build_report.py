"""Create the sensitivity report and a short student handoff from audited results."""
import hashlib
import json
from pathlib import Path
import sys


def build(out):
    s=json.loads((out/'sensitivity_summary.json').read_text())
    def f(v,d=4): return 'NA' if v is None else f'{v:.{d}f}'.replace('.',',')
    def con(cid,k='C_minus_A',metric='gini',estimand='difference'):
        return next(r for r in s['contrasts'] if r['config_id']==cid and r['contrast']==k and r['metric']==metric and r['estimand']==estimand)
    def met(cid,key,sc='A'):
        return next(r for r in s['scenarios'] if r['config_id']==cid and r['scenario']==sc and r['metric']==key)
    cfg={r['config_id']:r for r in s['configurations']}
    def cell(r): return f"{f(r['mean'])} [{f(r['ci95_low'])}; {f(r['ci95_high'])}]"
    table='\n'.join(f"| {s['labels'][cid]} | {f(100*cfg[cid]['coverage_mean'],2)} % | {cell(con(cid))} | {cell(con(cid,'D_minus_B'))} |" for cid in s['order'])
    changes='\n'.join(f"| {s['labels'][cid]} | {cell(con(cid,estimand='change_vs_base30'))} | {cell(con(cid,'D_minus_B',estimand='change_vs_base30'))} |" for cid in s['order'][1:] if cfg[cid]['parameter']!='S')
    norm_table='\n'.join(f"| {num} | {f(met(cid,'gini_normalized')['mean'])} | {f(met(cid,'gini_normalized','C')['mean'])} | {cell(con(cid,metric='gini_normalized'))} | {cell(con(cid,'D_minus_B',metric='gini_normalized'))} |" for cid,num in [('sens_s_005',5),('baseline30',10),('sens_s_020',20)])
    norm_changes='\n'.join(f"| {s['labels'][cid]} | {cell(con(cid,metric='gini_normalized',estimand='change_vs_base30'))} | {cell(con(cid,'D_minus_B',metric='gini_normalized',estimand='change_vs_base30'))} |" for cid in ['sens_s_005','sens_s_020'])
    opp='\n'.join(f"| {s['labels'][cid]} | {f(100*met(cid,'multi_choice_share')['mean'],2)} % | {f(100*met(cid,'mixed_proximity_share')['mean'],2)} % | {cfg[cid]['full_adoption_replicates']}/30 | {f(cfg[cid]['new_customers_last10_mean'],2)} |" for cid in s['order'])
    sign='\n'.join(f"| {s['labels'][cid]} | {con(cid)['positive_pairs']}/{con(cid)['zero_pairs']}/{con(cid)['negative_pairs']} | {con(cid,'D_minus_B')['positive_pairs']}/{con(cid,'D_minus_B')['zero_pairs']}/{con(cid,'D_minus_B')['negative_pairs']} |" for cid in s['order'][1:])
    assert all(con(cid,k)['ci95_low']>0 for cid in s['order'][1:] for k in ('C_minus_A','D_minus_B'))
    report=f'''# Article 2 — Sensibilidad de parámetros

**Fecha:** 26 de septiembre de 2026, America/Bogota. **Modelo:** v0.1.0. **Reglas:** especificación v0.1. **Horizonte:** 120 periodos. **Estado:** diez configuraciones completadas y auditadas.

La preferencia explícita por éxito acumulado conserva una diferencia media positiva de concentración en las diez configuraciones examinadas, tanto para C−A como para D−B. La magnitud cambia considerablemente: el contraste C−A va de {f(con('sens_pws_000')['mean'])} con red en anillo a {f(con('sens_pws_100')['mean'])} con reconexión completa. Esta estabilidad de dirección corresponde a los valores probados y al periodo 120; no es una afirmación de robustez global ni de comportamiento después de completarse todas las compras.

## Diseño y número de simulaciones

Se varió una dimensión a la vez respecto a la base: N=500, S=10, k=6, p_WS=0,10, q_s=0,25, q_r=0,20, a=0,10, α=ln(2), β=1 y T=120. Los escenarios A–D mantienen su definición. Los valores son supuestos experimentales, sin calibración real.

| Dimensión | Base | Valores examinados | Simulaciones nuevas |
|---|---:|---|---:|
| Reconexión de la red p_WS | 0,10 | 0; 1 | 240 |
| Recomendación q_r | 0,20 | 0,05; 0,50 | 240 |
| Intensidad de éxito β | 1 | 0,5; 2 | 120 |
| Vendedores S | 10 | 5; 20 | 240 |
| Probabilidad de compra a | 0,10 | 0,05; 0,20 | 240 |
| Total | | Diez configuraciones, 30 repeticiones por configuración | 1080 |

Cada configuración contiene 120 registros de escenario: 30 repeticiones por A–D. En las dos variaciones de β, A y B se copiaron exactamente del principal y se identificaron mediante `source_run_id`, porque su coeficiente activo de éxito sigue siendo cero. Son 120 registros reutilizados que remiten a 60 ejecuciones originales distintas. En total, las diez configuraciones contienen 1200 registros, de los cuales 1080 proceden de simulaciones nuevas.

La referencia es el subconjunto fijo de repeticiones 1–30 del principal, bloque 200000: otros 120 registros existentes. El análisis completo reúne 1320 filas de ejecución, pero no 1320 observaciones independientes. La unidad de remuestreo es cada uno de los 30 índices emparejados. Las reutilizaciones no aumentan el tamaño de muestra. El principal de 400 simulaciones y el piloto permanecen intactos.

**La base de esta comparación usa 30 pares, no los 100 pares del principal completo.** Por eso aquí C−A={f(con('baseline30')['mean'])} y D−B={f(con('baseline30','D_minus_B')['mean'])}; las estimaciones del principal completo fueron 0,072776 y 0,072748. Esta diferencia corresponde al subconjunto predefinido, no a una modificación de los resultados originales.

## Emparejamiento y verificaciones

Dentro de cada configuración, A–D comparten red, roles y sorteos. Al modificar q_r, β o a, también se conservan exactamente la red, los roles y las tablas uniformes de la base. Con p_WS cambia la red y la asignación de sorteos a sus enlaces, aunque se conservan roles y sorteos de compra/elección. Con S se conserva la red, pero cambian los roles y la indexación de consumidores. En estas dos dimensiones estructurales, el emparejamiento entre configuraciones corresponde al índice de semilla, sin afirmar identidad de todos los sorteos por persona o enlace.

En p_WS=0, la topología de anillo es determinista; las repeticiones varían ubicaciones de vendedores y realizaciones de difusión/compra. No se presentan esos anillos como 30 topologías diferentes. Los diagnósticos G(N,M) se reutilizan del principal porque N=500 y M=1500 permanecen constantes en todas las configuraciones.

La auditoría independiente aprobó {s['audit']['raw_assertions_passed']:,} comprobaciones de exportación en las diez configuraciones. También auditó el subconjunto base y verificó {s['audit']['exact_reused_rows']:,} filas reutilizadas exactamente, salvo el identificador de la ejecución. No hubo ejecuciones sin adopción; los Gini finales están definidos en todos los casos. Se comprobaron parámetros, coeficientes activos, semillas y medidas normalizadas.

En las simulaciones nuevas se verificó la identidad individual de conocimiento y compra entre escenarios ejecutados. Para las variaciones β, la comparación con A–B reutilizados verificó las cuentas de conocimiento/compra en todos los periodos, las compras por individuo y el primer conocimiento de cada comprador. Los tiempos individuales de conocimiento de consumidores que nunca compraron no están exportados en el principal y no se reconstruyeron en esa comparación; la igualdad completa A–B está respaldada por sus verificaciones originales. Este alcance queda registrado en los metadatos.

El motor conserva la huella `{s['plan']['code_sha256']}`. Los scripts nuevos organizan la campaña, la reutilización, la auditoría y el análisis; no modifican las reglas del simulador. El plan se registró antes de ejecutar la campaña. Fechas UTC: {s['campaign']['started_utc']} — {s['campaign']['finished_utc']}.

## Contrastes de concentración al periodo 120

La tabla muestra diferencias de **Gini sin normalizar**, con intervalos bootstrap marginales del 95 %. La cobertura es común a A–D dentro de cada configuración. C−A y D−B comparan la contribución adicional de la preferencia explícita por éxito, sobre la difusión por recomendaciones que ya opera en A y B.

| Configuración | Cobertura media | C−A: media [IC 95 %] | D−B: media [IC 95 %] |
|---|---:|---:|---:|
{table}

Los veinte intervalos de los dos contrastes principales en las diez configuraciones quedan por encima de cero de forma marginal. Los intervalos no están ajustados por multiplicidad y no constituyen una garantía simultánea sobre todas las configuraciones. Se conservaron resultados inversos y nulos por repetición:

| Configuración | Pares C−A: + / 0 / − | Pares D−B: + / 0 / − |
|---|---:|---:|
{sign}

Para comparar la intensidad del efecto con la base, se calculó en cada repetición la diferencia entre contrastes, por ejemplo (C−A)_configuración − (C−A)_base. Esta comparación emparejada, no el solapamiento visual de intervalos separados, sustenta los cambios siguientes. S se trata aparte con normalización.

| Configuración | Cambio de C−A frente a base30 | Cambio de D−B frente a base30 |
|---|---:|---:|
{changes}

## Interpretación de las cinco dimensiones

**Estructura social.** El anillo reduce mucho el contraste de éxito: pocas compras permiten comparar varios vendedores y la difusión sigue incompleta. Con p_WS=1 el contraste es mayor en los valores examinados. Los caminos medios sociales fueron {f(cfg['sens_pws_000']['path_lcc_mean'],2)}, {f(cfg['baseline30']['path_lcc_mean'],2)} y {f(cfg['sens_pws_100']['path_lcc_mean'],2)} para p_WS=0, 0,10 y 1. Las redes de la campaña fueron conexas. Reconexión completa en Watts–Strogatz no equivale a declarar la red idéntica a un grafo G(N,M).

**Recomendación.** En los tres valores examinados, aumentar q_r se acompaña de mayores contrastes de éxito y de más compras con varias alternativas. Esto es compatible con que la difusión amplíe las oportunidades sobre las que actúa la elección. No identifica por sí solo una mediación estadística ni un comportamiento de un mercado real.

**Intensidad de éxito.** β=0,5 produce contrastes menores que la base β=1; β=2 produce contrastes mayores. La cobertura no cambia: la identidad del vendedor elegido no modifica las tasas de compra ni recomendación en estas reglas. A y B son idénticos por reutilización documentada.

**Probabilidad de compra.** a=0,05 produce un contraste de éxito mayor que a=0,20 en esta comparación. Una interpretación consistente con las reglas es que comprar más tarde permite acumular más alternativas conocidas. El patrón de alternativas de la tabla siguiente acompaña esa lectura; no se atribuye a satisfacción o confianza, que no están modeladas. La menor a también deja compras pendientes en T=120.

**Número de vendedores.** S modifica el máximo del Gini y el mínimo de la cuota mayor. Por ello, además de valores originales, se exportan G_norm=G×S/(S−1) y cuota_norm=(cuota−1/S)/(1−1/S). Esta transformación ajusta los límites de la escala; no elimina las diferencias estructurales del mercado.

| Vendedores | G_norm medio A | G_norm medio C | C−A normalizado [IC] | D−B normalizado [IC] |
|---|---:|---:|---:|---:|
{norm_table}

| Configuración | Cambio normalizado de C−A frente a S=10 | Cambio normalizado de D−B frente a S=10 |
|---|---:|---:|
{norm_changes}

En las comparaciones normalizadas entre S=5 o S=20 y la base, los intervalos de cambio incluyen cero. Con 30 pares no se distingue con claridad una diferencia en la magnitud del efecto frente a S=10. Esto no prueba igualdad entre tamaños; sí permite observar que el contraste medio de éxito es positivo dentro de cada tamaño examinado.

## Disponibilidad de alternativas y cobertura incompleta

Las dos columnas de oportunidades siguientes corresponden a A, para mostrar el entorno de elección bajo una regla común sin sesgos explícitos. Las tablas CSV conservan los cuatro escenarios y también distinguen alternativas con distintos conteos de clientes previos. Las proporciones se calculan por repetición y después se promedian.

| Configuración | Compras con ≥2 candidatos, A | Directo e indirecto disponibles, A | Cobertura completa | Compras medias, periodos 111–120 |
|---|---:|---:|---:|---:|
{opp}

En p_WS=0, la cobertura media es {f(100*cfg['sens_pws_000']['coverage_mean'],2)} %, su mínimo es {f(100*cfg['sens_pws_000']['coverage_min'],2)} % y quedan {f(cfg['sens_pws_000']['remaining_mean'],2)} consumidores pendientes por repetición, en promedio. Durante los últimos diez periodos la cobertura todavía aumenta {f(100*cfg['sens_pws_000']['coverage_gain_last10_mean'],2)} puntos porcentuales. En a=0,05 la cobertura alcanza {f(100*cfg['sens_a_005']['coverage_mean'],2)} %, con {f(cfg['sens_a_005']['remaining_mean'],2)} pendientes en promedio. No se excluyen esas repeticiones ni se confunden sus fotografías a T=120 con mercados completamente cubiertos.

Las relaciones sociales sostienen toda la difusión. Un contraste de proximidad pequeño no equivale a ausencia de importancia social; la regla solo favorece un contacto directo cuando hay alternativas indirectas conocidas. La red comercial sigue formada por estrellas debido a roles separados y una compra por consumidor. Los resultados no demuestran una red libre de escala.

## Estadística y alcance de robustez

Se usaron 10000 remuestreos de los 30 índices completos, semilla 260927, conservando juntos A–D y las configuraciones en cada remuestreo. Los intervalos describen incertidumbre Monte Carlo bajo los supuestos. No se trataron agentes, vendedores, periodos ni copias reutilizadas como repeticiones independientes.

El estudio es una sensibilidad acotada de una dimensión a la vez. No examina combinaciones simultáneas de parámetros, todo el espacio de valores, ni incertidumbre empírica. Las comparaciones secundarias B−A, D−C e interacción entre reglas están disponibles en `contrast_summary.csv`; no equivalen a interacciones entre parámetros de sensibilidad. Se conservan 30 repeticiones por configuración en esta etapa, sin ampliar selectivamente para obtener significación. Las diferencias no resueltas se reportan como incertidumbre.

La conclusión que puede incorporarse al artículo es que, en los valores examinados y al horizonte fijo de 120 periodos, la preferencia explícita por éxito incrementó la concentración media, con magnitud condicionada por la estructura social y las oportunidades de elección. Para afirmar persistencia tras la cobertura completa del anillo se requeriría una extensión temporal específica, que no se ejecutó en esta campaña.

## Entregables

El paquete de datos conserva las diez configuraciones, la referencia base30, los identificadores de origen, las semillas, el plan, las huellas de entradas y las auditorías. El paquete de análisis contiene scripts reproducibles, tablas CSV, resumen JSON, informe, guía y figuras. La figura de contrastes utiliza Gini normalizado; la tabla principal de este informe presenta Gini original. Las dos escalas están identificadas explícitamente.
'''
    (out/'Article_2_Informe_sensibilidad_parametros_v0.1.0.md').write_text(report,encoding='utf-8')
    guide=f'''# Article 2 — Sensibilidad: guía para integrar resultados

## Qué se puede afirmar

En las diez configuraciones examinadas, la diferencia media de concentración al introducir la preferencia explícita por éxito permaneció positiva en T=120. Su magnitud depende de las condiciones: C−A={f(con('sens_pws_000')['mean'])} con p_WS=0 y {f(con('sens_pws_100')['mean'])} con p_WS=1. La conclusión se refiere a estas simulaciones y valores, sin calibración real.

## Cómo organizar la sección

1. **Diseño.** Explicar las cinco dimensiones, dos alternativas por dimensión y 30 repeticiones emparejadas. Diferenciar 1080 simulaciones nuevas, 120 registros reutilizados en β y la referencia existente de 120 ejecuciones base. La unidad independiente es cada uno de los 30 índices; las copias no aumentan la muestra.
2. **Dirección y magnitud.** Presentar la tabla de contrastes y su figura. Explicar que un efecto medio positivo no exige que todas las repeticiones sean positivas: en el anillo hay resultados nulos e inversos. No sumar ni promediar indiscriminadamente configuraciones para producir una única cifra de robustez.
3. **Cambios respecto a la base.** Utilizar `contrast_summary.csv`, `estimand=change_vs_base30`, que contiene la diferencia emparejada entre contrastes. La base de sensibilidad usa los mismos 30 pares; no comparar como si fuera el principal completo de 100 pares.
4. **Número de vendedores.** Usar `metric=gini_normalized` para comparar S=5, 10 y 20, y acompañar con Gini original y cuota del mayor vendedor. Reconocer que la normalización ajusta límites, sin hacer idénticos los sistemas.
5. **Difusión y oportunidades.** Relacionar los contrastes con cobertura y alternativas disponibles. Distinguir explicación compatible con las reglas de una prueba adicional de mediación.
6. **Límites.** La campaña cambia una dimensión a la vez, conserva T=120 y usa intervalos marginales sin ajuste por multiplicidad. No sustenta robustez global, validación empírica o una red comercial libre de escala.

## Dos resultados que requieren especial cuidado

**Anillo sin reconexión.** La cobertura media es {f(100*cfg['sens_pws_000']['coverage_mean'],2)} % y sigue creciendo al final. El efecto de éxito es pequeño al horizonte fijado. No redactar que el efecto desaparece, que todas las compras terminaron o que el patrón será igual después de la absorción.

**Cambios en S.** Los contrastes de éxito son positivos dentro de cada tamaño. Los intervalos de sus cambios normalizados frente a S=10 incluyen cero: la campaña no distingue con claridad su magnitud relativa. No presentar esto como prueba de equivalencia.

## Material disponible

`configuration_summary.csv` resume cobertura y actividad final; `scenario_summary.csv` resume resultados por escenario; `paired_differences.csv` conserva los 30 pares; `contrast_summary.csv` contiene intervalos y cambios frente a la base; `reuse_ledger.csv` identifica procedencias; `network_diagnostics.csv` y `temporal_summary.csv` permiten revisar red y trayectorias. El informe reúne las cifras listas para discusión y las figuras se entregan en PNG/SVG.

El principal y esta sensibilidad ya permiten integrar el primer borrador, manteniendo las conclusiones al horizonte observado. Si se desea hablar de la concentración después de completar todas las compras en p_WS=0, habrá que ejecutar y documentar una extensión temporal adicional.
'''
    (out/'Article_2_Guia_sensibilidad_estudiante_v0.1.0.md').write_text(guide,encoding='utf-8')
    (out/'analysis_checksums.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name!='analysis_checksums.json'},indent=2)+'\n')


if __name__=='__main__': build(Path(sys.argv[1]))
