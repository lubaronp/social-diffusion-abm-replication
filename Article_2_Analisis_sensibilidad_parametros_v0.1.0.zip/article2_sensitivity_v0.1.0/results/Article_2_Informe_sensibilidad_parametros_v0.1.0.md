# Article 2 — Sensibilidad de parámetros

**Fecha:** 26 de septiembre de 2026, America/Bogota. **Modelo:** v0.1.0. **Reglas:** especificación v0.1. **Horizonte:** 120 periodos. **Estado:** diez configuraciones completadas y auditadas.

La preferencia explícita por éxito acumulado conserva una diferencia media positiva de concentración en las diez configuraciones examinadas, tanto para C−A como para D−B. La magnitud cambia considerablemente: el contraste C−A va de 0,0045 con red en anillo a 0,1434 con reconexión completa. Esta estabilidad de dirección corresponde a los valores probados y al periodo 120; no es una afirmación de robustez global ni de comportamiento después de completarse todas las compras.

## Diseño y número de simulaciones

Se varió una dimensión a la vez respecto a la base: N=500, S=10, k=6, p_WS=0,10, q_s=0,25, q_r=0,20, a=0,10, α=ln(2), β=1 y T=120. Los escenarios A–D mantienen su definición. Los valores son supuestos experimentales, sin calibración real.

| Dimensión | Base | Valores examinados | Simulaciones nuevas |
|---|---:|---|---:|
| Reconexión de la red p_WS | 0,10 | 0; 1 | 240 |
| Recomendación q_r | 0,20 | 0,05; 0,50 | 240 |
| Intensidad de éxito β | 1 | 0,5; 2 | 120 |
| Vendedores S | 10 | 5; 20 | 240 |
| Probabilidad de compra a | 0,10 | 0,05; 0,20 | 240 |
| Total | | Diez configuraciones, 30 repeticiones por configuración | 1080 |

Cada configuración contiene 120 registros de escenario: 30 repeticiones por A–D. En las dos variaciones de β, A y B se copiaron exactamente del principal y se identificaron mediante `source_run_id`, porque su coeficiente activo de éxito sigue siendo cero. Son 120 registros reutilizados que remiten a 60 ejecuciones originales distintas. En total, las diez configuraciones contienen 1200 registros, de los cuales 1080 proceden de simulaciones nuevas.

La referencia es el subconjunto fijo de repeticiones 1–30 del principal, bloque 200000: otros 120 registros existentes. El análisis completo reúne 1320 filas de ejecución, pero no 1320 observaciones independientes. La unidad de remuestreo es cada uno de los 30 índices emparejados. Las reutilizaciones no aumentan el tamaño de muestra. El principal de 400 simulaciones y el piloto permanecen intactos.

**La base de esta comparación usa 30 pares, no los 100 pares del principal completo.** Por eso aquí C−A=0,0803 y D−B=0,0852; las estimaciones del principal completo fueron 0,072776 y 0,072748. Esta diferencia corresponde al subconjunto predefinido, no a una modificación de los resultados originales.

## Emparejamiento y verificaciones

Dentro de cada configuración, A–D comparten red, roles y sorteos. Al modificar q_r, β o a, también se conservan exactamente la red, los roles y las tablas uniformes de la base. Con p_WS cambia la red y la asignación de sorteos a sus enlaces, aunque se conservan roles y sorteos de compra/elección. Con S se conserva la red, pero cambian los roles y la indexación de consumidores. En estas dos dimensiones estructurales, el emparejamiento entre configuraciones corresponde al índice de semilla, sin afirmar identidad de todos los sorteos por persona o enlace.

En p_WS=0, la topología de anillo es determinista; las repeticiones varían ubicaciones de vendedores y realizaciones de difusión/compra. No se presentan esos anillos como 30 topologías diferentes. Los diagnósticos G(N,M) se reutilizan del principal porque N=500 y M=1500 permanecen constantes en todas las configuraciones.

La auditoría independiente aprobó 14,884,756 comprobaciones de exportación en las diez configuraciones. También auditó el subconjunto base y verificó 302,772 filas reutilizadas exactamente, salvo el identificador de la ejecución. No hubo ejecuciones sin adopción; los Gini finales están definidos en todos los casos. Se comprobaron parámetros, coeficientes activos, semillas y medidas normalizadas.

En las simulaciones nuevas se verificó la identidad individual de conocimiento y compra entre escenarios ejecutados. Para las variaciones β, la comparación con A–B reutilizados verificó las cuentas de conocimiento/compra en todos los periodos, las compras por individuo y el primer conocimiento de cada comprador. Los tiempos individuales de conocimiento de consumidores que nunca compraron no están exportados en el principal y no se reconstruyeron en esa comparación; la igualdad completa A–B está respaldada por sus verificaciones originales. Este alcance queda registrado en los metadatos.

El motor conserva la huella `81e7fa14ba2700a2d5faef4acaaa024cc0a4cc3f10a342b5f3e581e94d2b7d1d`. Los scripts nuevos organizan la campaña, la reutilización, la auditoría y el análisis; no modifican las reglas del simulador. El plan se registró antes de ejecutar la campaña. Fechas UTC: 2026-09-26T09:37:45.171771+00:00 — 2026-09-26T09:38:26.891824+00:00.

## Contrastes de concentración al periodo 120

La tabla muestra diferencias de **Gini sin normalizar**, con intervalos bootstrap marginales del 95 %. La cobertura es común a A–D dentro de cada configuración. C−A y D−B comparan la contribución adicional de la preferencia explícita por éxito, sobre la difusión por recomendaciones que ya opera en A y B.

| Configuración | Cobertura media | C−A: media [IC 95 %] | D−B: media [IC 95 %] |
|---|---:|---:|---:|
| Base (30 pares) | 99,98 % | 0,0803 [0,0707; 0,0908] | 0,0852 [0,0743; 0,0976] |
| p_WS = 0 | 80,10 % | 0,0045 [0,0017; 0,0091] | 0,0053 [0,0020; 0,0101] |
| p_WS = 1 | 100,00 % | 0,1434 [0,1293; 0,1581] | 0,1459 [0,1291; 0,1637] |
| q_r = 0,05 | 99,69 % | 0,0334 [0,0255; 0,0409] | 0,0360 [0,0279; 0,0437] |
| q_r = 0,50 | 99,99 % | 0,1061 [0,0903; 0,1235] | 0,1084 [0,0920; 0,1260] |
| β = 0,5 | 99,98 % | 0,0397 [0,0332; 0,0468] | 0,0469 [0,0388; 0,0560] |
| β = 2 | 99,98 % | 0,1260 [0,1125; 0,1413] | 0,1281 [0,1132; 0,1446] |
| S = 5 | 99,97 % | 0,0604 [0,0458; 0,0741] | 0,0645 [0,0528; 0,0768] |
| S = 20 | 99,99 % | 0,0758 [0,0687; 0,0830] | 0,0773 [0,0693; 0,0848] |
| a = 0,05 | 98,52 % | 0,1010 [0,0887; 0,1147] | 0,1024 [0,0904; 0,1157] |
| a = 0,20 | 100,00 % | 0,0450 [0,0371; 0,0534] | 0,0518 [0,0410; 0,0642] |

Los veinte intervalos de los dos contrastes principales en las diez configuraciones quedan por encima de cero de forma marginal. Los intervalos no están ajustados por multiplicidad y no constituyen una garantía simultánea sobre todas las configuraciones. Se conservaron resultados inversos y nulos por repetición:

| Configuración | Pares C−A: + / 0 / − | Pares D−B: + / 0 / − |
|---|---:|---:|
| p_WS = 0 | 22/6/2 | 22/6/2 |
| p_WS = 1 | 30/0/0 | 30/0/0 |
| q_r = 0,05 | 29/0/1 | 29/0/1 |
| q_r = 0,50 | 30/0/0 | 30/0/0 |
| β = 0,5 | 30/0/0 | 30/0/0 |
| β = 2 | 30/0/0 | 30/0/0 |
| S = 5 | 29/0/1 | 30/0/0 |
| S = 20 | 30/0/0 | 30/0/0 |
| a = 0,05 | 30/0/0 | 30/0/0 |
| a = 0,20 | 30/0/0 | 30/0/0 |

Para comparar la intensidad del efecto con la base, se calculó en cada repetición la diferencia entre contrastes, por ejemplo (C−A)_configuración − (C−A)_base. Esta comparación emparejada, no el solapamiento visual de intervalos separados, sustenta los cambios siguientes. S se trata aparte con normalización.

| Configuración | Cambio de C−A frente a base30 | Cambio de D−B frente a base30 |
|---|---:|---:|
| p_WS = 0 | -0,0758 [-0,0877; -0,0634] | -0,0800 [-0,0936; -0,0665] |
| p_WS = 1 | 0,0631 [0,0433; 0,0827] | 0,0607 [0,0386; 0,0826] |
| q_r = 0,05 | -0,0469 [-0,0594; -0,0355] | -0,0492 [-0,0627; -0,0373] |
| q_r = 0,50 | 0,0258 [0,0083; 0,0442] | 0,0231 [0,0071; 0,0400] |
| β = 0,5 | -0,0406 [-0,0479; -0,0337] | -0,0383 [-0,0448; -0,0323] |
| β = 2 | 0,0457 [0,0381; 0,0536] | 0,0428 [0,0353; 0,0506] |
| a = 0,05 | 0,0208 [0,0047; 0,0362] | 0,0172 [0,0005; 0,0330] |
| a = 0,20 | -0,0353 [-0,0478; -0,0236] | -0,0335 [-0,0475; -0,0204] |

## Interpretación de las cinco dimensiones

**Estructura social.** El anillo reduce mucho el contraste de éxito: pocas compras permiten comparar varios vendedores y la difusión sigue incompleta. Con p_WS=1 el contraste es mayor en los valores examinados. Los caminos medios sociales fueron 42,08, 5,43 y 3,69 para p_WS=0, 0,10 y 1. Las redes de la campaña fueron conexas. Reconexión completa en Watts–Strogatz no equivale a declarar la red idéntica a un grafo G(N,M).

**Recomendación.** En los tres valores examinados, aumentar q_r se acompaña de mayores contrastes de éxito y de más compras con varias alternativas. Esto es compatible con que la difusión amplíe las oportunidades sobre las que actúa la elección. No identifica por sí solo una mediación estadística ni un comportamiento de un mercado real.

**Intensidad de éxito.** β=0,5 produce contrastes menores que la base β=1; β=2 produce contrastes mayores. La cobertura no cambia: la identidad del vendedor elegido no modifica las tasas de compra ni recomendación en estas reglas. A y B son idénticos por reutilización documentada.

**Probabilidad de compra.** a=0,05 produce un contraste de éxito mayor que a=0,20 en esta comparación. Una interpretación consistente con las reglas es que comprar más tarde permite acumular más alternativas conocidas. El patrón de alternativas de la tabla siguiente acompaña esa lectura; no se atribuye a satisfacción o confianza, que no están modeladas. La menor a también deja compras pendientes en T=120.

**Número de vendedores.** S modifica el máximo del Gini y el mínimo de la cuota mayor. Por ello, además de valores originales, se exportan G_norm=G×S/(S−1) y cuota_norm=(cuota−1/S)/(1−1/S). Esta transformación ajusta los límites de la escala; no elimina las diferencias estructurales del mercado.

| Vendedores | G_norm medio A | G_norm medio C | C−A normalizado [IC] | D−B normalizado [IC] |
|---|---:|---:|---:|---:|
| 5 | 0,3109 | 0,3864 | 0,0755 [0,0573; 0,0926] | 0,0806 [0,0660; 0,0959] |
| 10 | 0,3328 | 0,4220 | 0,0892 [0,0785; 0,1009] | 0,0947 [0,0825; 0,1084] |
| 20 | 0,3635 | 0,4433 | 0,0798 [0,0723; 0,0873] | 0,0814 [0,0730; 0,0893] |

| Configuración | Cambio normalizado de C−A frente a S=10 | Cambio normalizado de D−B frente a S=10 |
|---|---:|---:|
| S = 5 | -0,0137 [-0,0332; 0,0045] | -0,0141 [-0,0323; 0,0043] |
| S = 20 | -0,0094 [-0,0210; 0,0017] | -0,0133 [-0,0290; 0,0013] |

En las comparaciones normalizadas entre S=5 o S=20 y la base, los intervalos de cambio incluyen cero. Con 30 pares no se distingue con claridad una diferencia en la magnitud del efecto frente a S=10. Esto no prueba igualdad entre tamaños; sí permite observar que el contraste medio de éxito es positivo dentro de cada tamaño examinado.

## Disponibilidad de alternativas y cobertura incompleta

Las dos columnas de oportunidades siguientes corresponden a A, para mostrar el entorno de elección bajo una regla común sin sesgos explícitos. Las tablas CSV conservan los cuatro escenarios y también distinguen alternativas con distintos conteos de clientes previos. Las proporciones se calculan por repetición y después se promedian.

| Configuración | Compras con ≥2 candidatos, A | Directo e indirecto disponibles, A | Cobertura completa | Compras medias, periodos 111–120 |
|---|---:|---:|---:|---:|
| Base (30 pares) | 33,45 % | 1,59 % | 27/30 | 0,00 |
| p_WS = 0 | 5,98 % | 0,85 % | 0/30 | 17,40 |
| p_WS = 1 | 53,80 % | 3,72 % | 30/30 | 0,00 |
| q_r = 0,05 | 20,02 % | 0,59 % | 14/30 | 2,43 |
| q_r = 0,50 | 39,30 % | 2,32 % | 29/30 | 0,00 |
| β = 0,5 | 33,45 % | 1,59 % | 27/30 | 0,00 |
| β = 2 | 33,45 % | 1,59 % | 27/30 | 0,00 |
| S = 5 | 28,10 % | 0,51 % | 26/30 | 0,17 |
| S = 20 | 37,63 % | 4,79 % | 29/30 | 0,03 |
| a = 0,05 | 37,19 % | 2,14 % | 0/30 | 5,47 |
| a = 0,20 | 27,27 % | 1,19 % | 30/30 | 0,00 |

En p_WS=0, la cobertura media es 80,10 %, su mínimo es 57,76 % y quedan 97,53 consumidores pendientes por repetición, en promedio. Durante los últimos diez periodos la cobertura todavía aumenta 3,55 puntos porcentuales. En a=0,05 la cobertura alcanza 98,52 %, con 7,27 pendientes en promedio. No se excluyen esas repeticiones ni se confunden sus fotografías a T=120 con mercados completamente cubiertos.

Las relaciones sociales sostienen toda la difusión. Un contraste de proximidad pequeño no equivale a ausencia de importancia social; la regla solo favorece un contacto directo cuando hay alternativas indirectas conocidas. La red comercial sigue formada por estrellas debido a roles separados y una compra por consumidor. Los resultados no demuestran una red libre de escala.

## Estadística y alcance de robustez

Se usaron 10000 remuestreos de los 30 índices completos, semilla 260927, conservando juntos A–D y las configuraciones en cada remuestreo. Los intervalos describen incertidumbre Monte Carlo bajo los supuestos. No se trataron agentes, vendedores, periodos ni copias reutilizadas como repeticiones independientes.

El estudio es una sensibilidad acotada de una dimensión a la vez. No examina combinaciones simultáneas de parámetros, todo el espacio de valores, ni incertidumbre empírica. Las comparaciones secundarias B−A, D−C e interacción entre reglas están disponibles en `contrast_summary.csv`; no equivalen a interacciones entre parámetros de sensibilidad. Se conservan 30 repeticiones por configuración en esta etapa, sin ampliar selectivamente para obtener significación. Las diferencias no resueltas se reportan como incertidumbre.

La conclusión que puede incorporarse al artículo es que, en los valores examinados y al horizonte fijo de 120 periodos, la preferencia explícita por éxito incrementó la concentración media, con magnitud condicionada por la estructura social y las oportunidades de elección. Para afirmar persistencia tras la cobertura completa del anillo se requeriría una extensión temporal específica, que no se ejecutó en esta campaña.

## Entregables

El paquete de datos conserva las diez configuraciones, la referencia base30, los identificadores de origen, las semillas, el plan, las huellas de entradas y las auditorías. El paquete de análisis contiene scripts reproducibles, tablas CSV, resumen JSON, informe, guía y figuras. La figura de contrastes utiliza Gini normalizado; la tabla principal de este informe presenta Gini original. Las dos escalas están identificadas explícitamente.
