# Article 2 — Sensibilidad: guía para integrar resultados

## Qué se puede afirmar

En las diez configuraciones examinadas, la diferencia media de concentración al introducir la preferencia explícita por éxito permaneció positiva en T=120. Su magnitud depende de las condiciones: C−A=0,0045 con p_WS=0 y 0,1434 con p_WS=1. La conclusión se refiere a estas simulaciones y valores, sin calibración real.

## Cómo organizar la sección

1. **Diseño.** Explicar las cinco dimensiones, dos alternativas por dimensión y 30 repeticiones emparejadas. Diferenciar 1080 simulaciones nuevas, 120 registros reutilizados en β y la referencia existente de 120 ejecuciones base. La unidad independiente es cada uno de los 30 índices; las copias no aumentan la muestra.
2. **Dirección y magnitud.** Presentar la tabla de contrastes y su figura. Explicar que un efecto medio positivo no exige que todas las repeticiones sean positivas: en el anillo hay resultados nulos e inversos. No sumar ni promediar indiscriminadamente configuraciones para producir una única cifra de robustez.
3. **Cambios respecto a la base.** Utilizar `contrast_summary.csv`, `estimand=change_vs_base30`, que contiene la diferencia emparejada entre contrastes. La base de sensibilidad usa los mismos 30 pares; no comparar como si fuera el principal completo de 100 pares.
4. **Número de vendedores.** Usar `metric=gini_normalized` para comparar S=5, 10 y 20, y acompañar con Gini original y cuota del mayor vendedor. Reconocer que la normalización ajusta límites, sin hacer idénticos los sistemas.
5. **Difusión y oportunidades.** Relacionar los contrastes con cobertura y alternativas disponibles. Distinguir explicación compatible con las reglas de una prueba adicional de mediación.
6. **Límites.** La campaña cambia una dimensión a la vez, conserva T=120 y usa intervalos marginales sin ajuste por multiplicidad. No sustenta robustez global, validación empírica o una red comercial libre de escala.

## Dos resultados que requieren especial cuidado

**Anillo sin reconexión.** La cobertura media es 80,10 % y sigue creciendo al final. El efecto de éxito es pequeño al horizonte fijado. No redactar que el efecto desaparece, que todas las compras terminaron o que el patrón será igual después de la absorción.

**Cambios en S.** Los contrastes de éxito son positivos dentro de cada tamaño. Los intervalos de sus cambios normalizados frente a S=10 incluyen cero: la campaña no distingue con claridad su magnitud relativa. No presentar esto como prueba de equivalencia.

## Material disponible

`configuration_summary.csv` resume cobertura y actividad final; `scenario_summary.csv` resume resultados por escenario; `paired_differences.csv` conserva los 30 pares; `contrast_summary.csv` contiene intervalos y cambios frente a la base; `reuse_ledger.csv` identifica procedencias; `network_diagnostics.csv` y `temporal_summary.csv` permiten revisar red y trayectorias. El informe reúne las cifras listas para discusión y las figuras se entregan en PNG/SVG.

El principal y esta sensibilidad ya permiten integrar el primer borrador, manteniendo las conclusiones al horizonte observado. Si se desea hablar de la concentración después de completar todas las compras en p_WS=0, habrá que ejecutar y documentar una extensión temporal adicional.
