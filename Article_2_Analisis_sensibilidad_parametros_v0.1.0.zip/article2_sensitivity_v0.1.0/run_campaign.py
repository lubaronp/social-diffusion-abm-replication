"""One-factor sensitivity orchestration; imports the unchanged model v0.1.0."""
import argparse
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, replace
from datetime import datetime, timezone
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys

ROOT=Path(__file__).resolve().parent
MODEL=ROOT.parent/'article2_model_v0.1.0'
sys.path.insert(0,str(MODEL))
from article2.model import Parameters, make_inputs, simulate, coefficients
from article2.experiment import SCHEMAS, write_csv, source_fingerprint, sha256_file
from article2.network import edge_list, graph_metrics

HASH='81e7fa14ba2700a2d5faef4acaaa024cc0a4cc3f10a342b5f3e581e94d2b7d1d'
SPECS=[('pws_000','p_WS',0.0),('pws_100','p_WS',1.0),
       ('qr_005','q_r',0.05),('qr_050','q_r',0.5),
       ('beta_050','beta',0.5),('beta_200','beta',2.0),
       ('s_005','S',5),('s_020','S',20),('a_005','a',0.05),('a_020','a',0.2)]
RUN_TABLES=('system_timeseries','seller_timeseries','commercial_edges','choice_candidates')


def now(): return datetime.now(timezone.utc).isoformat()


def read(folder,table):
    with (Path(folder)/(table+'.csv')).open(newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))


def dump(path,data): path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')


def seal(folder):
    dump(folder/'checksums.json',{p.name:sha256_file(p) for p in sorted(folder.iterdir()) if p.is_file() and p.name!='checksums.json'})


def verify_hashes(folder):
    for name,digest in json.loads((folder/'checksums.json').read_text()).items():
        assert sha256_file(folder/name)==digest,(folder,name)


def fingerprint(inp):
    def h(obj): return hashlib.sha256(json.dumps(obj,separators=(',',':')).encode()).hexdigest()
    return {'graph':h(edge_list(inp.graph)),'sellers':h(inp.sellers),'consumers':h(inp.consumers),
            'directed_edges':h(inp.directed_edges),'message':hashlib.sha256(inp.message.tobytes()).hexdigest(),
            'buy':hashlib.sha256(inp.buy.tobytes()).hexdigest(),'choice':hashlib.sha256(inp.choice.tobytes()).hexdigest()}


def prepare(destination,main):
    assert source_fingerprint()==HASH
    verify_hashes(main)
    meta=json.loads((main/'execution.json').read_text())
    assert meta['status']=='completed' and meta['completed_runs']==400 and meta['parameters']['T']==120
    assert meta['random_block_id']==200000 and meta['code_sha256']==HASH
    destination.mkdir(parents=True,exist_ok=False)
    configs=[dict(config_id='sens_'+name,parameter=key,value=value,new_runs=60 if key=='beta' else 120,reused_run_records=60 if key=='beta' else 0) for name,key,value in SPECS]
    plan={'registered_utc':now(),'model_version':'0.1.0','spec_version':'0.1','code_sha256':HASH,
          'T':120,'replicate_ids':list(range(1,31)),'random_block_id':200000,'base_parameters':meta['parameters'],
          'configurations':configs,'new_simulations':1080,'sensitivity_run_records':1200,
          'reused_beta_records':120,'unique_beta_source_runs':60,'baseline_records':120,
          'main_source_checksums_sha256':sha256_file(main/'checksums.json'),
          'bootstrap':{'seed':260927,'resamples':10000,'unit':'whole paired replicate','multiplicity_adjusted':False},
          'design':'one parameter at a time; exploratory local sensitivity, not global interaction analysis',
          'pairing':'A-D share inputs in each configuration. Across configs, q_r/beta/a retain graph, roles and all tapes; p_WS changes edge binding; S changes consumer indexing.',
          'replication_policy':'30 fixed replications for this screening; no extension based solely on significance. Unresolved effects remain uncertain.',
          'reference_networks':'Reuse the same 10 G(N,M) reference diagnostics per replicate (N=500,M=1500 remain fixed).'}
    dump(destination/'campaign_plan.json',plan)
    base=destination/'baseline30'; base.mkdir()
    ms=[m for m in read(main,'experiment_manifest') if int(m['replicate_id'])<=30]
    run_ids={m['run_id'] for m in ms}
    for table,fields in SCHEMAS.items():
        with (main/(table+'.csv')).open(newline='',encoding='utf-8') as f:
            rows=[r for r in csv.DictReader(f) if (r['run_id'] in run_ids if 'run_id' in fields else int(r['replicate_id'])<=30)]
        write_csv(base/(table+'.csv'),fields,rows)
    dump(base/'execution.json',{**meta,'repetitions':30,'completed_runs':120,'new_simulations':0,'reused_runs':120,'extracted_utc':now(),'source':'main_v01_T120','note':'Exact subset of original rows; original run IDs and phase retained.'})
    seal(base)
    fingerprints={str(r):fingerprint(make_inputs(Parameters(**meta['parameters']),200000,r)) for r in range(1,31)}
    dump(destination/'baseline_input_fingerprints.json',fingerprints)
    (destination/'configs').mkdir()
    for c in configs: dump(destination/'configs'/(c['config_id']+'.json'),{**meta['parameters'],c['parameter']:c['value']})
    dump(destination/'campaign_status.json',{'status':'prepared','new_simulations_completed':0,'completed_configurations':[],'plan_registered_utc':plan['registered_utc']})
    return plan


def run_one(destination,c):
    destination=Path(destination); base=destination/'baseline30'
    plan=json.loads((destination/'campaign_plan.json').read_text())
    assert source_fingerprint()==HASH
    p=Parameters(**{**plan['base_parameters'],c['parameter']:c['value']})
    cid=c['config_id']; folder=destination/cid; folder.mkdir()
    for table,fields in SCHEMAS.items(): write_csv(folder/(table+'.csv'),fields,[])
    def save(table,rows): write_csv(folder/(table+'.csv'),SCHEMAS[table],rows,append=True)
    base_man={(int(m['replicate_id']),m['scenario']):m for m in read(base,'experiment_manifest')}
    source={t:defaultdict(list) for t in RUN_TABLES}
    # Only beta variants need copied outcomes; keep other source loading bounded.
    if c['parameter']=='beta':
        for t in RUN_TABLES:
            for row in read(base,t): source[t][row['run_id']].append(row)
    diag=defaultdict(list)
    for row in read(base,'social_diagnostics'): diag[int(row['replicate_id'])].append(row)
    fps=json.loads((destination/'baseline_input_fingerprints.json').read_text())
    input_checks=[]; reuse_checks=[]
    meta={'phase':'sensitivity','repetitions':30,'scenarios':list('ABCD'),'random_block_id':200000,'config_id':cid,
          'parameters':asdict(p),'random_benchmarks_per_network':10,'model_version':'0.1.0','spec_version':'0.1',
          'python':sys.version,'platform':platform.platform(),'rng':'stdlib random.Random / MT19937',
          'code_sha256':HASH,'orchestrator_sha256':sha256_file(Path(__file__)),
          'started_utc':now(),'status':'running','calibrated':False,'new_simulations':0,'reused_runs':0,
          'reference_diagnostics_reused_from':'main_v01_T120',
          'beta_check_scope':'New C-D: individual awareness and adoption; cross-check against reused A-B: all awareness/adoption counts, individual purchases and first-awareness of adopters.' if c['parameter']=='beta' else 'Individual awareness and adoption across all four simulated scenarios.'}
    dump(folder/'execution.json',meta)
    try:
        for r in range(1,31):
            inp=make_inputs(p,200000,r); fp=fingerprint(inp); basefp=fps[str(r)]
            expected=('sellers','consumers','buy','choice') if c['parameter']=='p_WS' else ('graph','directed_edges','message') if c['parameter']=='S' else tuple(fp)
            assert all(fp[k]==basefp[k] for k in expected),(cid,r,'input pairing')
            input_checks.append({'replicate_id':r,'expected_identical':list(expected),'fingerprints':fp,'passed':True})
            keys={'config_id':cid,'random_block_id':200000,'replicate_id':r}
            save('agents',[{**keys,'agent_id':i,'role':'seller' if i in inp.sellers else 'consumer','social_degree':len(inp.graph[i])} for i in range(p.N)])
            save('social_edges',[{**keys,'source_id':u,'target_id':v} for u,v in edge_list(inp.graph)])
            ds=[{**row,**keys} for row in diag[r]]
            if c['parameter']=='p_WS':
                ds=[{**keys,'graph_type':'watts_strogatz','reference_id':0,'seed':inp.seeds['network'],**graph_metrics(inp.graph)}]+[row for row in ds if row['graph_type']=='gnm_reference']
            save('social_diagnostics',ds)
            baseline=None
            for scenario in 'ABCD':
                run=f'sensitivity_{cid}_b200000_r{r:04d}_{scenario}'
                reused=c['parameter']=='beta' and scenario in 'AB'
                source_id=base_man[r,scenario]['run_id'] if reused else None
                alpha,beta=coefficients(p,scenario)
                save('experiment_manifest',[{'run_id':run,'phase':'sensitivity',**keys,'scenario':scenario,**asdict(p),
                    'active_alpha':alpha,'active_beta':beta,'seed_customers':0,'external_visibility':0,
                    **{'seed_'+k:v for k,v in inp.seeds.items()},'source_run_id':source_id,
                    'model_version':'0.1.0','spec_version':'0.1','code_sha256':HASH,'python_version':platform.python_version(),'rng':'stdlib random.Random / MT19937'}])
                if reused:
                    for table in RUN_TABLES: save(table,[{**row,'run_id':run} for row in source[table][source_id]])
                    # Original paired identity check remains upstream provenance for copied A/B.
                    meta['reused_runs']+=1
                else:
                    result=simulate(p,scenario,inp,run)
                    for table,rows in zip(RUN_TABLES,(result.system,result.seller,result.commercial,result.candidates)): save(table,rows)
                    state=(result.awareness_period,result.adoption_period)
                    if baseline is None: baseline=state
                    assert state==baseline,(cid,r,scenario,'within configuration coupling')
                    if c['parameter']=='beta':
                        original=base_man[r,'A']['run_id']
                        old_times=source['system_timeseries'][original]
                        assert [(x['period'],x['aware_agents'],x['customers']) for x in old_times]==[(str(x['period']),str(x['aware_agents']),str(x['customers'])) for x in result.system]
                        assert result.adoption_period=={int(x['consumer_id']):int(x['adoption_period']) for x in source['commercial_edges'][original]}
                        first=defaultdict(lambda:10**9)
                        for x in source['choice_candidates'][original]: first[int(x['consumer_id'])]=min(first[int(x['consumer_id'])],int(x['first_known_period']))
                        assert all(result.awareness_period[i]==t for i,t in first.items())
                        reuse_checks.append({'replicate_id':r,'scenario':scenario,'source_run_id':original,'all_period_counts_equal':True,'individual_adoption_equal':True,'adopter_awareness_equal':True})
                    meta['new_simulations']+=1
                save('paired_checks',[{**keys,'scenario':scenario,'identical_awareness':1,'identical_adoption':1,'passed':1}])
            if r%10==0: print(f'{cid}: {r}/30 repetitions exported',flush=True)
        meta.update(status='completed',completed_runs=120,finished_utc=now())
        dump(folder/'input_pairing.json',input_checks); dump(folder/'reuse_cross_checks.json',reuse_checks)
    except Exception as e:
        meta.update(status='failed',error_type=type(e).__name__,error=str(e)); raise
    finally: dump(folder/'execution.json',meta)
    seal(folder)
    return {'config_id':cid,'new_simulations':meta['new_simulations'],'reused_runs':meta['reused_runs'],'status':meta['status']}


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--out',type=Path,required=True); parser.add_argument('--main',type=Path,required=True); parser.add_argument('--workers',type=int,default=3)
    args=parser.parse_args(); plan=prepare(args.out,args.main)
    status={'status':'running','started_utc':now(),'new_simulations_completed':0,'completed_configurations':[]}
    dump(args.out/'campaign_status.json',status)
    try:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures=[pool.submit(run_one,str(args.out.resolve()),c) for c in plan['configurations']]
            for future in as_completed(futures):
                result=future.result(); status['completed_configurations'].append(result); status['new_simulations_completed']+=result['new_simulations']; dump(args.out/'campaign_status.json',status); print(json.dumps(result),flush=True)
        assert status['new_simulations_completed']==1080
        status.update(status='completed',finished_utc=now()); dump(args.out/'campaign_status.json',status)
    except Exception as e:
        status.update(status='failed',error=str(e)); dump(args.out/'campaign_status.json',status); raise


if __name__=='__main__': main()
