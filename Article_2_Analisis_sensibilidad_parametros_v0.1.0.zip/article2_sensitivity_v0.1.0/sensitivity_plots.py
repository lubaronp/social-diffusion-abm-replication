"""Figures for paired sensitivity; normalized concentration allows changing S."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def make_plots(out,s,temporal):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    colors={'base':'#253D57','p_WS':'#345779','q_r':'#138985','beta':'#D27B30','S':'#8555A0','a':'#B65664'}
    specs={r['config_id']:r for r in s['configurations']}
    def c(cid,key): return next(r for r in s['contrasts'] if r['config_id']==cid and r['contrast']==key and r['metric']=='gini_normalized' and r['estimand']=='difference')
    fig,axes=plt.subplots(1,2,figsize=(11.7,7.3),sharey=True,layout='constrained')
    for ax,key,title in zip(axes,('C_minus_A','D_minus_B'),('C−A: éxito acumulado','D−B: éxito con proximidad')):
        for i,cid in enumerate(s['order']):
            r=c(cid,key); col=colors[specs[cid]['parameter']]
            ax.plot([r['ci95_low'],r['ci95_high']],[i,i],lw=2.5,color=col)
            ax.scatter([r['mean']],[i],s=42,color=col,zorder=3,marker='D' if cid=='baseline30' else 'o')
        ax.axvline(0,color='#A3A8AD',lw=1,ls='--')
        ax.axvline(c('baseline30',key)['mean'],color='#A3A8AD',lw=1,ls=':')
        ax.set(title=title,xlabel='Diferencia media de Gini normalizado',yticks=range(11),yticklabels=[s['labels'][cid] for cid in s['order']])
        ax.grid(axis='x',alpha=.17)
        ax.set_axisbelow(True)
    axes[0].invert_yaxis()
    fig.suptitle('Article 2 · Sensibilidad de los contrastes de concentración',fontsize=15,fontweight='bold')
    fig.supxlabel('30 repeticiones emparejadas · T=120 · IC bootstrap marginal 95 % · Línea punteada: base de los mismos 30 pares\nGini normalizado = Gini × S/(S−1). Una dimensión cambia a la vez; no se evalúan interacciones entre parámetros.',fontsize=9)
    save(fig,out,'Article_2_Sensibilidad_contrastes_v0.1.0'); plt.close(fig)

    fig,axes=plt.subplots(2,3,figsize=(13.7,8.0),layout='constrained')
    panels=[('Estructura de la red','sens_pws_000','sens_pws_100'),('Recomendación','sens_qr_005','sens_qr_050'),('Preferencia por éxito','sens_beta_050','sens_beta_200'),('Número de vendedores','sens_s_005','sens_s_020'),('Probabilidad de compra','sens_a_005','sens_a_020')]
    for ax,(title,lo,hi) in zip(axes.flat,panels):
        for cid,col,ls in [('baseline30','#8A9299','--'),(lo,'#345779','-'),(hi,'#D27B30','-')]:
            rows=[r for r in temporal if r['config_id']==cid and r['scenario']=='A' and r['metric']=='coverage']
            ax.plot([r['period'] for r in rows],[100*r['mean'] for r in rows],label=s['labels'][cid],color=col,ls=ls,lw=2)
        ax.set(title=title,xlabel='Periodo abstracto',ylabel='Cobertura media (%)',ylim=(0,103),xlim=(0,120))
        ax.legend(frameon=False,fontsize=8,loc='lower right')
        ax.grid(axis='y',alpha=.17)
        if lo=='sens_beta_050': ax.text(.05,.88,'Las tres curvas coinciden',transform=ax.transAxes,fontsize=8,color='#45515C')
    ax=axes.flat[5]
    for scenario,col in zip('ABCD',('#345779','#138985','#D27B30','#8555A0')):
        values=[next(r['mean'] for r in s['scenarios'] if r['config_id']==cid and r['scenario']==scenario and r['metric']=='gini_normalized') for cid in ('sens_s_005','baseline30','sens_s_020')]
        ax.plot([5,10,20],values,label=scenario,color=col,lw=2,marker='o')
    ax.set(title='Concentración al variar vendedores',xlabel='Número de vendedores',ylabel='Gini normalizado medio en T=120',xticks=[5,10,20],ylim=(0,1))
    ax.legend(frameon=False,fontsize=8,ncol=2); ax.grid(axis='y',alpha=.17)
    fig.suptitle('Article 2 · Cobertura y escala de la concentración',fontsize=15,fontweight='bold')
    fig.supxlabel('La cobertura coincide entre A–D dentro de cada configuración · Curvas medias sobre los mismos 30 índices de repetición\nLos resultados al periodo 120 no implican absorción completa: p_WS=0 y a=0,05 conservan compras pendientes.',fontsize=9)
    save(fig,out,'Article_2_Sensibilidad_dinamica_v0.1.0'); plt.close(fig)


def save(fig,out,name):
    fig.savefig(out/(name+'.png'),dpi=180)
    fig.savefig(out/(name+'.svg'))
