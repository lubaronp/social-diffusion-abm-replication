# Article 2 — Campaña de sensibilidad de parámetros v0.1.0

Diez configuraciones, una dimensión a la vez, T=120, 30 repeticiones emparejadas (índices 1–30 del bloque principal 200000). El motor `article2` v0.1.0 permanece sin cambios.

## Diseño y contabilidad

- p_WS: 0 y 1; q_r: 0,05 y 0,50; beta: 0,5 y 2; S: 5 y 20; a: 0,05 y 0,20.
- 1080 simulaciones nuevas.
- 120 registros de escenario reutilizados en las variaciones de beta (A y B, 30 pares por configuración), que representan 60 ejecuciones originales distintas.
- 120 registros adicionales de referencia base30, extraídos del principal. Incluyen los 60 orígenes A/B anteriores.
- 1320 registros en las tablas de análisis; unidad de remuestreo: 30 índices de repetición, no 1320 observaciones independientes.
- El subconjunto base conserva los identificadores y las filas originales. `source_run_id` identifica las reutilizaciones beta. `reuse_ledger.csv` registra todos los orígenes.

Se conservan roles/red/tablas uniformes al variar q_r, beta o a. Cambiar p_WS altera los enlaces a los que se asignan los sorteos; cambiar S altera la indexación de consumidores. Entre esas configuraciones estructurales el emparejamiento es por índice de semilla, no por identidad de todos los sorteos por persona/enlace. En p_WS=0 la topología es determinista, aunque cambian ubicaciones de vendedores y sorteos entre repeticiones.

Los diez G(N,M) por repetición se reutilizan de la base porque N y M permanecen fijos. El plan con fecha anterior a la ejecución documenta las configuraciones y el alcance de los intervalos. No se incorporan datos del piloto ni se modifica el principal completo.

## Archivos necesarios y reproducción

Extraer en una misma carpeta:

1. `Article_2_Codigo_v0.1.0.zip`: motor original y auditor de exportaciones.
2. `Article_2_Datos_sensibilidad_parametros_v0.1.0.zip`: resultados de esta campaña, incluida la referencia base30.
3. `Article_2_Analisis_sensibilidad_parametros_v0.1.0.zip`: este directorio, scripts y resultados derivados.

Para regenerar las simulaciones se necesitan también los datos completos originales de `Article_2_Datos_principal_T120_v0.1.0.zip`. Python 3.12.14; la simulación, auditorías y estadística usan biblioteca estándar. Matplotlib 3.10.8 se usa para las figuras. Los tres procesos de trabajo escriben configuraciones independientes; su orden de finalización no afecta las semillas o los resultados.

Desde la carpeta que contiene los proyectos, para repetir la campaña:

```bash
python3 article2_sensitivity_v0.1.0/run_campaign.py --main article2_model_v0.1.0/outputs/main_v01_T120 --out article2_model_v0.1.0/outputs/sensitivity_parameters_reproduced --workers 3
python3 article2_sensitivity_v0.1.0/audit_campaign.py article2_model_v0.1.0/outputs/sensitivity_parameters_reproduced --workers 3
```

Para volver a analizar los datos archivados sin simular:

```bash
python3 article2_sensitivity_v0.1.0/analyze_sensitivity.py --root article2_model_v0.1.0/outputs/sensitivity_parameters_v01 --out article2_sensitivity_v0.1.0/results_reproduced
python3 article2_sensitivity_v0.1.0/build_report.py article2_sensitivity_v0.1.0/results_reproduced
```

Los destinos de ejecución, análisis y auditoría deben ser nuevos. El código rechaza sobrescribirlos. `build_report.py` está vinculado a esta campaña y comprueba que las afirmaciones resumidas de los contrastes principales coincidan con sus intervalos; no es una plantilla genérica para otros parámetros.

## Auditorías

`audit_campaign.py` aplica el auditor independiente original a las diez configuraciones y a base30, verifica parámetros/coeficientes/semillas contra el plan, comprueba las medidas normalizadas y compara exactamente las filas reutilizadas, salvo el identificador de ejecución.

`input_pairing.json` registra huellas de grafo, roles, orden de consumidores/enlaces y tablas uniformes. El organizador verifica las identidades esperadas antes de simular. Para las configuraciones beta, el alcance de `paired_checks.csv` está precisado en `execution.json`: A–B remiten a controles originales; C–D se comparan individualmente; frente a A–B reutilizados se comparan todas las cuentas temporales, compras individuales y primeros conocimientos de compradores. No se reconstruyen los tiempos individuales de conocimiento de los no compradores del principal, porque no están exportados.

Las huellas de las tablas de números usan bytes de `array('d')` en el entorno registrado. Para una reproducción en otra arquitectura, interpretar esa comprobación de bytes con la representación numérica de la plataforma.

## Tablas de análisis

- `run_diagnostics.csv`: por configuración, repetición y escenario; concentración original y normalizada, cobertura, oportunidades de elección y compras pendientes.
- `scenario_summary.csv`: estadísticas entre repeticiones. Cada repetición tiene igual peso.
- `paired_differences.csv`: contrastes C−A, D−B, B−A, D−C e interacción, en Gini original y normalizado. `change_vs_base30` es la diferencia entre el contraste de cada configuración y el de la misma repetición base.
- `contrast_summary.csv`: medias, dispersión, signos, error Monte Carlo e intervalos percentiles. `estimand=difference` resume el contraste; `estimand=change_vs_base30` resume su cambio respecto a la base.
- `configuration_summary.csv`: cobertura y conectividad por configuración. La difusión común A–D se cuenta una vez por repetición.
- `temporal_summary.csv`: medias por periodo; `n` indica las observaciones con métrica definida. Tiempos de compra, si no se alcanza el umbral, se guardan como NA.
- `reuse_ledger.csv`: cada ejecución nueva y cada referencia reutilizada.
- `network_diagnostics.csv`: red social y referencias; distancias en el mayor componente.
- `sensitivity_summary.json`, informe, guía y figuras PNG/SVG.

Gini normalizado = Gini × S/(S−1). Cuota mayor normalizada = (cuota−1/S)/(1−1/S). Ajustan los límites de las medidas, sin eliminar diferencias estructurales entre tamaños. Las concentraciones indefinidas se conservan como NA, no como cero.

Bootstrap: 10000 remuestreos de los 30 índices completos, semilla 260927, mismos índices para escenarios/configuraciones. Intervalos marginales del 95 %, sin ajuste por multiplicidad. No se trata de análisis global ni de interacción entre parámetros. La fotografía al periodo 120 no implica cobertura completa; especialmente p_WS=0 y a=0,05 requieren esa aclaración.
