"""Paired one-factor analysis of ten settings and the same 30 baseline replicates."""
import argparse
from collections import defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import statistics as st
from run_campaign import read, dump

LABELS={'baseline30':'Base (30 pares)','sens_pws_000':'p_WS = 0','sens_pws_100':'p_WS = 1',
        'sens_qr_005':'q_r = 0,05','sens_qr_050':'q_r = 0,50','sens_beta_050':'β = 0,5','sens_beta_200':'β = 2',
        'sens_s_005':'S = 5','sens_s_020':'S = 20','sens_a_005':'a = 0,05','sens_a_020':'a = 0,20'}


def write(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n'); w.writeheader()
        w.writerows({k:'NA' if v is None else v for k,v in r.items()} for r in rows)


def quantile(values,p):
    x=sorted(values); i=(len(x)-1)*p
    return x[math.floor(i)]+(i-math.floor(i))*(x[math.ceil(i)]-x[math.floor(i)])


def stats(values):
    v=[x for x in values if x is not None]
    if not v: return dict(n=0,mean=None,sd=None,median=None,min=None,max=None)
    return dict(n=len(v),mean=st.mean(v),sd=st.stdev(v) if len(v)>1 else 0,median=st.median(v),min=min(v),max=max(v))


def difference(g):
    if any(g[s] is None for s in 'ABCD'): return {k:None for k in ('C_minus_A','D_minus_B','B_minus_A','D_minus_C','interaction')}
    return {'C_minus_A':g['C']-g['A'],'D_minus_B':g['D']-g['B'],'B_minus_A':g['B']-g['A'],'D_minus_C':g['D']-g['C'],'interaction':(g['D']-g['B'])-(g['C']-g['A'])}


def analyze(root,out):
    audit=json.loads((root/'audit_summary.json').read_text()); assert audit['status']=='passed'
    plan=json.loads((root/'campaign_plan.json').read_text())
    campaign=json.loads((root/'campaign_status.json').read_text()); assert campaign['status']=='completed'
    out.mkdir(parents=True,exist_ok=False)
    order=['baseline30']+[c['config_id'] for c in plan['configurations']]
    config_specs={c['config_id']:c for c in plan['configurations']}
    runs=[]; temporal=[]; networks=[]; ledger=[]
    for cid in order:
        folder=root/cid; ms=read(folder,'experiment_manifest'); sy=defaultdict(dict); candidates=defaultdict(lambda:defaultdict(list))
        for r in read(folder,'system_timeseries'): sy[r['run_id']][int(r['period'])]=r
        for r in read(folder,'choice_candidates'): candidates[r['run_id']][int(r['consumer_id'])].append(r)
        for m in ms:
            run=m['run_id']; series=sy[run]; last=series[120]; groups=list(candidates[run].values()); total=int(last['customers'])
            def val(key,t=120): return None if series[t][key]=='NA' else float(series[t][key])
            assert len(groups)==total
            mixed=sum(len({r['direct_tie'] for r in g})>1 for g in groups)
            row={'config_id':cid,'label':LABELS[cid],'replicate_id':int(m['replicate_id']),'scenario':m['scenario'],'run_id':run,'S':int(m['S']),
                 'gini':val('customer_gini'),'gini_normalized':val('gini_normalized'),'largest_share':val('largest_share'),'largest_share_normalized':val('largest_share_normalized'),
                 'coverage':val('coverage'),'aware_share':val('aware_share'),'customers':total,'remaining_consumers':int(m['N'])-int(m['S'])-total,
                 'new_customers_last10':total-int(series[110]['customers']),'coverage_gain_last10':val('coverage')-val('coverage',110),
                 'gini_change_last10':val('customer_gini')-val('customer_gini',110) if val('customer_gini') is not None and val('customer_gini',110) is not None else None,
                 'multi_choice_share':val('multi_choice_share'),'mixed_proximity_share':mixed/total if total else None,
                 'varied_success_share':sum(len({r['previous_customers'] for r in g})>1 for g in groups)/total if total else None,
                 't95':next((t for t,r in sorted(series.items()) if float(r['coverage'])>=.95),None),
                 't100':next((t for t,r in sorted(series.items()) if float(r['coverage'])==1),None)}
            runs.append(row)
            ledger.append({'config_id':cid,'replicate_id':int(m['replicate_id']),'scenario':m['scenario'],'run_id':run,
                           'origin':'existing_main' if cid=='baseline30' or m['source_run_id']!='NA' else 'new_sensitivity',
                           'source_run_id':run if cid=='baseline30' else m['source_run_id']})
        assert len(ms)==120
        for t in range(121):
            for scenario in 'ABCD':
                group=[m for m in ms if m['scenario']==scenario]
                for metric in ('coverage','customer_gini'):
                    vals=[float(sy[m['run_id']][t][metric]) for m in group if sy[m['run_id']][t][metric]!='NA']
                    temporal.append({'config_id':cid,'scenario':scenario,'period':t,'metric':metric,**stats(vals)})
        ds=defaultdict(list)
        for d in read(folder,'social_diagnostics'): ds[int(d['replicate_id'])].append(d)
        for rep,group in ds.items():
            social=next(d for d in group if d['graph_type']=='watts_strogatz'); ref=[d for d in group if d['graph_type']=='gnm_reference']
            cr=st.mean(float(d['mean_local_clustering']) for d in ref); lr=st.mean(float(d['mean_path_length_lcc']) for d in ref)
            networks.append({'config_id':cid,'replicate_id':rep,'components':int(social['components']),'lcc_share':float(social['largest_component_share']),
                'clustering':float(social['mean_local_clustering']),'path_lcc':float(social['mean_path_length_lcc']),
                'reference_clustering_mean':cr,'reference_path_mean':lr,'clustering_ratio':float(social['mean_local_clustering'])/cr,
                'path_ratio':float(social['mean_path_length_lcc'])/lr,'reference_min_lcc_share':min(float(d['largest_component_share']) for d in ref)})
    write(out/'run_diagnostics.csv',runs); write(out/'reuse_ledger.csv',ledger); write(out/'temporal_summary.csv',temporal); write(out/'network_diagnostics.csv',networks)
    keyed={(r['config_id'],r['replicate_id'],r['scenario']):r for r in runs}
    metrics=['gini','gini_normalized','largest_share','largest_share_normalized','coverage','aware_share','remaining_consumers','new_customers_last10','coverage_gain_last10','gini_change_last10','multi_choice_share','mixed_proximity_share','varied_success_share']
    scenarios=[{'config_id':cid,'scenario':s,'metric':k,**stats([keyed[cid,r,s][k] for r in range(1,31)])} for cid in order for s in 'ABCD' for k in metrics]
    write(out/'scenario_summary.csv',scenarios)
    paired=[]; contrast_keys=('C_minus_A','D_minus_B','B_minus_A','D_minus_C','interaction')
    for cid in order:
        for rep in range(1,31):
            for metric in ('gini','gini_normalized'):
                d=difference({s:keyed[cid,rep,s][metric] for s in 'ABCD'})
                b=difference({s:keyed['baseline30',rep,s][metric] for s in 'ABCD'})
                for k in contrast_keys:
                    paired.append({'config_id':cid,'replicate_id':rep,'metric':metric,'contrast':k,'difference':d[k],
                                   'change_vs_base30':d[k]-b[k] if d[k] is not None and b[k] is not None else None})
    write(out/'paired_differences.csv',paired)
    rng=random.Random(260927); draws=[[rng.randrange(30) for _ in range(30)] for _ in range(10000)]
    grouped=defaultdict(list)
    for r in paired: grouped[r['config_id'],r['metric'],r['contrast']].append(r)
    summaries=[]
    for key,rs in grouped.items():
        rs.sort(key=lambda r:r['replicate_id'])
        for estimand in ('difference','change_vs_base30'):
            values=[r[estimand] for r in rs]
            valid=[v for v in values if v is not None]
            if len(valid)==30:
                bs=[sum(values[i] for i in inds)/30 for inds in draws]
                lo,hi=quantile(bs,.025),quantile(bs,.975)
            else:
                # Retain conditioning explicitly; no undefined-Gini values are replaced by zero.
                local=random.Random(260927)
                bs=[sum(local.choice(valid) for _ in valid)/len(valid) for _ in range(10000)] if valid else []
                lo,hi=(quantile(bs,.025),quantile(bs,.975)) if bs else (None,None)
            summaries.append({'config_id':key[0],'metric':key[1],'contrast':key[2],'estimand':estimand,**stats(valid),
                'ci95_low':lo,'ci95_high':hi,'positive_pairs':sum(v>0 for v in valid),'zero_pairs':sum(v==0 for v in valid),'negative_pairs':sum(v<0 for v in valid),
                'monte_carlo_se':st.stdev(valid)/math.sqrt(len(valid)) if len(valid)>1 else None})
    write(out/'contrast_summary.csv',summaries)
    configs=[]
    for cid in order:
        rs=[keyed[cid,r,'A'] for r in range(1,31)]
        ns=[n for n in networks if n['config_id']==cid]
        configs.append({'config_id':cid,'label':LABELS[cid],
            'parameter':config_specs[cid]['parameter'] if cid in config_specs else 'base',
            'value':config_specs[cid]['value'] if cid in config_specs else None,
            'new_runs':config_specs[cid]['new_runs'] if cid in config_specs else 0,
            'no_adoption_runs':sum(r['customers']==0 for r in runs if r['config_id']==cid),
            'coverage_mean':st.mean(r['coverage'] for r in rs),'coverage_min':min(r['coverage'] for r in rs),
            'full_adoption_replicates':sum(r['remaining_consumers']==0 for r in rs),
            'remaining_mean':st.mean(r['remaining_consumers'] for r in rs),
            'new_customers_last10_mean':st.mean(r['new_customers_last10'] for r in rs),
            'coverage_gain_last10_mean':st.mean(r['coverage_gain_last10'] for r in rs),
            'connected_networks':sum(n['components']==1 for n in ns),
            'clustering_mean':st.mean(n['clustering'] for n in ns),'path_lcc_mean':st.mean(n['path_lcc'] for n in ns)})
    write(out/'configuration_summary.csv',configs)
    assert sum(r['origin']=='new_sensitivity' for r in ledger)==1080
    assert len({r['source_run_id'] for r in ledger if r['origin']=='existing_main'})==120
    summary={'model_version':'0.1.0','T':120,'new_simulations':1080,'sensitivity_records':1200,'baseline_records':120,'independent_seed_replicates':30,
             'labels':LABELS,'order':order,'plan':plan,'audit':audit,'campaign':campaign,'configurations':configs,'scenarios':scenarios,'contrasts':summaries,
             'bootstrap':{'seed':260927,'resamples':10000,'method':'paired percentile; common replicate indices across configurations and contrasts; marginal unadjusted intervals'},
             'all_metrics_defined':all(r['gini'] is not None for r in runs)}
    dump(out/'sensitivity_summary.json',summary)
    from sensitivity_plots import make_plots
    make_plots(out,summary,temporal)
    return summary


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--root',type=Path,required=True); parser.add_argument('--out',type=Path,required=True); a=parser.parse_args()
    s=analyze(a.root,a.out); print(json.dumps({'configurations':s['configurations'],'all_metrics_defined':s['all_metrics_defined']},indent=2))
