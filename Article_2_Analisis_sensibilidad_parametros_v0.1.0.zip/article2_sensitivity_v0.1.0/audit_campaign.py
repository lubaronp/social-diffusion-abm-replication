"""Audit every configuration using the original independent export auditor."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from collections import defaultdict
from datetime import datetime
import json
import math
from pathlib import Path
import sys
from run_campaign import MODEL, HASH, RUN_TABLES, read, dump, coefficients, Parameters
sys.path.insert(0,str(MODEL))
from audit_outputs import audit


def audit_one(root,c):
    root=Path(root); cid=c['config_id']; folder=root/cid
    result=audit(folder)
    plan=json.loads((root/'campaign_plan.json').read_text())
    meta=json.loads((folder/'execution.json').read_text())
    assert datetime.fromisoformat(meta['started_utc'])>datetime.fromisoformat(plan['registered_utc'])
    assert result['runs']==120 and meta['new_simulations']==c['new_runs'] and meta['reused_runs']==c['reused_run_records']
    p=Parameters(**{**plan['base_parameters'],c['parameter']:c['value']})
    ms=read(folder,'experiment_manifest')
    assert {(int(m['replicate_id']),m['scenario']) for m in ms}=={(r,s) for r in range(1,31) for s in 'ABCD'}
    base_ms={(int(m['replicate_id']),m['scenario']):m for m in read(root/'baseline30','experiment_manifest')}
    reused=[]
    for m in ms:
        assert m['code_sha256']==HASH and m['phase']=='sensitivity' and m['config_id']==cid
        for k,v in vars(p).items(): assert float(m[k])==v
        alpha,beta=coefficients(p,m['scenario']); assert float(m['active_alpha'])==alpha and float(m['active_beta'])==beta
        for j,stage in enumerate(('network','roles','message','buy','choice')): assert int(m['seed_'+stage])==200000+10*int(m['replicate_id'])+j
        if c['parameter']=='beta' and m['scenario'] in 'AB':
            assert m['source_run_id']==base_ms[int(m['replicate_id']),m['scenario']]['run_id']; reused.append(m)
        else: assert m['source_run_id']=='NA'
    assert all(r['passed']=='1' for r in read(folder,'paired_checks'))
    reuse_rows=0
    if reused:
        for table in RUN_TABLES:
            original=defaultdict(list); copied=defaultdict(list)
            for row in read(root/'baseline30',table): original[row['run_id']].append({k:v for k,v in row.items() if k!='run_id'})
            for row in read(folder,table): copied[row['run_id']].append({k:v for k,v in row.items() if k!='run_id'})
            for m in reused:
                assert copied[m['run_id']]==original[m['source_run_id']],(cid,table,m['run_id'])
                reuse_rows+=len(copied[m['run_id']])
    normalized_rows=0
    for row in read(folder,'system_timeseries'):
        if row['metric_status']=='defined':
            assert math.isclose(float(row['gini_normalized']),float(row['customer_gini'])*p.S/(p.S-1),abs_tol=1e-12)
            assert math.isclose(float(row['largest_share_normalized']),(float(row['largest_share'])-1/p.S)/(1-1/p.S),abs_tol=1e-12)
            normalized_rows+=1
        else: assert row['gini_normalized']==row['largest_share_normalized']=='NA'
    result.update(config_id=cid,new_simulations=meta['new_simulations'],reused_runs=len(reused),exact_reuse_rows=reuse_rows,normalized_metric_rows_checked=normalized_rows,design_matches_plan=True,input_fingerprints_verified=True)
    dump(root/'audits'/(cid+'.json'),result)
    return result


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('root',type=Path); parser.add_argument('--workers',type=int,default=3); args=parser.parse_args()
    (args.root/'audits').mkdir()
    base_result=audit(args.root/'baseline30'); dump(args.root/'audits'/'baseline30.json',base_result)
    configs=json.loads((args.root/'campaign_plan.json').read_text())['configurations']; results=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(audit_one,str(args.root.resolve()),c) for c in configs]
        for future in as_completed(futures):
            r=future.result(); results.append(r); print(r['config_id'],r['status'],flush=True)
    results.sort(key=lambda r:next(i for i,c in enumerate(configs) if c['config_id']==r['config_id']))
    summary={'status':'passed','configurations':10,'new_simulations':sum(r['new_simulations'] for r in results),
             'sensitivity_run_records':sum(r['runs'] for r in results),'reused_beta_records':sum(r['reused_runs'] for r in results),
             'baseline_records':120,'independent_seed_replicates':30,'raw_assertions_passed':sum(r['assertions_passed'] for r in results),
             'exact_reused_rows':sum(r['exact_reuse_rows'] for r in results),'baseline_audit':base_result,'configuration_audits':results}
    dump(args.root/'audit_summary.json',summary); print(json.dumps({k:v for k,v in summary.items() if k not in ('baseline_audit','configuration_audits')},indent=2))


if __name__=='__main__': main()
