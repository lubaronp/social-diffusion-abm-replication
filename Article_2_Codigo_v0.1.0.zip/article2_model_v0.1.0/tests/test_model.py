import csv
from dataclasses import replace
import io
import json
import math
from pathlib import Path
import tempfile
import unittest
from contextlib import redirect_stdout

from article2.model import Parameters, make_inputs, simulate, probabilities, categorical, concentration
from article2.network import graph_from_edges, watts_strogatz, edge_list, graph_metrics, gnm_random
from article2.experiment import run_experiment, load_parameters, sha256_file


SMALL = Parameters(N=30, S=3, k=4, T=12, q_s=.6, q_r=.5, a=.4)


class NetworkTests(unittest.TestCase):
    def test_ring_has_analytic_degree_and_clustering(self):
        """Anillo N=20, k=4: todos los grados 4 y agrupamiento medio 0.5."""
        graph = watts_strogatz(20, 4, 0, 1)
        self.assertEqual([len(ns) for ns in graph], [4] * 20)
        self.assertAlmostEqual(graph_metrics(graph)["mean_local_clustering"], .5)

    def test_rewiring_preserves_simple_graph_and_edges(self):
        """Reconexión p=0,0.1,1 preserva N*k/2, simetría y ausencia de bucles."""
        for seed in range(5):
            for p in (0, .1, 1):
                graph = watts_strogatz(30, 6, p, seed)
                self.assertEqual(len(edge_list(graph)), 90)
                for u, ns in enumerate(graph):
                    self.assertNotIn(u, ns)
                    for v in ns:
                        self.assertIn(u, graph[v])

    def test_complete_ring_does_not_hang(self):
        """Red completa sin destinos disponibles conserva sus diez enlaces."""
        self.assertEqual(len(edge_list(watts_strogatz(5, 4, 1, 7))), 10)

    def test_path_metrics_have_known_values(self):
        """Ciclo de cuatro nodos: distancia 4/3, diámetro 2, agrupamiento 0."""
        metrics = graph_metrics(graph_from_edges(4, [(0, 1), (1, 2), (2, 3), (3, 0)]))
        self.assertAlmostEqual(metrics["mean_path_length_lcc"], 4 / 3)
        self.assertEqual(metrics["diameter_lcc"], 2)
        self.assertEqual(metrics["mean_local_clustering"], 0)

    def test_triangle_and_isolate_metrics(self):
        """Triángulo y aislado: C medio 0.75, L del componente mayor 1, cuota 0.75."""
        metrics = graph_metrics(graph_from_edges(4, [(0, 1), (1, 2), (0, 2)]))
        self.assertEqual(metrics["components"], 2)
        self.assertEqual(metrics["mean_local_clustering"], .75)
        self.assertEqual(metrics["mean_path_length_lcc"], 1)
        self.assertEqual(metrics["largest_component_share"], .75)

    def test_gnm_edge_count_and_reproducibility(self):
        """Referencias G(N,M) preservan M para redes vacías, dispersas y completas."""
        for m in (0, 10, 45):
            first = gnm_random(10, m, 34)
            self.assertEqual(len(edge_list(first)), m)
            self.assertEqual(first, gnm_random(10, m, 34))

    def test_invalid_graphs_rejected(self):
        """Bucles, duplicados y extremos inexistentes se rechazan."""
        for edges in ([(0, 0)], [(0, 1), (1, 0)], [(0, 8)]):
            with self.assertRaises(ValueError):
                graph_from_edges(4, edges)


class ChoiceTests(unittest.TestCase):
    def test_specification_numeric_example(self):
        """Caso manual: A=(1/2,1/2), B=(2/3,1/3), C=(1/5,4/5), D=(1/3,2/3)."""
        for alpha, beta, expected in [(0, 0, [.5, .5]), (math.log(2), 0, [2/3, 1/3]),
                                      (0, 1, [.2, .8]), (math.log(2), 1, [1/3, 2/3])]:
            _, actual = probabilities([0, 3], [1, 0], alpha, beta)
            for a, e in zip(actual, expected):
                self.assertAlmostEqual(a, e)

    def test_random_choice_ignores_success_and_proximity(self):
        """A da probabilidad 1/3 aunque éxito y proximidad sean diferentes."""
        _, actual = probabilities([0, 10, 1000], [0, 1, 0], 0, 0)
        for p in actual:
            self.assertAlmostEqual(p, 1/3)

    def test_proximity_ignores_success(self):
        """B mantiene peso doble para contacto directo al intercambiar los conteos."""
        first = probabilities([0, 1000], [1, 0], math.log(2), 0)[1]
        second = probabilities([1000, 0], [1, 0], math.log(2), 0)[1]
        self.assertEqual(first, second)
        self.assertAlmostEqual(first[0] / first[1], 2)

    def test_success_monotonic_and_equal_success_reduction(self):
        """C favorece mayor éxito; igual éxito reduce C a A y D a B."""
        self.assertGreater(probabilities([0, 9], [0, 0], 0, 1)[1][1], .5)
        self.assertEqual(probabilities([8, 8], [1, 0], 0, 1)[1], [.5, .5])
        for p, expected in zip(probabilities([8, 8], [1, 0], math.log(2), 1)[1], [2/3, 1/3]):
            self.assertAlmostEqual(p, expected)

    def test_single_candidate_and_probability_bounds(self):
        """Un candidato tiene probabilidad 1; probabilidades múltiples suman 1."""
        self.assertEqual(probabilities([0], [0], 10, 10)[1], [1])
        _, actual = probabilities([0, 1, 1000000], [0, 1, 0], 2, 2)
        self.assertTrue(all(0 < p <= 1 for p in actual))
        self.assertAlmostEqual(math.fsum(actual), 1)

    def test_categorical_intervals(self):
        """Diez uniformes equiespaciados generan exactamente 2 y 8 elecciones."""
        outcomes = [categorical([.2, .8], (i + .5) / 10) for i in range(10)]
        self.assertEqual(outcomes.count(0), 2)
        self.assertEqual(outcomes.count(1), 8)
        self.assertEqual(categorical([.2, .8], .2), 1)

    def test_invalid_choice_inputs_rejected(self):
        """Alternativas vacías, conteos negativos y coeficientes inválidos se rechazan."""
        for counts, direct, alpha, beta in [([], [], 0, 0), ([-1], [0], 0, 1),
                                            ([0], [2], 0, 1), ([0], [0], -1, 1)]:
            with self.assertRaises(ValueError):
                probabilities(counts, direct, alpha, beta)

    def test_gini_known_cases_and_zero_adoption(self):
        """Gini: igualdad=0, monopolio entre diez=0.9, sin clientes=NA."""
        self.assertEqual(concentration([1]*10)["customer_gini"], 0)
        self.assertAlmostEqual(concentration([10]+[0]*9)["customer_gini"], .9)
        self.assertEqual(concentration([10]+[0]*9)["gini_normalized"], 1)
        self.assertIsNone(concentration([0]*10)["customer_gini"])
        self.assertEqual(concentration([0]*10)["metric_status"], "no_adoption")


class DynamicsTests(unittest.TestCase):
    def fixture_chain(self, **changes):
        p = Parameters(N=4, S=2, k=2, T=4, q_s=1, q_r=1, a=1)
        p = replace(p, **changes)
        inp = make_inputs(p, graph=graph_from_edges(4, [(0, 1), (1, 2)]), sellers=(0, 3), constant=0)
        return p, inp

    def test_referral_delay_and_saturation(self):
        """Cadena: compras en t=1 y t=2; t=3 y t=4 quedan constantes."""
        p, inp = self.fixture_chain()
        result = simulate(p, "A", inp, record_messages=True)
        self.assertEqual(result.adoption_period, {1: 1, 2: 2})
        self.assertEqual([row["new_customers"] for row in result.system], [0, 1, 1, 0, 0])
        self.assertEqual(len(result.system), p.T + 1)
        self.assertEqual(result.system[-1]["coverage"], 1)

    def test_no_communication_no_awareness_or_purchase(self):
        """q_s=q_r=0: nadie se informa o compra, incluso con a=1."""
        p, inp = self.fixture_chain(q_s=0, q_r=0)
        result = simulate(p, "D", inp)
        self.assertEqual(result.awareness_period, {})
        self.assertEqual(result.commercial, [])
        self.assertTrue(all(row["metric_status"] == "no_adoption" for row in result.system))

    def test_no_purchase_informed_consumers_do_not_forward(self):
        """a=0: el vecino directo se informa, no compra ni transmite al siguiente."""
        p, inp = self.fixture_chain(a=0)
        result = simulate(p, "A", inp, record_messages=True)
        self.assertEqual(result.awareness_period, {1: 1})
        self.assertEqual(result.commercial, [])
        self.assertTrue(all(row["sender_id"] == 0 for row in result.messages))

    def test_no_referrals_restricts_reach(self):
        """q_r=0: solo el vecino directo del vendedor puede comprar."""
        p, inp = self.fixture_chain(q_r=0)
        result = simulate(p, "D", inp)
        self.assertEqual(result.assignments, {1: 0})
        self.assertEqual(result.known_sellers[2], ())

    def test_disconnected_network_is_retained(self):
        """Componente sin vendedor permanece desinformado; no se regenera la red."""
        p = Parameters(N=6, S=2, k=2, T=4, q_s=1, q_r=1, a=1)
        graph = graph_from_edges(6, [(0,1), (1,2), (3,4)])
        inp = make_inputs(p, graph=graph, sellers=(0,5), constant=0)
        result = simulate(p, "A", inp)
        self.assertEqual(set(result.assignments), {1,2})
        self.assertEqual(inp.graph, graph)

    def test_known_sellers_persist_without_purchase(self):
        """Información recibida en t=1 permite comprar en t=3 sin nuevos mensajes."""
        p, inp = self.fixture_chain(T=3, q_s=.5, a=.5)
        m, c = len(inp.directed_edges), len(inp.consumers)
        for i in range(m, len(inp.message)):
            inp.message[i] = .9
        for i in range(2*c):
            inp.buy[i] = .9
        result = simulate(p, "A", inp)
        self.assertEqual(result.adoption_period, {1: 3})

    def test_choice_uses_previous_period_counts(self):
        """Dos compras simultáneas usan conteos cero y probabilidades 1/2 cada una."""
        p = Parameters(N=4, S=2, k=2, T=1, q_s=1, q_r=1, a=1)
        graph = graph_from_edges(4, [(0,1), (0,2), (3,1), (3,2)])
        inp = make_inputs(p, graph=graph, sellers=(0,3), constant=0)
        inp.choice[0], inp.choice[1] = .6, .4
        result = simulate(p, "C", inp)
        self.assertEqual(result.assignments, {1: 3, 2: 0})
        self.assertTrue(all(row["probability"] == .5 and row["previous_customers"] == 0 for row in result.candidates))

    def test_reverse_processing_order_has_no_effect(self):
        """Invertir orden de compradores preserva todos los resultados registrados."""
        inp = make_inputs(SMALL)
        for scenario in "ABCD":
            forward = simulate(SMALL, scenario, inp)
            reverse = simulate(SMALL, scenario, inp, reverse_order=True)
            self.assertEqual(forward, reverse)

    def test_awareness_and_adoption_coupled_across_scenarios(self):
        """A-D comparten identidades y períodos de conocimiento y compra en cinco semillas."""
        for replicate in range(1,6):
            inp = make_inputs(SMALL, replicate=replicate)
            baseline = simulate(SMALL, "A", inp)
            for scenario in "BCD":
                result = simulate(SMALL, scenario, inp)
                self.assertEqual(result.awareness_period, baseline.awareness_period)
                self.assertEqual(result.adoption_period, baseline.adoption_period)

    def test_zero_preferences_make_all_scenarios_identical(self):
        """Con α=β=0, A-D producen los mismos enlaces y datos bajo sorteos comunes."""
        p = replace(SMALL, alpha=0, beta=0)
        inp = make_inputs(p)
        baseline = simulate(p, "A", inp)
        for scenario in "BCD":
            self.assertEqual(simulate(p, scenario, inp), baseline)

    def test_model_preserves_graph_and_accounting(self):
        """Red fija, roles válidos, un enlace por cliente y conteos correctos en cada período."""
        inp = make_inputs(SMALL)
        before = edge_list(inp.graph)
        result = simulate(SMALL, "D", inp)
        self.assertEqual(edge_list(inp.graph), before)
        self.assertEqual(len({e["consumer_id"] for e in result.commercial}), len(result.commercial))
        for e in result.commercial:
            self.assertIn(e["consumer_id"], inp.consumers)
            self.assertIn(e["seller_id"], inp.sellers)
            self.assertNotEqual(e["consumer_id"], e["seller_id"])
        for system in result.system:
            sellers = [r for r in result.seller if r["period"] == system["period"]]
            self.assertEqual(sum(r["customers"] for r in sellers), system["customers"])
            self.assertEqual(system["customers"], system["commercial_edges"])
        commercial_graph = graph_from_edges(SMALL.N, [(r["consumer_id"],r["seller_id"]) for r in result.commercial])
        self.assertEqual(graph_metrics(commercial_graph)["mean_local_clustering"], 0)

    def test_choice_candidates_have_message_provenance(self):
        """Todo candidato procede de un mensaje social anterior o del mismo período."""
        inp = make_inputs(SMALL)
        result = simulate(SMALL, "D", inp, record_messages=True)
        ledger = {(m["receiver_id"],m["seller_id"],m["period"],m["sender_id"]) for m in result.messages}
        self.assertTrue(result.candidates)
        for row in result.candidates:
            self.assertIn((row["consumer_id"],row["candidate_seller_id"],row["first_known_period"],row["first_informer_id"]), ledger)
            self.assertLessEqual(row["first_known_period"],row["period"])
        for message in result.messages:
            sender = message["sender_id"]
            self.assertIn(message["receiver_id"],inp.graph[sender])
            if sender in inp.consumers:
                self.assertLess(result.adoption_period[sender],message["period"])
                self.assertEqual(result.assignments[sender],message["seller_id"])
        self.assertEqual(sum(r["selected"] for r in result.candidates),len(result.commercial))

    def test_repeated_messages_do_not_duplicate_alternatives(self):
        """Mensajes reiterados del mismo vendedor mantienen un único candidato."""
        p, inp = self.fixture_chain(a=0)
        result = simulate(p,"A",inp,record_messages=True)
        self.assertEqual(len(result.messages),p.T)
        self.assertEqual(result.known_sellers[1],(0,))

    def test_exact_repeatability_and_rng_stage_isolation(self):
        """Recrear las cinco semillas reproduce tablas y resultados exactamente."""
        first, second = make_inputs(SMALL), make_inputs(SMALL)
        self.assertEqual(first,second)
        self.assertEqual(simulate(SMALL,"D",first),simulate(SMALL,"D",second))
        self.assertEqual(len(set(first.seeds.values())),5)
        self.assertNotEqual(first.buy, first.choice)

    def test_extended_horizon_preserves_prefix(self):
        """Ampliar T preserva todos los sorteos y estados del horizonte inicial."""
        short, long = replace(SMALL,T=5), replace(SMALL,T=10)
        a,b = make_inputs(short),make_inputs(long)
        for field in ("message","buy","choice"):
            self.assertEqual(getattr(a,field),getattr(b,field)[:len(getattr(a,field))])
        for scenario in "ABCD":
            r1,r2 = simulate(short,scenario,a),simulate(long,scenario,b)
            self.assertEqual(r1.system,r2.system[:6])
            self.assertEqual(r1.commercial,[r for r in r2.commercial if r["adoption_period"]<=5])

    def test_invalid_parameters_rejected(self):
        """Se rechazan probabilidades fuera de rango, NaN, grado impar y población inválida."""
        for update in ({"q_s":-1},{"q_r":2},{"a":float("nan")},{"k":3},{"S":30},{"T":0},{"alpha":-1},{"N":30.0}):
            with self.assertRaises(ValueError):
                replace(SMALL,**update)


class ExportTests(unittest.TestCase):
    def test_export_headers_zero_case_and_no_overwrite(self):
        """La exportación conserva tablas vacías con encabezados, NA y rechaza sobrescritura."""
        p = replace(SMALL,q_s=0,q_r=0,T=2)
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)/"run"
            with redirect_stdout(io.StringIO()):
                meta = run_experiment(p,out,phase="verification",repetitions=1,block=900000,benchmarks=1)
            self.assertEqual(meta["completed_runs"],4)
            with (out/"commercial_edges.csv").open() as f:
                self.assertEqual(len(list(csv.reader(f))),1)
            with (out/"system_timeseries.csv").open() as f:
                self.assertTrue(all(r["customer_gini"]=="NA" for r in csv.DictReader(f)))
            checksums=json.loads((out/"checksums.json").read_text())
            for name,digest in checksums.items():
                self.assertEqual(sha256_file(out/name),digest)
            before=(out/"execution.json").read_bytes()
            with self.assertRaises(FileExistsError):
                run_experiment(p,out,phase="verification",repetitions=1,block=900000)
            self.assertEqual((out/"execution.json").read_bytes(),before)

    def test_config_unknown_fields_fail(self):
        """Un parámetro desconocido provoca error y no se ignora silenciosamente."""
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/"bad.json"
            path.write_text('{"unknown_parameter": 3}')
            with self.assertRaises(TypeError):
                load_parameters(path)


if __name__=="__main__":
    unittest.main()
