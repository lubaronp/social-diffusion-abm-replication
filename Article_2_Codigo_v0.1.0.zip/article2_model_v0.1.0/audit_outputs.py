"""Independent checks reconstructed from exported CSVs, without running the model."""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path


def audit(folder):
    folder=Path(folder)
    def read(name):
        with (folder/f"{name}.csv").open(encoding="utf-8",newline="") as f:
            return list(csv.DictReader(f))
    checks=0
    def require(condition,message):
        nonlocal checks
        checks+=1
        if not condition:
            raise AssertionError(message)
    def close(a,b):
        return math.isclose(float(a),float(b),rel_tol=1e-11,abs_tol=1e-12)
    meta=json.loads((folder/"execution.json").read_text())
    require(meta["status"]=="completed","Execution incomplete")
    for name,digest in json.loads((folder/"checksums.json").read_text()).items():
        require(hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest,"Checksum mismatch: "+name)
    manifests=read("experiment_manifest")
    systems=read("system_timeseries")
    sellers=read("seller_timeseries")
    commercial=read("commercial_edges")
    candidates=read("choice_candidates")
    social=read("social_edges")
    agents=read("agents")
    diagnostics=read("social_diagnostics")
    require(len({m["run_id"] for m in manifests})==len(manifests),"Duplicate run IDs")
    paired={}
    for m in manifests:
        run=m["run_id"]
        n,s,tmax=int(m["N"]),int(m["S"]),int(m["T"])
        key=(m["config_id"],m["random_block_id"],m["replicate_id"])
        def matching(row):
            return (row["config_id"],row["random_block_id"],row["replicate_id"])==key
        roles={int(row["agent_id"]):row["role"] for row in agents if matching(row)}
        seller_ids={i for i,role in roles.items() if role=="seller"}
        require(len(roles)==n and len(seller_ids)==s,"Role count mismatch")
        graph={tuple(sorted((int(row["source_id"]),int(row["target_id"])))) for row in social if matching(row)}
        require(len(graph)==n*int(m["k"])//2,"Social edge count mismatch")
        es=[r for r in commercial if r["run_id"]==run]
        sy=sorted([r for r in systems if r["run_id"]==run],key=lambda r:int(r["period"]))
        se=[r for r in sellers if r["run_id"]==run]
        ca=[r for r in candidates if r["run_id"]==run]
        require([int(r["period"]) for r in sy]==list(range(tmax+1)),"Missing/duplicate periods")
        require(len(se)==s*(tmax+1),"Seller series row count mismatch")
        require(len({r["consumer_id"] for r in es})==len(es),"Repeated customer")
        by_consumer={int(row["consumer_id"]):row for row in es}
        options=defaultdict(list)
        for row in ca:
            options[int(row["consumer_id"])].append(row)
        require(set(options)==set(by_consumer),"Candidate ledger differs from purchases")
        for buyer,event in by_consumer.items():
            chosen,period=int(event["seller_id"]),int(event["adoption_period"])
            require(roles[buyer]=="consumer" and chosen in seller_ids,"Invalid commercial roles")
            alternatives=options[buyer]
            require(len(alternatives)==int(event["choice_set_size"]),"Wrong choice set size")
            require(len({r["candidate_seller_id"] for r in alternatives})==len(alternatives),"Duplicate candidate")
            require(sum(int(r["selected"]) for r in alternatives)==1,"Not exactly one selected candidate")
            previous=Counter(int(e["seller_id"]) for e in es if int(e["adoption_period"])<period)
            weights=[]
            for row in alternatives:
                j=int(row["candidate_seller_id"])
                direct=int(tuple(sorted((buyer,j))) in graph)
                require(int(row["period"])==period and int(row["direct_tie"])==direct,"Candidate period/proximity mismatch")
                require(int(row["previous_customers"])==previous[j],"Within-period feedback or wrong prior counts")
                weights.append(math.exp(float(m["active_alpha"])*direct)*(previous[j]+1)**float(m["active_beta"]))
                first,source=int(row["first_known_period"]),int(row["first_informer_id"])
                require(1<=first<=period and tuple(sorted((source,buyer))) in graph,"Invalid first-message provenance")
                if source in seller_ids:
                    require(source==j,"Seller recommended another seller")
                else:
                    require(source in by_consumer,"Non-customer sent a referral")
                    source_event=by_consumer[source]
                    require(int(source_event["adoption_period"])<first and int(source_event["seller_id"])==j,"Referral before purchase or wrong seller")
                require(int(row["selected"])==int(j==chosen),"Selected flag mismatch")
            denominator=sum(weights)
            for row,weight in zip(alternatives,weights):
                require(close(row["probability"],weight/denominator),"Incorrect choice probability")
                require(close(row["weight"],weight),"Incorrect exported weight")
            require(close(sum(float(row["probability"]) for row in alternatives),1),"Probability sum mismatch")
        for row in sy:
            t=int(row["period"])
            observed=Counter(int(e["seller_id"]) for e in es if int(e["adoption_period"])<=t)
            counts=[observed[j] for j in sorted(seller_ids)]
            total=sum(counts)
            new=Counter(int(e["seller_id"]) for e in es if int(e["adoption_period"])==t)
            require(total==int(row["customers"])==int(row["commercial_edges"]),"System count mismatch")
            require(sum(new.values())==int(row["new_customers"]),"Acquisitions mismatch")
            require(close(row["coverage"],total/(n-s)),"Coverage denominator mismatch")
            require(total<=int(row["aware_agents"])<=n-s,"Awareness count outside bounds")
            for sr in [r for r in se if int(r["period"])==t]:
                j=int(sr["seller_id"])
                require(int(sr["customers"])==observed[j] and int(sr["new_customers"])==new[j],"Seller count mismatch")
                require(int(sr["previous_customers"])==observed[j]-new[j],"Prior seller count mismatch")
                expected_op=sum(int(r["period"])==t and int(r["candidate_seller_id"])==j for r in ca)
                require(int(sr["choice_opportunities"])==expected_op,"Opportunity count mismatch")
            if total:
                g=sum(abs(x-y) for x in counts for y in counts)/(2*s*total)
                require(close(row["customer_gini"],g),"Gini mismatch")
                require(close(row["largest_share"],max(counts)/total),"Largest share mismatch")
            else:
                require(row["customer_gini"]=="NA" and row["largest_share"]=="NA","Undefined concentration must be NA")
        signature=[(r["period"],r["aware_agents"],r["customers"]) for r in sy]
        require(key not in paired or paired[key]==signature,"Different diffusion in paired scenarios")
        paired[key]=signature
    return {"status":"passed","phase":meta["phase"],"runs":len(manifests),"assertions_passed":checks,
            "system_rows":len(systems),"seller_rows":len(sellers),"commercial_rows":len(commercial),
            "candidate_rows":len(candidates),"social_diagnostic_rows":len(diagnostics),
            "pilot_executed":meta["phase"]=="pilot"}


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("folder",type=Path)
    parser.add_argument("--report",type=Path,required=True)
    args=parser.parse_args()
    if args.report.exists():
        raise FileExistsError(args.report)
    result=audit(args.folder)
    args.report.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2))
