"""Article 2: customer choice on a fixed social graph."""

__version__ = "0.1.0"
SPEC_VERSION = "0.1"
