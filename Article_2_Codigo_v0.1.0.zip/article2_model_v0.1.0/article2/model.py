"""Synchronous implementation of Article 2 specification 0.1.

    social graph -> offer messages -> purchase -> choice -> commercial edge

All exogenous draws are indexed before simulation; branches consume no RNG.
"""
from array import array
from collections import Counter
from dataclasses import dataclass, asdict
import math
import random

from .network import watts_strogatz, validate_graph, edge_list


@dataclass(frozen=True)
class Parameters:
    N: int = 500
    S: int = 10
    k: int = 6
    p_WS: float = 0.10
    q_s: float = 0.25
    q_r: float = 0.20
    a: float = 0.10
    T: int = 60
    alpha: float = math.log(2)
    beta: float = 1.0

    def __post_init__(self):
        if any(type(x) is not int for x in (self.N, self.S, self.k, self.T)):
            raise ValueError("N, S, k and T must be integers")
        if not (self.N > self.S >= 2 and 0 < self.k < self.N and self.k % 2 == 0 and self.T > 0):
            raise ValueError("Invalid population, roles, ring degree or horizon")
        for key in ("p_WS", "q_s", "q_r", "a"):
            value = getattr(self, key)
            if not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f"{key} must lie in [0, 1]")
        for key in ("alpha", "beta"):
            value = getattr(self, key)
            if not math.isfinite(value) or value < 0:
                raise ValueError(f"{key} must be nonnegative and finite")


def coefficients(parameters, scenario):
    if scenario not in ("A", "B", "C", "D"):
        raise ValueError("Unknown scenario")
    return (parameters.alpha if scenario in ("B", "D") else 0.0,
            parameters.beta if scenario in ("C", "D") else 0.0)


def probabilities(counts, direct, alpha, beta):
    """Return log weights and probabilities in the supplied candidate order."""
    if not counts or len(counts) != len(direct):
        raise ValueError("Empty or mismatched alternatives")
    if any(type(n) is not int or n < 0 for n in counts):
        raise ValueError("Counts must be nonnegative integers")
    if any(h not in (0, 1) for h in direct):
        raise ValueError("Proximity must be binary")
    if any(not math.isfinite(v) or v < 0 for v in (alpha, beta)):
        raise ValueError("Invalid preference coefficients")
    logs = [alpha * h + beta * math.log1p(n) for n, h in zip(counts, direct)]
    if not all(math.isfinite(x) for x in logs):
        raise ValueError("Log weights overflowed; reduce coefficients")
    maximum = max(logs)
    scaled = [math.exp(x - maximum) for x in logs]
    total = math.fsum(scaled)
    probs = [x / total for x in scaled]
    if any(p == 0.0 for p in probs):
        raise ValueError("Numerical underflow eliminates a candidate; reduce coefficients")
    if not math.isclose(math.fsum(probs), 1, rel_tol=0, abs_tol=1e-12):
        raise AssertionError("Choice probabilities do not sum to one")
    return logs, probs


def categorical(probs, uniform):
    if not 0 <= uniform < 1:
        raise ValueError("Uniform must lie in [0, 1)")
    cumulative = 0.0
    for index, p in enumerate(probs):
        cumulative += p
        if uniform < cumulative:
            return index
    return len(probs) - 1  # round-off at the last cumulative boundary


def concentration(counts):
    if len(counts) < 2 or any(x < 0 for x in counts):
        raise ValueError("At least two nonnegative seller counts required")
    total, s = sum(counts), len(counts)
    if total == 0:
        return {"customer_gini": None, "gini_normalized": None,
                "largest_share": None, "largest_share_normalized": None,
                "metric_status": "no_adoption"}
    g = sum(abs(x - y) for x in counts for y in counts) / (2 * s * total)
    largest = max(counts) / total
    return {"customer_gini": g, "gini_normalized": g * s / (s - 1),
            "largest_share": largest,
            "largest_share_normalized": (largest - 1 / s) / (1 - 1 / s),
            "metric_status": "defined"}


@dataclass
class Inputs:
    graph: tuple
    sellers: tuple
    consumers: tuple
    directed_edges: tuple
    seeds: dict
    T: int
    message: array
    buy: array
    choice: array


def make_inputs(parameters, block=900000, replicate=1, *, graph=None, sellers=None, constant=None):
    """Constant draws are for deterministic verification fixtures only."""
    if type(replicate) is not int or not 1 <= replicate < 10000:
        raise ValueError("Replicate must be an integer from 1 to 9999")
    if type(block) is not int or block < 0:
        raise ValueError("Block must be a nonnegative integer")
    stages = ("network", "roles", "message", "buy", "choice")
    seeds = {stage: block + 10 * replicate + offset for offset, stage in enumerate(stages)}
    if graph is None:
        graph = watts_strogatz(parameters.N, parameters.k, parameters.p_WS, seeds["network"])
    validate_graph(graph)
    graph = tuple(frozenset(ns) for ns in graph)
    if len(graph) != parameters.N:
        raise ValueError("Graph size does not match parameters")
    if sellers is None:
        sellers = random.Random(seeds["roles"]).sample(range(parameters.N), parameters.S)
    sellers = tuple(sorted(sellers))
    if (len(sellers) != parameters.S or len(set(sellers)) != len(sellers)
            or any(type(j) is not int or not 0 <= j < parameters.N for j in sellers)):
        raise ValueError("Invalid seller set")
    consumers = tuple(i for i in range(parameters.N) if i not in sellers)
    directed = tuple((u, v) for u, ns in enumerate(graph) for v in sorted(ns))
    def draws(stage, size):
        if constant is not None:
            if not 0 <= constant < 1:
                raise ValueError("Constant uniform must lie in [0,1)")
            return array("d", [constant]) * size
        rng = random.Random(seeds[stage])
        return array("d", (rng.random() for _ in range(size)))
    return Inputs(graph, sellers, consumers, directed, seeds, parameters.T,
                  draws("message", parameters.T * len(directed)),
                  draws("buy", parameters.T * len(consumers)),
                  draws("choice", parameters.T * len(consumers)))


@dataclass
class Result:
    system: list
    seller: list
    commercial: list
    candidates: list
    messages: list
    awareness_period: dict
    adoption_period: dict
    assignments: dict
    known_sellers: dict


def simulate(parameters, scenario, inputs, run_id="verification", *, reverse_order=False, record_messages=False):
    """Run one scenario. Input graph and random tables are read-only."""
    p, inp = parameters, inputs
    if len(inp.graph) != p.N or len(inp.sellers) != p.S or inp.T < p.T:
        raise ValueError("Input bundle incompatible with parameters")
    alpha, beta = coefficients(p, scenario)
    seller_set = frozenset(inp.sellers)
    consumer_index = {i: index for index, i in enumerate(inp.consumers)}
    known = {i: set() for i in inp.consumers}
    first_message, aware_time, adoption_time, assigned = {}, {}, {}, {}
    counts = {j: 0 for j in inp.sellers}
    system, seller_rows, commercial, candidates, messages = [], [], [], [], []
    initial_edges = edge_list(inp.graph)
    order = tuple(reversed(inp.consumers)) if reverse_order else inp.consumers
    m, c = len(inp.directed_edges), len(inp.consumers)
    if len(inp.message) < p.T * m or len(inp.buy) < p.T * c or len(inp.choice) < p.T * c:
        raise ValueError("Random table is too short")

    def record(t, previous, new_counts, opportunities):
        total = len(assigned)
        system.append({"run_id": run_id, "period": t, "aware_agents": len(aware_time),
                       "aware_share": len(aware_time) / c, "customers": total,
                       "new_customers": sum(new_counts.values()), "commercial_edges": total,
                       "coverage": total / c, "max_commercial_degree": max(counts.values()),
                       "multi_choice_share": sum(e["choice_set_size"] >= 2 for e in commercial) / total if total else None,
                       "direct_choice_share": sum(e["direct_tie"] for e in commercial) / total if total else None,
                       **concentration(list(counts.values()))})
        for j in inp.sellers:
            seller_rows.append({"run_id": run_id, "period": t, "seller_id": j,
                                "previous_customers": previous[j], "new_customers": new_counts.get(j, 0),
                                "customers": counts[j], "choice_opportunities": opportunities.get(j, 0)})

    record(0, counts.copy(), {}, {})
    for t in range(1, p.T + 1):
        previous, previous_assignments = counts.copy(), assigned.copy()
        # All messages are sent by people active before this period's purchases.
        for e_index, (u, v) in enumerate(inp.directed_edges):
            if v in seller_set or v in previous_assignments:
                continue
            if u in seller_set:
                offer, threshold = u, p.q_s
            elif u in previous_assignments:
                offer, threshold = previous_assignments[u], p.q_r
            else:
                continue
            if inp.message[(t - 1) * m + e_index] < threshold:
                known[v].add(offer)
                aware_time.setdefault(v, t)
                first_message.setdefault((v, offer), (t, u))
                if record_messages:
                    messages.append({"run_id": run_id, "period": t, "sender_id": u,
                                     "receiver_id": v, "seller_id": offer})
        pending, pending_candidates, opportunities = [], [], Counter()
        for i in order:
            if i in previous_assignments or not known[i]:
                continue
            draw_index = (t - 1) * c + consumer_index[i]
            if inp.buy[draw_index] >= p.a:
                continue
            options = sorted(known[i])
            direct = [int(j in inp.graph[i]) for j in options]
            logs, probs = probabilities([previous[j] for j in options], direct, alpha, beta)
            selected_index = categorical(probs, inp.choice[draw_index])
            chosen = options[selected_index]
            pending.append({"run_id": run_id, "consumer_id": i, "seller_id": chosen,
                            "adoption_period": t, "choice_set_size": len(options),
                            "direct_tie": direct[selected_index]})
            for pos, j in enumerate(options):
                opportunities[j] += 1
                first_t, source = first_message[i, j]
                pending_candidates.append({"run_id": run_id, "period": t, "consumer_id": i,
                    "candidate_seller_id": j, "previous_customers": previous[j], "direct_tie": direct[pos],
                    "log_weight": logs[pos], "weight": math.exp(logs[pos]) if logs[pos] < 709 else None,
                    "probability": probs[pos], "selected": int(j == chosen),
                    "first_known_period": first_t, "first_informer_id": source})
        new_counts = Counter()
        for event in sorted(pending, key=lambda row: row["consumer_id"]):
            i, j = event["consumer_id"], event["seller_id"]
            if i in assigned or i == j or j not in known[i] or j not in seller_set:
                raise AssertionError("Invalid commercial edge")
            assigned[i], adoption_time[i] = j, t
            counts[j] += 1
            new_counts[j] += 1
            commercial.append(event)
        candidates.extend(sorted(pending_candidates, key=lambda row: (row["consumer_id"], row["candidate_seller_id"])))
        if not (len(assigned) == len(commercial) == sum(counts.values()) <= c):
            raise AssertionError("Customer/edge accounting mismatch")
        if Counter(assigned.values()) != +Counter(counts):
            raise AssertionError("Seller counts do not match actual assignments")
        record(t, previous, new_counts, opportunities)
    if edge_list(inp.graph) != initial_edges:
        raise AssertionError("Social graph changed")
    return Result(system, seller_rows, commercial, candidates, messages, aware_time,
                  adoption_time, assigned, {i: tuple(sorted(k)) for i, k in known.items()})
