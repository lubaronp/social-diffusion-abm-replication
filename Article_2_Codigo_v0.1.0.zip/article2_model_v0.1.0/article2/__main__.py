import argparse
import json
from pathlib import Path
from .experiment import load_parameters, run_experiment


def main():
    parser = argparse.ArgumentParser(description="Article 2: explicitly run one experiment phase")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path, help="New directory; existing paths are rejected")
    parser.add_argument("--phase", choices=["verification", "pilot", "main", "sensitivity"], required=True)
    parser.add_argument("--repetitions", type=int, required=True)
    parser.add_argument("--block", type=int, required=True)
    parser.add_argument("--config-id", default="base_v01")
    parser.add_argument("--benchmarks", type=int, default=10)
    args = parser.parse_args()
    result = run_experiment(load_parameters(args.config), args.out, phase=args.phase,
                            repetitions=args.repetitions, block=args.block,
                            config_id=args.config_id, benchmarks=args.benchmarks)
    print(json.dumps({"status": result["status"], "runs": result["completed_runs"], "out": str(args.out)}, indent=2))


if __name__ == "__main__":
    main()
