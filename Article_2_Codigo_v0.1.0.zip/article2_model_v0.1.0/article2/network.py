"""Small, auditable undirected graph routines; no external dependencies."""
from collections import deque
import random


def graph_from_edges(n, edges):
    adjacency = [set() for _ in range(n)]
    for u, v in edges:
        if not (0 <= u < n and 0 <= v < n) or u == v:
            raise ValueError("Invalid edge or self-link")
        if v in adjacency[u]:
            raise ValueError("Duplicate undirected edge")
        adjacency[u].add(v)
        adjacency[v].add(u)
    return tuple(frozenset(x) for x in adjacency)


def edge_list(graph):
    return tuple((u, v) for u, ns in enumerate(graph) for v in sorted(ns) if u < v)


def validate_graph(graph):
    if not graph:
        raise ValueError("Empty graph")
    for u, ns in enumerate(graph):
        for v in ns:
            if type(v) is not int or not 0 <= v < len(graph) or v == u:
                raise ValueError("Invalid social endpoint")
            if u not in graph[v]:
                raise ValueError("Social graph is not symmetric")


def watts_strogatz(n, k, p, seed):
    """Rewire each original clockwise ring edge once (node then offset order).

    A candidate cannot be the source or any of its current neighbors. If the
    source has no available target, keep that edge. Never condition on being
    connected. The number of undirected edges stays n*k/2.
    """
    if not (type(n) is int and type(k) is int and 0 < k < n and k % 2 == 0):
        raise ValueError("Require even 0 < k < n")
    if not 0 <= p <= 1:
        raise ValueError("Invalid rewiring probability")
    original = [(u, (u + d) % n) for u in range(n) for d in range(1, k // 2 + 1)]
    graph = [set(x) for x in graph_from_edges(n, original)]
    rng = random.Random(seed)
    for u, v in original:
        if rng.random() < p:
            candidates = [x for x in range(n) if x != u and x not in graph[u]]
            if candidates:
                w = rng.choice(candidates)
                graph[u].remove(v)
                graph[v].remove(u)
                graph[u].add(w)
                graph[w].add(u)
    result = tuple(frozenset(x) for x in graph)
    validate_graph(result)
    if len(edge_list(result)) != n * k // 2:
        raise AssertionError("Rewiring changed edge count")
    return result


def gnm_random(n, m, seed):
    """Uniform simple graph with exactly m undirected edges."""
    if not 0 <= m <= n * (n - 1) // 2:
        raise ValueError("Invalid number of edges")
    rng = random.Random(seed)
    if m > n * (n - 1) // 4:
        edges = rng.sample([(u, v) for u in range(n) for v in range(u + 1, n)], m)
    else:
        edges = set()
        while len(edges) < m:
            u, v = rng.sample(range(n), 2)
            edges.add((min(u, v), max(u, v)))
    return graph_from_edges(n, edges)


def graph_metrics(graph):
    """Mean local clustering includes zeros; paths use largest component only."""
    validate_graph(graph)
    n = len(graph)
    components, seen = [], set()
    for root in range(n):
        if root in seen:
            continue
        queue, component = deque([root]), {root}
        seen.add(root)
        while queue:
            u = queue.popleft()
            for v in sorted(graph[u]):
                if v not in seen:
                    seen.add(v)
                    component.add(v)
                    queue.append(v)
        components.append(component)
    # Ties resolved by lowest node ID, not arbitrary set order.
    largest = min(components, key=lambda c: (-len(c), min(c)))
    clustering = 0.0
    for ns in graph:
        if len(ns) >= 2:
            ordered_links = sum(len(graph[v] & ns) for v in ns)
            clustering += ordered_links / (len(ns) * (len(ns) - 1))
    distances_sum, diameter = 0, 0
    for root in sorted(largest):
        queue, distance = deque([root]), {root: 0}
        while queue:
            u = queue.popleft()
            for v in sorted(graph[u]):
                if v not in distance:
                    distance[v] = distance[u] + 1
                    queue.append(v)
        distances_sum += sum(distance.values())
        diameter = max(diameter, max(distance.values()))
    size = len(largest)
    return {"nodes": n, "edges": len(edge_list(graph)),
            "mean_degree": sum(map(len, graph)) / n,
            "mean_local_clustering": clustering / n,
            "components": len(components), "largest_component_size": size,
            "largest_component_share": size / n,
            "mean_path_length_lcc": distances_sum / (size * (size - 1)) if size > 1 else 0.0,
            "diameter_lcc": diameter}
