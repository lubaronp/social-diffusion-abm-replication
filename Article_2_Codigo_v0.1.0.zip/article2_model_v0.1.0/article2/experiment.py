"""Explicit experiment runner and CSV export. Never starts a pilot on import."""
import csv
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys

from . import __version__, SPEC_VERSION
from .model import Parameters, make_inputs, simulate, coefficients
from .network import edge_list, graph_metrics, gnm_random


SCHEMAS = {
    "system_timeseries": ["run_id", "period", "aware_agents", "aware_share", "customers", "new_customers", "commercial_edges", "coverage", "max_commercial_degree", "multi_choice_share", "direct_choice_share", "customer_gini", "gini_normalized", "largest_share", "largest_share_normalized", "metric_status"],
    "seller_timeseries": ["run_id", "period", "seller_id", "previous_customers", "new_customers", "customers", "choice_opportunities"],
    "commercial_edges": ["run_id", "consumer_id", "seller_id", "adoption_period", "choice_set_size", "direct_tie"],
    "choice_candidates": ["run_id", "period", "consumer_id", "candidate_seller_id", "previous_customers", "direct_tie", "log_weight", "weight", "probability", "selected", "first_known_period", "first_informer_id"],
    "agents": ["config_id", "random_block_id", "replicate_id", "agent_id", "role", "social_degree"],
    "social_edges": ["config_id", "random_block_id", "replicate_id", "source_id", "target_id"],
    "social_diagnostics": ["config_id", "random_block_id", "replicate_id", "graph_type", "reference_id", "seed", "nodes", "edges", "mean_degree", "mean_local_clustering", "components", "largest_component_size", "largest_component_share", "mean_path_length_lcc", "diameter_lcc"],
    "experiment_manifest": ["run_id", "phase", "config_id", "random_block_id", "replicate_id", "scenario", "N", "S", "k", "p_WS", "q_s", "q_r", "a", "T", "alpha", "beta", "active_alpha", "active_beta", "seed_customers", "external_visibility", "seed_network", "seed_roles", "seed_message", "seed_buy", "seed_choice", "source_run_id", "model_version", "spec_version", "code_sha256", "python_version", "rng"],
    "paired_checks": ["config_id", "random_block_id", "replicate_id", "scenario", "identical_awareness", "identical_adoption", "passed"],
}


def write_csv(path, fields, rows, append=False):
    path = Path(path)
    new = not append or not path.exists()
    with path.open("a" if append else "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="raise", lineterminator="\n")
        if new:
            writer.writeheader()
        for row in rows:
            writer.writerow({key: "NA" if row.get(key) is None else row[key] for key in fields})


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_fingerprint():
    digest = hashlib.sha256()
    for path in sorted(Path(__file__).parent.glob("*.py")):
        digest.update(path.name.encode())
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def load_parameters(path):
    with Path(path).open(encoding="utf-8") as handle:
        raw = json.load(handle)
    return Parameters(**raw)


def run_experiment(parameters, destination, *, phase, repetitions, block, config_id="base_v01", benchmarks=10):
    if phase not in ("verification", "pilot", "main", "sensitivity"):
        raise ValueError("Explicit phase is required")
    if type(repetitions) is not int or not 1 <= repetitions < 10000:
        raise ValueError("Invalid repetition count")
    if type(benchmarks) is not int or not 0 <= benchmarks <= 99:
        raise ValueError("benchmarks must be between 0 and 99")
    if not config_id or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in config_id):
        raise ValueError("Use letters, digits, underscores and hyphens in config_id")
    # Refuse overwrite, including an existing empty directory.
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    for table, fields in SCHEMAS.items():
        write_csv(destination / f"{table}.csv", fields, [])
    code_hash = source_fingerprint()
    metadata = {"phase": phase, "repetitions": repetitions, "scenarios": ["A", "B", "C", "D"],
                "random_block_id": block, "config_id": config_id, "parameters": asdict(parameters),
                "random_benchmarks_per_network": benchmarks, "model_version": __version__,
                "spec_version": SPEC_VERSION, "python": sys.version, "platform": platform.platform(),
                "rng": "stdlib random.Random / MT19937", "code_sha256": code_hash,
                "started_utc": datetime.now(timezone.utc).isoformat(), "status": "running",
                "calibrated": False}
    meta_path = destination / "execution.json"
    meta_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    def save(table, rows):
        write_csv(destination / f"{table}.csv", SCHEMAS[table], rows, append=True)
    try:
        for replicate in range(1, repetitions + 1):
            inp = make_inputs(parameters, block, replicate)
            keys = {"config_id": config_id, "random_block_id": block, "replicate_id": replicate}
            save("agents", [{**keys, "agent_id": i, "role": "seller" if i in inp.sellers else "consumer", "social_degree": len(inp.graph[i])} for i in range(parameters.N)])
            edges = edge_list(inp.graph)
            save("social_edges", [{**keys, "source_id": u, "target_id": v} for u, v in edges])
            diagnostics = [{**keys, "graph_type": "watts_strogatz", "reference_id": 0,
                            "seed": inp.seeds["network"], **graph_metrics(inp.graph)}]
            for ref in range(1, benchmarks + 1):
                seed = 1_000_000_000 + block * 10000 + replicate * 100 + ref
                reference = gnm_random(parameters.N, len(edges), seed)
                diagnostics.append({**keys, "graph_type": "gnm_reference", "reference_id": ref,
                                    "seed": seed, **graph_metrics(reference)})
            save("social_diagnostics", diagnostics)
            baseline = None
            for scenario in ("A", "B", "C", "D"):
                run_id = f"{phase}_{config_id}_b{block}_r{replicate:04d}_{scenario}"
                result = simulate(parameters, scenario, inp, run_id)
                alpha, beta = coefficients(parameters, scenario)
                save("experiment_manifest", [{"run_id": run_id, "phase": phase, **keys,
                    "scenario": scenario, **asdict(parameters), "active_alpha": alpha, "active_beta": beta,
                    "seed_customers": 0, "external_visibility": 0,
                    **{f"seed_{key}": value for key, value in inp.seeds.items()}, "source_run_id": None,
                    "model_version": __version__, "spec_version": SPEC_VERSION, "code_sha256": code_hash,
                    "python_version": platform.python_version(), "rng": "stdlib random.Random / MT19937"}])
                for table, rows in (("system_timeseries", result.system), ("seller_timeseries", result.seller),
                                    ("commercial_edges", result.commercial), ("choice_candidates", result.candidates)):
                    save(table, rows)
                state = (result.awareness_period, result.adoption_period)
                if baseline is None:
                    baseline = state
                checks = {"identical_awareness": int(state[0] == baseline[0]), "identical_adoption": int(state[1] == baseline[1])}
                passed = int(all(checks.values()))
                save("paired_checks", [{**keys, "scenario": scenario, **checks, "passed": passed}])
                if not passed:
                    raise AssertionError("Scenarios have different awareness/adoption with common draws")
            print(f"{phase}: repetition {replicate}/{repetitions}; A-D exported", flush=True)
        metadata.update(status="completed", completed_runs=4 * repetitions,
                        finished_utc=datetime.now(timezone.utc).isoformat())
    except Exception as error:
        metadata.update(status="failed", error_type=type(error).__name__, error=str(error))
        raise
    finally:
        meta_path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    checksums = {p.name: sha256_file(p) for p in sorted(destination.iterdir()) if p.is_file()}
    (destination / "checksums.json").write_text(json.dumps(checksums, indent=2) + "\n", encoding="utf-8")
    return metadata
