# Diccionario de salidas — v0.1.0

Todos los CSV usan UTF-8, coma como separador y punto decimal. Los índices de personas comienzan en cero. `NA` indica ausencia o magnitud no definida. Banderas booleanas exportadas: 0/1.

| Archivo | Unidad y uso |
|---|---|
| `experiment_manifest.csv` | Una ejecución. Parámetros nominales `alpha`, `beta` y coeficientes efectivos `active_alpha`, `active_beta`; cinco semillas; versión y huella del código. `source_run_id=NA` cuando no hay reutilización. |
| `agents.csv` | Persona por configuración, bloque y repetición. El rol no cambia. |
| `social_edges.csv` | Arista social no dirigida; `source_id < target_id`. No duplicar su orientación al contar enlaces. |
| `social_diagnostics.csv` | Red social o referencia G(N,M). `mean_path_length_lcc` y `diameter_lcc` se calculan únicamente en el mayor componente. Para un componente unitario se usa 0 como convención. |
| `system_timeseries.csv` | Ejecución y cierre temporal. Incluye t=0. `aware_agents` comprende clientes informados y no clientes informados. Los cocientes de difusión usan N−S. |
| `seller_timeseries.csv` | Vendedor y cierre temporal. `previous_customers` es el conteo al inicio del período; `new_customers` sus adquisiciones; `customers` la suma. `choice_opportunities` cuenta eventos de compra en los que apareció como candidato. |
| `commercial_edges.csv` | Una compra por consumidor. `adoption_period` es el período de creación, `choice_set_size` cuenta alternativas únicas, `direct_tie` indica contacto social directo con el vendedor elegido. |
| `choice_candidates.csv` | Una alternativa por evento de compra. `previous_customers` es el éxito usado para elegir; `selected` identifica una única alternativa. `first_known_period` y `first_informer_id` documentan el primer mensaje que presentó ese vendedor. |
| `paired_checks.csv` | Ejecución: identidad exacta de períodos de conocimiento y compra frente a A; se comprueba con los estados por persona antes de exportar. |
| `execution.json` | Estado `running`, `completed` o `failed`, configuración, entorno, fase y número de ejecuciones. Una carpeta con estado `failed` no es un experimento terminado. |
| `checksums.json` | SHA-256 de los archivos originales de ejecución. No incluye a sí mismo ni informes agregados después. |

En `system_timeseries.csv`, `customer_gini` incluye a todos los vendedores, incluso los de cero clientes. `gini_normalized` divide por su máximo teórico para S vendedores. `largest_share` es la mayor participación observada; su versión normalizada descuenta la participación igualitaria 1/S. `multi_choice_share` y `direct_choice_share` son proporciones acumuladas de compras, no del total de consumidores potenciales. `max_commercial_degree` es el máximo número de clientes de un vendedor.

Para reconstruir el conjunto comercial al cierre t, filtrar `commercial_edges.csv` por `adoption_period <= t`. Los nodos aislados se recuperan desde `agents.csv`. Los archivos de agentes y red social se comparten entre escenarios y no deben multiplicarse por cuatro para contar personas independientes.

El nombre de fase y las semillas separan verificación, piloto, principal y sensibilidad. Nunca combinar esos archivos únicamente porque tienen las mismas columnas.
