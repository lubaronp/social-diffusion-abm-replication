# Decisiones de implementación — Article 2 v0.1.0

Fecha: 25 de septiembre de 2026. Especificación implementada: 0.1.

## Decisiones técnicas

| Decisión | Motivo y efecto |
|---|---|
| Python con biblioteca estándar | Permite ejecutar modelo y pruebas en un solo entorno, sin instalaciones adicionales. Concreta la alternativa Python prevista en la especificación; conserva las reglas científicas. |
| Python 3.12.14 como entorno verificado | Fija la versión utilizada. Se registran plataforma y generador para no prometer identidad de resultados entre entornos no comprobados. |
| Grafos inmutables con conjuntos de vecinos | Evita cambios accidentales de la red durante la simulación. |
| Watts–Strogatz propio y documentado | Recorre nodo y luego distancia horaria de la arista original. Su código y pruebas quedan disponibles para auditoría; no se afirma identidad de aristas con generadores de otros paquetes. |
| Semillas de cinco etapas y tablas uniformes por agente/arista/período | Las diferencias en ramas del programa no desplazan los sorteos entre escenarios. |
| Actualización sincrónica | Todas las elecciones usan los conteos del cierre anterior. Clientes nuevos recomiendan desde el siguiente período. |
| Orden estable de candidatos y exportaciones | Reproduce sorteos categóricos y archivos, y evita dependencia de la iteración de conjuntos. |
| `NA` explícito en CSV | Separa ausencia de clientes de igualdad en el reparto. |
| Manifiesto, huella SHA-256 y sumas de comprobación | Permite relacionar resultados con el código y detectar archivos alterados. La huella del modelo cubre los archivos `article2/*.py`; el paquete completo tiene su propio inventario. |
| Rechazo de directorios existentes | Evita sobrescribir resultados de una fase o versión anterior. |

Los pesos se calculan con logaritmos y normalización estable. Se exportan `log_weight` y `weight`; para pesos que excedan el rango exponencial, `weight` queda `NA` y se conserva el logaritmo. Si una combinación extrema de parámetros causa subdesbordamiento y elimina numéricamente una alternativa, el modelo devuelve un error explícito. Los parámetros de esta entrega no presentan esos problemas.

No hay cambio de mecanismos respecto a la especificación 0.1. No se introdujeron satisfacción, confianza psicológica, calidad, ingresos, visibilidad externa o entrada escalonada.

## Límites del ejecutor

El comando de experimentos genera A–D para cada repetición y conserva los mismos objetos iniciales y sorteos. Es apto para verificación y piloto. No automatiza todavía el análisis estadístico, la producción de figuras, el ajuste de distribuciones ni la selección de configuraciones de sensibilidad. La reutilización de resultados A/B entre sensibilidades de β se documentará cuando se prepare esa fase; no se deben contar las copias como repeticiones nuevas.

Los resultados contenidos en `verification/` sirven para comprobar funcionamiento y exportación. La verificación computacional no equivale a validación empírica o predictiva. El piloto sigue pendiente.
