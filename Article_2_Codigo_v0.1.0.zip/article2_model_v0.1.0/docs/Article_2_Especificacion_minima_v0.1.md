# Article 2 — Especificación mínima del modelo de simulación

**Versión:** 0.1 — 25 de septiembre de 2026  
**Proyecto:** The 22 Manuscripts – Season II, Universidad Nacional de Colombia, Sede de La Paz  
**Estado:** especificación operativa para construir y verificar el modelo; todavía no se han ejecutado experimentos con esta versión.  
**Naturaleza del estudio:** experimento computacional teórico, sin calibración ni validación predictiva con datos reales.

**Título provisional:** *Social Diffusion and Commercial Concentration: An Agent-Based Model of Customer Choice*

Este documento concreta una primera versión implementable a partir de la guía «Indications - Article 2 - MLM - ABM SW SF». Para esta versión, los cambios registrados al final sustituyen las expectativas más amplias de la guía. Los valores son decisiones experimentales provisionales: después del piloto podrán revisarse mediante una nueva versión documentada, antes de ejecutar el experimento principal. El título no anticipa una distribución scale-free.

El propósito inmediato es entregar al estudiante un modelo comprensible y resultados reproducibles que pueda analizar para iniciar el manuscrito. El estudiante conserva la responsabilidad de comprender las reglas, verificar su implementación, interpretar las salidas y liderar la escritura; los profesores orientan y revisan estas decisiones. Se conserva la ruta de la guía: NetLogo para simulación y Python o R para análisis. La especificación lógica también puede implementarse íntegramente en Python si el equipo ya trabaja allí; debe elegirse y documentarse una sola implementación antes del experimento principal.

## 1. Propósito, pregunta y expectativas

**Pregunta principal:** ¿Cómo cambian la concentración de clientes y su distribución entre vendedores cuando la elección favorece la proximidad social, el éxito comercial acumulado o ambos mecanismos, bajo difusión local de información?

El modelo separa tres objetos:

| Objeto | Representación | Función |
|---|---|---|
| Red social | Grafo fijo, simple y no dirigido entre personas | Determina quién puede comunicar una oferta a quién. |
| Difusión | Mensajes y adquisición de información a lo largo del tiempo | Determina cuándo una persona conoce la oferta y qué vendedores conoce. |
| Red comercial | Enlaces dirigidos de clientes a vendedores | Registra las elecciones efectivamente realizadas. |

Se estudia la concentración de clientes, no la totalidad de un sistema de mercadeo multinivel. No se representan reclutamiento de distribuidores, jerarquías de compensación ni comisiones multinivel. En el manuscrito, el alcance debe corresponder a estas relaciones comerciales simplificadas.

Las expectativas son preguntas contrastables dentro del modelo:

- ¿La preferencia por éxito acumulado aumenta la concentración respecto a la elección aleatoria entre vendedores conocidos?
- ¿La preferencia por vendedores directamente conectados modifica esa diferencia?
- ¿Los patrones cambian al modificar la estructura social y la facilidad de recomendar?

No se exige obtener diferencias positivas. Deben conservarse los resultados nulos, inversos y heterogéneos entre repeticiones.

**Qué emerge y qué se fija.** Se fijan los roles, la red social y la regla de una compra por cliente. Emergen la identidad del vendedor elegido, la secuencia de adquisición y el número de clientes de cada vendedor. Con roles separados y un solo proveedor por cliente, la red comercial es necesariamente un conjunto de estrellas dirigidas hacia los vendedores, además de nodos aislados. Su forma general está restringida por las reglas; los tamaños de las estrellas y su desigualdad son resultados del modelo.

**Límite de interpretación.** Diez vendedores por simulación permiten comparar concentración, pero no sostienen una clasificación convincente de la distribución como ley de potencia. No se ajustarán distribuciones scale-free como resultado principal de esta versión, ni se juntarán vendedores de distintas simulaciones para presentar una supuesta red única. Tampoco se inferirá una cola pesada únicamente a partir de desigualdad o de un gráfico log–log. La clasificación distributiva requeriría un experimento posterior diseñado para ese propósito [3].

## 2. Entidades, variables y escala

Hay N personas con identificadores enteros estables. Al inicio se seleccionan S vendedores uniformemente, sin reemplazo, entre las N personas. Las N − S restantes son consumidores potenciales. Los roles son excluyentes y no cambian. Todos los vendedores están activos desde el período cero y comienzan con cero clientes.

| Entidad | Variable | Definición y estado inicial |
|---|---|---|
| Persona | `agent_id`, `role` | Identificador y rol fijo: `seller` o `consumer`. |
| Persona | `neighbors` | Contactos de la red social fija. |
| Consumidor i | `known_sellers`, K_i | Conjunto de vendedores de quienes recibió al menos un mensaje; inicialmente vacío. |
| Consumidor i | `aware` | Verdadero si K_i no está vacío; inicialmente falso. |
| Consumidor i | `adopted` | Ha realizado su única compra; inicialmente falso. |
| Consumidor i | `seller_id` | Vendedor seleccionado; inicialmente nulo. |
| Consumidor i | `adoption_period` | Período de compra; inicialmente nulo. |
| Vendedor j | `customer_count`, n_j | Total de clientes adquiridos hasta el cierre del período anterior; inicialmente cero. |

Una compra crea un vínculo permanente. No hay recompra, abandono, cambio de vendedor, entrada de nuevos vendedores ni restricciones de capacidad. Estos supuestos permiten estudiar adquisición y asignación con pocas reglas. Las cantidades no representan ingresos monetarios ni ventas recurrentes.

Un paso es un **período abstracto**, sin equivalencia automática con un mes. El horizonte base es T = 60; se guardan el estado inicial t = 0 y los cierres t = 1, …, T.

## 3. Red social e inicialización

1. Generar un grafo Watts–Strogatz con N nodos, grado inicial par k y probabilidad de reconexión p_WS. Usar una implementación documentada; evitar bucles y enlaces duplicados.
2. Conservar el grafo obtenido aunque tenga varios componentes. No repetir la generación hasta obtener una red visualmente conveniente. Registrar conectividad y tamaño del mayor componente.
3. Seleccionar los S vendedores y guardar sus identificadores. Su ubicación se reutiliza en los cuatro escenarios de esa repetición.
4. Inicializar consumidores desinformados, K_i vacío y cero vínculos comerciales. Ser vecino de un vendedor no implica conocer su oferta antes de recibir un mensaje.
5. Preparar las realizaciones aleatorias comunes descritas en la sección 8.

La red social se mantiene exactamente igual durante toda la ejecución. Verificar y guardar N, número de enlaces, grado medio, agrupamiento medio local —nodos con grado menor que dos contribuyen cero—, número de componentes, proporción del mayor componente y distancia media dentro de ese componente. Comparar con diez grafos aleatorios G(N,M) de igual número de nodos y enlaces por configuración social, con semillas registradas. Calcular las mismas medidas en ellos.

El diagnóstico small-world se apoya en agrupamiento elevado y caminos relativamente cortos frente a referencias adecuadas [2]. No se aplicará la etiqueta automáticamente. Si los componentes difieren mucho en tamaño entre la red y sus referencias, las distancias no son directamente comparables; reportar esta limitación. En el artículo, mostrar los diagnósticos y su variación entre realizaciones. Las redes de control con p_WS = 0 o 1 no se denominarán automáticamente small-world.

## 4. Reglas de comunicación, compra y elección

### 4.1 Comunicación y memoria

En cada período, los emisores elegibles son todos los vendedores y los consumidores que ya habían comprado al cierre del período anterior.

- Cada vendedor intenta comunicar su propia oferta a cada vecino que todavía no ha comprado, con probabilidad q_s por contacto y período.
- Cada cliente intenta recomendar a su vendedor a cada vecino consumidor que todavía no ha comprado, con probabilidad q_r por contacto y período.
- Un consumidor informado que aún no ha comprado no transmite mensajes.
- Los mensajes siempre recorren un enlace social. No hay visibilidad externa.
- Cada mensaje identifica un único vendedor. El receptor incorpora ese identificador a K_i; las repeticiones no duplican alternativas.
- Los vendedores conocidos se recuerdan permanentemente. Varias recomendaciones del mismo vendedor no aumentan directamente su peso de elección.
- Todos los clientes tienen la misma probabilidad de recomendar. No se modela satisfacción ni se presupone que recomendar demuestra satisfacción.

Un vendedor puede llegar a personas lejanas mediante cadenas sucesivas de clientes; cada comunicación individual sigue siendo local. El conjunto K_i contiene solo vendedores efectivamente presentados mediante mensajes, no todos los vendedores a dos pasos ni todos los que existen en el mercado.

### 4.2 Decisión de compra

Después de recibir todos los mensajes del período, cada consumidor que no haya comprado y tenga K_i no vacío realiza una compra con probabilidad a. Si no compra, puede intentarlo en el período siguiente. Esta probabilidad es idéntica entre personas y escenarios; no depende del vendedor, de su éxito, del número de exposiciones ni del tamaño de K_i.

La elección de un vendedor ocurre únicamente después de que la compra haya sido decidida. Si K_i está vacío no hay compra. Esta simplificación aísla la asignación de clientes y evita introducir coeficientes de necesidad, confianza o satisfacción sin una función central en el estudio.

### 4.3 Proximidad y éxito acumulado

Para un consumidor i y vendedor conocido j:

\[
h_{ij}=\begin{cases}1,&\text{si existe un enlace social directo entre i y j;}\\0,&\text{en otro caso.}\end{cases}
\]

La proximidad representa la existencia de una relación directa, no una medición de confianza psicológica. Un vendedor no conectado directamente puede ser conocido por recomendación, en cuyo caso h_ij = 0.

El éxito acumulado es n_j(t−1), número de clientes al cierre anterior. Se supone que, cuando la regla lo utiliza, el comprador puede observar esa señal para los vendedores de su conjunto K_i. No conoce por ello a vendedores fuera de K_i. Esta observabilidad perfecta es un supuesto teórico, no un hecho empírico sobre mercados reales.

### 4.4 Regla única de elección

Para j en K_i, definir:

\[
w_{ij}(t)=\exp(\alpha h_{ij})\,[n_j(t-1)+1]^{\beta},
\qquad
P_i(j,t)=\frac{w_{ij}(t)}{\sum_{\ell\in K_i}w_{i\ell}(t)}.
\]

El término +1 permite elegir vendedores sin clientes. Ordenar K_i por identificador antes de realizar el sorteo categórico. Si solo hay un vendedor conocido, su probabilidad es uno en cualquier escenario. Para estabilidad numérica puede calcularse `log_weight = alpha*h + beta*log1p(n)` y normalizar exponenciales después de restar el máximo.

| Escenario | Nombre | α | β | Regla |
|---|---|---:|---:|---|
| A | Aleatorio | 0 | 0 | Probabilidades iguales dentro de K_i. |
| B | Proximidad | ln(2) | 0 | Un vendedor conectado directamente tiene el doble de peso que uno indirecto. |
| C | Éxito acumulado | 0 | 1 | El peso es proporcional a clientes previos + 1. |
| D | Combinado | ln(2) | 1 | Multiplica la ventaja de proximidad por la de éxito acumulado. |

No cambia ninguna otra regla entre escenarios. No se añade calidad del servicio únicamente al escenario combinado.

**Ejemplo para verificar la implementación.** Un comprador conoce a dos vendedores. El primero es contacto directo y tiene cero clientes; el segundo no es contacto directo y tiene tres clientes. Las probabilidades respectivas deben ser: A = (1/2, 1/2); B = (2/3, 1/3); C = (1/5, 4/5); D = (1/3, 2/3).

### 4.5 Qué compara realmente el experimento

El escenario A elimina la preferencia explícita por éxito dentro del conjunto conocido, pero no elimina toda ventaja acumulativa: un vendedor con más clientes puede recibir más recomendaciones y aparecer en más conjuntos de elección. Los contrastes C−A y D−B miden cuánto añade la preferencia explícita sobre ese proceso común de difusión. No deben describirse como una comparación entre ausencia total y presencia total de ventaja acumulativa.

Con estas reglas, conocer al menos un vendedor basta para intentar comprar; la identidad del vendedor elegido no cambia la probabilidad de compra o de recomendación. Por tanto, con realizaciones aleatorias comunes, **los tiempos de conocimiento y compra deben coincidir exactamente entre los cuatro escenarios**. Lo que cambia es el vendedor recomendado y elegido. Esta igualdad es una consecuencia verificable del diseño, no un resultado sustantivo inesperado.

La difusión puede cambiar al variar la red social, q_s, q_r o a. Para atribuir diferencias de adopción a las reglas de elección sería necesario introducir otro mecanismo y documentarlo en una versión posterior.

## 5. Secuencia temporal y pseudocódigo

La actualización es sincrónica. Todas las elecciones del período usan n_j(t−1); ningún comprador se beneficia de ser procesado antes dentro del mismo período. Los nuevos clientes comienzan a recomendar en t+1.

```text
Inicializar red, roles, estados y tablas aleatorias comunes.
Registrar período 0.
Para cada período t = 1, ..., T:
    Congelar los clientes y conteos de vendedores al cierre de t-1.
    Generar mensajes usando solo los emisores activos al cierre de t-1.
    Entregar todos los mensajes y actualizar los conjuntos K_i.
    Para cada consumidor todavía sin compra, en orden de identificador:
        Si K_i está vacío: continuar.
        Si el sorteo de compra U_buy[t,i] es menor que a:
            Calcular pesos con K_i y conteos congelados de t-1.
            Elegir vendedor usando U_choice[t,i].
            Guardar la compra en una lista temporal.
    Aplicar simultáneamente todas las compras de la lista temporal.
    Crear los enlaces, actualizar conteos y registrar resultados.
    Comprobar invariantes de población, enlaces y probabilidades.
```

Siempre se completa el horizonte T, incluso si ya no aparecen compras. Un período sin adopciones no prueba que la difusión haya terminado. Cuando todos los consumidores han comprado, se siguen registrando estados constantes hasta T.

## 6. Parámetros base y su condición

Los valores siguientes son supuestos para el piloto; no proceden de calibración empírica. Las referencias metodológicas justifican conceptos y procedimientos, no estos números.

| Parámetro | Símbolo / clave | Base | Justificación operativa |
|---|---|---:|---|
| Población total | `N` | 500 | Tamaño manejable para un primer modelo. |
| Vendedores | `S` | 10 | Permite estudiar reparto desigual; deja 490 consumidores. |
| Vecinos iniciales | `k` | 6 | Grado par, red social relativamente dispersa. |
| Reconexión social | `p_WS` | 0.10 | Candidato a diagnosticar; no garantía de small-world. |
| Comunicación de vendedor por contacto y período | `q_s` | 0.25 | Mantiene una fuente inicial de difusión. |
| Recomendación de cliente por contacto y período | `q_r` | 0.20 | Permite transmisión sucesiva por clientes. |
| Compra por consumidor informado y período | `a` | 0.10 | Separa conocimiento y adquisición. |
| Horizonte | `T` | 60 | Permite observar trayectorias y posible saturación. |
| Ventaja directa cuando está activa | `alpha` | ln(2) | Peso doble respecto a un vendedor indirecto. |
| Preferencia por éxito cuando está activa | `beta` | 1 | Preferencia lineal en clientes + 1. |
| Clientes iniciales | `seed_customers` | 0 | Todos los vendedores parten en igualdad comercial. |
| Visibilidad externa | `external_visibility` | 0 | Información restringida a comunicación social. |

Restricciones: N > S ≥ 2; k par y 0 < k < N; probabilidades entre cero y uno; α, β ≥ 0; T entero positivo. No incluir capacidades, ingresos, calidad, confianza heterogénea ni entrada temprana en esta versión.

## 7. Indicadores y salidas

### 7.1 Resultados principales

Sea C(t) = Σ_j n_j(t) y S el número total de vendedores, incluidos quienes tienen cero clientes.

- **Concentración principal:** Gini de clientes entre los S vendedores:

\[
G(t)=\frac{\sum_{j=1}^{S}\sum_{\ell=1}^{S}|n_j(t)-n_\ell(t)|}{2S\sum_{j=1}^{S}n_j(t)}.
\]

- **Concentración complementaria:** participación del vendedor mayor, `max(n_j)/C(t)`.
- **Cobertura:** `C(t)/(N−S)`; el denominador excluye vendedores.
- **Conocimiento de la oferta:** consumidores con K_i no vacío, dividido por N−S; incluye a quienes ya compraron.
- **Oportunidad efectiva de elegir:** proporción de compras con al menos dos alternativas y distribución de `choice_set_size` al comprar.
- **Composición local:** proporción de compras dirigidas a un vendedor conectado directamente con el comprador. Es un vínculo local, no una medida de agrupamiento triangular comercial.

Si C(t) = 0, registrar Gini y participaciones como `NA` con estado `no_adoption`, no como cero. El cero debe representar igualdad cuando sí existen clientes. Si no hubo compras, también es `NA` la proporción de elecciones con varias alternativas.

Con diez vendedores, el top 10% equivale al vendedor mayor; no se tratarán como dos indicadores distintos. En sensibilidad con distinto S, añadir `G_normalized = G*S/(S−1)` y `largest_share_normalized = (largest_share−1/S)/(1−1/S)` para reconocer que sus límites dependen del número de vendedores. Reportar también los valores originales y S.

### 7.2 Resultados que no constituyen pruebas independientes

- Los enlaces comerciales equivalen al número de compradores: no son una segunda medida independiente de crecimiento.
- El agrupamiento triangular comercial es cero por construcción. Los componentes y caminos de las estrellas no prueban comunidades comerciales emergentes.
- No se estiman ingresos. Multiplicar todos los clientes por una comisión idéntica reproduciría mecánicamente su desigualdad.
- La correlación entre clientes previos y clientes nuevos es descriptiva. La regla ya incorpora una preferencia en C y D; esa correlación no demuestra por sí sola un mecanismo descubierto ni evidencia causal del mundo real.

### 7.3 Archivos requeridos por la implementación

| Archivo | Unidad de registro | Campos mínimos |
|---|---|---|
| `experiment_manifest.csv` | Ejecución | `run_id`, `phase`, `config_id`, `random_block_id`, `replicate_id`, `scenario`, parámetros, semillas, `source_run_id` si aplica, versión de modelo, versión de código y software. |
| `agents.csv` | Persona por repetición/configuración | `config_id`, `replicate_id`, `agent_id`, `role`, grado social. |
| `social_edges.csv` | Enlace social por repetición/configuración | `config_id`, `replicate_id`, `source_id`, `target_id`; una fila con source < target. |
| `social_diagnostics.csv` | Red social o referencia | Identificadores, semilla, tipo de red y métricas de la sección 3. |
| `system_timeseries.csv` | Período por ejecución | `run_id`, `period`, informados, compradores, compras nuevas, enlaces, Gini, cuota mayor, cobertura y estado de métricas. |
| `seller_timeseries.csv` | Vendedor y período por ejecución | `run_id`, `period`, `seller_id`, clientes previos, clientes nuevos, clientes totales, número de conjuntos de compra en los que aparece. |
| `commercial_edges.csv` | Compra única | `run_id`, `consumer_id`, `seller_id`, `adoption_period`, `choice_set_size`, vínculo social directo sí/no. |
| `choice_candidates.csv` | Alternativa en cada compra | `run_id`, `period`, `consumer_id`, `candidate_seller_id`, clientes previos, h_ij, peso, probabilidad, elegido sí/no. |
| `verification_log.csv` | Prueba | Identificador, configuración, resultado esperado, observado, aprobado, error y corrección. |

No es necesario exportar todos los mensajes para el experimento principal. Para depuración de redes pequeñas puede activarse un registro de mensajes. Los candidatos de compra permiten comprobar oportunidades de elección y distinguir disponibilidad de preferencia. Una recomendación no se exportará como si fuera una compra adicional.

## 8. Diseño experimental y reproducibilidad

### 8.1 Emparejamiento

Cada repetición r genera una red, una ubicación de vendedores y realizaciones aleatorias comunes para A, B, C y D. Las repeticiones son independientes entre sí. El contraste se hace dentro de cada repetición.

Usar fuentes aleatorias separadas para red, selección de roles, comunicación, compra y elección. Registrar cinco semillas por repetición. Una asignación reproducible propuesta es `seed_stage = B + 10*r + offset`, con offsets 0 a 4 en ese orden. Usar B = 100000 para piloto, B = 200000 para principal y bloques nuevos de amplitud 100000 a partir de B = 300000 cuando se necesiten nuevas realizaciones de sensibilidad; r comienza en 1 y debe ser menor que 10000 por bloque. Registrar el generador aleatorio y las versiones de software. Las referencias aleatorias de red usan otro rango de semillas, explícito en el manifiesto.

Un bloque identifica las realizaciones aleatorias compartidas, no necesariamente una única configuración. Las variaciones de β, q_r o a pueden usar las primeras 30 repeticiones del bloque principal, conservando exactamente la red, roles y tablas uniformes. Para cambios de p_WS o S se generan los objetos correspondientes y se documenta el bloque utilizado. Cuando solo varía β, reutilizar las salidas A y B ya obtenidas en ese mismo bloque y repetición; no duplicarlas como observaciones nuevas. Cada manifiesto debe identificar `random_block_id` y, si hay reutilización, `source_run_id`.

Para asegurar el emparejamiento, generar y reutilizar:

- `U_message[t,u,v]` para cada orientación de cada enlace social, en orden fijo (período, emisor, receptor), independientemente de si el emisor llegará a estar activo.
- `U_buy[t,i]` y `U_choice[t,i]` para cada consumidor y período, en orden fijo, independientemente de si el sorteo se utiliza.

Todos son uniformes en [0,1). El sorteo de comunicación se compara con q_s si el emisor es vendedor y q_r si es cliente activo. Las tablas son comunes entre escenarios. No basta con reiniciar una semilla global si distintas ramas del programa consumen números en órdenes diferentes. Las tablas pueden regenerarse desde sus semillas; no es obligatorio almacenarlas si el orden y el generador quedan completamente documentados.

### 8.2 Fases

| Fase | Diseño | Uso |
|---|---|---|
| Verificación | Redes pequeñas y casos construidos | Revisar reglas e invariantes, sin interpretar hipótesis. |
| Piloto | 20 repeticiones × 4 escenarios = 80 ejecuciones | Evaluar errores, tiempos, saturación, disponibilidad de alternativas y variabilidad. |
| Principal | 100 repeticiones nuevas × 4 escenarios = 400 ejecuciones | Comparar mecanismos con configuración y código congelados. |
| Sensibilidad | Configuraciones seleccionadas y documentadas | Identificar condiciones en que las conclusiones cambian. |

El piloto no se incorpora silenciosamente al conjunto principal. Si se cambia una regla, se actualiza la versión y se repiten las verificaciones pertinentes. Cien repeticiones es una base de trabajo heredada de la guía, no una garantía universal de precisión. Antes del experimento principal, utilizar la dispersión del piloto para fijar el número final o una regla de ampliación basada en precisión, nunca en obtener significación estadística.

**Revisión del piloto:** comprobar que existen suficientes compras con dos o más candidatos para que las reglas puedan compararse; mostrar cuándo la adopción alcanza 50% y 90%, si ocurre; observar si los contrastes de concentración varían mucho entre repeticiones. Si casi todas las compras tienen una alternativa, documentarlo y revisar la disponibilidad de opciones antes de fijar el diseño. No modificar parámetros para forzar una mayor concentración en C o D.

### 8.3 Sensibilidad acotada

Para mantener el trabajo manejable, proponer inicialmente las siguientes variaciones, una dimensión a la vez respecto a la base:

| Dimensión | Base | Alternativas |
|---|---:|---|
| Reconexión social p_WS | 0.10 | 0 y 1, como controles estructurales |
| Recomendación q_r | 0.20 | 0.05 y 0.50 |
| Intensidad de éxito β en C y D | 1 | 0.5 y 2 |
| Número de vendedores S | 10 | 5 y 20 |
| Probabilidad de compra a | 0.10 | 0.05 y 0.20 |

Comenzar con 30 repeticiones emparejadas por configuración adicional. Cuando solo cambia β, reutilizar A y B de las mismas repeticiones/configuraciones porque sus reglas no han cambiado; no presentarlos como datos independientes nuevos. Dejar identificada la reutilización en el manifiesto. Ampliar las configuraciones donde la incertidumbre impida distinguir patrones relevantes. Esta exploración no sustituye un análisis global de todas las interacciones; describirla como sensibilidad acotada.

Además, verificar T = 120 en un subconjunto emparejado predefinido para establecer si las conclusiones a T = 60 dependen del horizonte. Para esta comparación, las realizaciones aleatorias de los primeros 60 períodos deben coincidir exactamente. Los tamaños de corrida de sensibilidad son provisionales y se cierran después de medir el costo del piloto.

### 8.4 Comparación estadística

Resultado principal: Gini al período T. Calcular por repetición `C−A`, `D−B`, `B−A` y la interacción `(D−B)−(C−A)`. Los dos primeros contrastes evalúan la preferencia por éxito bajo distintas condiciones de proximidad. Mostrar medias, medianas y dispersión; presentar intervalos del 95% para las diferencias mediante remuestreo de repeticiones completas, preservando juntos sus cuatro escenarios, con semilla registrada.

Los intervalos describen incertidumbre Monte Carlo bajo los supuestos del modelo, no incertidumbre sobre una población real calibrada. No usar cada agente ni cada período como una repetición independiente. Si alguna ejecución termina sin adopción, reportar su frecuencia y usar comparaciones de Gini solo en repeticiones donde esté definido, indicando ese condicionamiento. No convertir estos casos en desigualdad cero.

Las curvas temporales y los resultados por vendedor complementan el análisis. No se necesita comenzar por pruebas de significación para cada variable. Cualquier análisis adicional debe identificarse como exploratorio.

## 9. Verificación y criterio para iniciar el experimento principal

Las siguientes son pruebas del código futuro. No se presentan como pruebas ya ejecutadas.

| Prueba | Condición | Resultado esperado |
|---|---|---|
| Red fija | Comparar aristas antes y después | Identidad y número de aristas sin cambios. |
| Roles y enlaces | Inspeccionar todas las compras | Consumidor → vendedor, sin bucles ni duplicados; grado de salida de consumidor ≤ 1. |
| Contabilidad | Cada cierre | Compradores = enlaces = suma de clientes por vendedor ≤ N−S. |
| Sin comunicación | q_s = q_r = 0, sin informados iniciales | Cero informados y cero compras. |
| Sin compra | a = 0 | Puede haber información de vendedores; cero compras y cero recomendaciones de clientes. |
| Sin referidos | q_r = 0 | Solo los vecinos consumidores de vendedores pueden llegar a informarse. |
| Un candidato | K_i contiene uno | Elección de ese vendedor con probabilidad 1. |
| Probabilidades | Cada compra | Pesos positivos, probabilidades en [0,1], suma 1 con tolerancia 10⁻¹². |
| Ejemplo numérico | Caso de la sección 4.4 | Reproducir exactamente las cuatro parejas de probabilidades, salvo redondeo. |
| Igual éxito | Todos los candidatos tienen el mismo n_j | C coincide con A y D con B para ese conjunto de elección. |
| Parámetros nulos | α = β = 0 | Todos los escenarios reducidos a esa regla producen la misma elección con el mismo sorteo. |
| Alternativas válidas | Inspeccionar compra y candidatos | Vendedor elegido pertenece a K_i y fue conocido mediante un mensaje válido. |
| Sin ventaja por orden | Permutar orden de evaluación | Compras iguales con sorteos identificados por agente; conteos se actualizan al cierre. |
| Retraso de referidos | Cadena vendedor–consumidor–consumidor con q_s=q_r=a=1 | Primer consumidor compra en t=1; segundo en t=2. |
| Acoplamiento de difusión | Misma red y tablas aleatorias en A–D | Mismos informados y compradores por identidad y período; vendedores elegidos pueden diferir. |
| Reproducibilidad | Reejecutar parámetros, semillas y versión | Mismos datos, excluyendo metadatos como hora de ejecución. |
| Saturación | Todos los consumidores ya compraron | Cero adquisiciones y enlaces nuevos; estados posteriores constantes. |

La revisión conceptual de los profesores debe confirmar que las reglas corresponden a la pregunta y que los resultados se interpretarán bajo sus supuestos. No se denomina validación empírica. Reproducir un patrón esperado tampoco valida el modelo por sí solo.

**Se inicia el experimento principal cuando:** las pruebas pasan, los diagnósticos sociales están disponibles, el piloto ofrece una comparación interpretable y se han congelado reglas, parámetros, semillas, salidas y versión de código. Si un patrón no aparece, se registra; no es motivo automático para descartar ejecuciones.

## 10. Material para análisis y escritura

El paquete de simulación debe contener código, especificación, configuración, resultados crudos, tablas de análisis, bitácora y README con instrucciones reproducibles. Guardar por separado piloto, principal y sensibilidad. No sobrescribir resultados cuando cambie el modelo.

El estudiante puede comenzar el análisis con cuatro productos:

1. Tabla de diagnósticos de la red social y verificación del modelo.
2. Curvas de conocimiento y adopción, explicando la igualdad entre escenarios que exige esta versión.
3. Comparación emparejada de concentración y reparto de clientes, incluyendo ceros y oportunidades reales de elección.
4. Tabla de sensibilidad que identifique patrones estables, cambios de signo e incertidumbre.

Las visualizaciones comerciales usarán las mismas posiciones de personas para los cuatro escenarios de una misma repetición. Elegir de antemano una repetición ilustrativa o explicar una regla transparente de selección; una imagen no sustituye el conjunto de resultados.

Para redactar métodos, organizar la descripción según los siete elementos de ODD: propósito y patrones; entidades, estados y escalas; procesos y secuencia; conceptos de diseño; inicialización; datos de entrada; y submodelos [1]. Este documento suministra las reglas, pero la versión final de ODD debe corresponder al código efectivamente utilizado. En datos de entrada se declarará la ausencia de datos empíricos de calibración.

Frases compatibles con el alcance del manuscrito:

- “Under the modeled assumptions, customer allocation became more concentrated when…”
- “The simulations compare explicit success-based choice with random choice among known sellers.”
- “The model does not estimate concentration in a specific empirical market.”

La dirección de los resultados se completa después del análisis. No afirmar que se generó una red scale-free, que se reprodujo una empresa MLM real o que se validó una teoría mediante ajuste a datos reales.

## 11. Registro de cambios respecto a la guía inicial

| Cambio para v0.1 | Razón | Trabajo adicional y efecto en viabilidad | Estado |
|---|---|---|---|
| Título y objetivo centrados en concentración | Evitar anticipar una ley de potencia con diez vendedores | Revisar encuadre y expectativas; reduce riesgo de ejecución | Título provisional; alcance operativo de esta versión |
| Roles separados y una adquisición | Definir exactamente qué significa un enlace | Implementación más simple; limita topologías posibles | Adoptado para el modelo mínimo |
| Regla común con proximidad binaria y clientes + 1 | Aislar dos mecanismos y permitir verificaciones analíticas | Sustituir reglas ambiguas; reduce variables | Adoptado para el piloto |
| Éxito acumulado observable en el conjunto conocido | Dar significado preciso a la señal utilizada | Documentar supuesto; no requiere datos reales | Supuesto teórico revisable |
| Compra homogénea y recomendación sin satisfacción | Aislar asignación y evitar mecanismos accesorios | Menos parámetros; implica difusión idéntica entre escenarios emparejados | Adoptado para v0.1 |
| Reconocer ventaja por referidos también en A | Evitar un contraste teórico mal definido | Ajustar interpretación, sin complejidad nueva | Necesario bajo las reglas propuestas |
| Omitir inferencia scale-free, agrupamiento comercial e ingresos | Son insuficientes, impuestos o redundantes en este diseño | Reducir análisis y figuras; mejora viabilidad | Fuera del experimento principal v0.1 |
| Actualización sincrónica y números aleatorios comunes | Evitar ventajas artificiales por orden y mejorar comparación | Requiere preparar sorteos e invariantes | Requisito de implementación |
| Piloto separado y comparación emparejada | Distinguir depuración, experimento e incertidumbre | 80 ejecuciones piloto y 400 principales como base | Cantidades principales revisables por precisión |
| Entrada escalonada y visibilidad externa diferidas | Mantener una pregunta central y ejecución comprensible | No requieren trabajo en esta versión | Extensiones opcionales posteriores |

El piloto debe resolver la disponibilidad efectiva de alternativas, el horizonte y la precisión necesaria. Cualquier modificación posterior debe registrar qué cambió, por qué, qué pruebas se repitieron y qué ejecuciones pertenecen a cada versión. La simplificación no cambia la meta de completar un manuscrito y paquete reproducible antes del 15 de diciembre de 2026.

## 12. Referencias metodológicas verificadas

[1] Grimm, V., et al. (2020). The ODD Protocol for Describing Agent-Based and Other Simulation Models: A Second Update to Improve Clarity, Replication, and Structural Realism. *Journal of Artificial Societies and Social Simulation, 23*(2), 7. https://doi.org/10.18564/jasss.4259 — Se utiliza para estructurar la documentación, no para atribuir valores empíricos a los parámetros.

[2] Watts, D. J., & Strogatz, S. H. (1998). Collective dynamics of ‘small-world’ networks. *Nature, 393*, 440–442. https://doi.org/10.1038/30918 — Fundamenta la distinción entre agrupamiento y longitud de caminos en redes small-world.

[3] Clauset, A., Shalizi, C. R., & Newman, M. E. J. (2009). Power-law distributions in empirical data. *SIAM Review, 51*(4), 661–703. https://doi.org/10.1137/070710111 — Fundamenta la cautela al clasificar distribuciones y la necesidad de evaluar alternativas. Versión de los autores: https://arxiv.org/abs/0706.1062.

**Documento base del proyecto:** «Indications - Article 2 - MLM - ABM SW SF», proporcionado por Sebastián. Las reglas numéricas específicas de esta versión son propuestas de diseño del equipo y no resultados extraídos de esas referencias.
