# Article 2 — Estado y organización

**Actualización:** 25 de septiembre de 2026. **Modelo:** v0.1.0. **Especificación:** v0.1.

Implementación y verificación completas: 33 pruebas aprobadas, cuatro ejecuciones técnicas a tamaño base y auditoría de exportaciones aprobada. El piloto, el experimento principal y la sensibilidad siguen pendientes.

## Carpetas

| Carpeta | Uso |
|---|---|
| [00_Coordinacion](https://drive.google.com/drive/folders/134hwPnP8Y3RAoVscYOI_J4bdpGgm-J6I) | Estado del proyecto, índice y decisiones. |
| [01_Modelo_y_especificacion](https://drive.google.com/drive/folders/1BIPrmQVCMZvA6WLDSFfU8WPJWBBrG8GA) | Guía original, especificación mínima y decisiones de implementación. |
| [02_Codigo](https://drive.google.com/drive/folders/1gewmyEN60dUU5QGjQkI0AZRH6dXnDzpT) | Código Python, pruebas, configuración y README en un ZIP versionado. |
| [03_Verificacion](https://drive.google.com/drive/folders/1FJ2OhlSxbcUqcmcEQrq9wxJL1dRDNV8p) | Informe y evidencia técnica; separados de resultados científicos. |
| [04_Datos_crudos](https://drive.google.com/drive/folders/165C5DguNf0viJXjauGqqD3ewNybpHn3F) | Carpeta matriz de datos de experimentos. |
| [04_Datos_crudos/01_Piloto](https://drive.google.com/drive/folders/15v4DlsyJGuTIIUITo-_ZSzxR6Soblsww) | Reservada para las 80 ejecuciones del piloto; todavía pendiente. |
| [04_Datos_crudos/02_Principal](https://drive.google.com/drive/folders/1TSd_tZ8d_y55q-gcLjLjOL3_NX4fsLf0) | Reservada para las 400 ejecuciones principales; todavía pendiente. |
| [04_Datos_crudos/03_Sensibilidad](https://drive.google.com/drive/folders/1INtyXe8RIoBZ8umN1hNnkRNFhRYMUmTO) | Reservada para las configuraciones de sensibilidad. |
| [05_Analisis](https://drive.google.com/drive/folders/1YFZZyDiLJxwvSd5O5cI7Aku-VruvGLCw) | Scripts y tablas de análisis posteriores. |
| [06_Figuras_y_tablas](https://drive.google.com/drive/folders/12S2DamDXGhuW5JyqSWVwd4yHsXvwdrLT) | Figuras y tablas finales del manuscrito. |
| [07_Manuscrito](https://drive.google.com/drive/folders/1BoGy8WPc35Q-xMEmSWwALZDptB_BfB_J) | Plantilla existente y versiones futuras del artículo. |

## Archivos existentes

- La [guía original](https://docs.google.com/document/d/11RcFFITB_OI_sAeMUKFG2lftpkFGd4uMaWBsIDuF96M/edit?usp=drivesdk) está en `01_Modelo_y_especificacion`.
- La [plantilla del manuscrito](https://docs.google.com/document/d/10KSNR3SwoStpuCZRzycd1W5VhEmLiY1QGkGaeytsf8Y/edit?usp=drivesdk) está en `07_Manuscrito`.
- Ambos documentos conservan sus identificadores y enlaces. Su contenido no fue modificado.

## Convenciones

- Conservar la guía original como antecedente. Para programar esta versión, aplicar la especificación mínima v0.1 y las decisiones de implementación v0.1.0.
- Usar nombres de versión y separar siempre verificación, piloto, principal y sensibilidad.
- El ZIP de código y el ZIP de verificación comparten la carpeta raíz `article2_model_v0.1.0`; extraerlos en la misma ubicación permite reunir programa y evidencia.
- Conservar resultados crudos y semillas. Guardar nuevas ejecuciones en carpetas nuevas y no sobrescribir versiones.
- Registrar cualquier cambio de reglas antes de generar una nueva serie de resultados.
- Las carpetas de análisis y figuras son espacios preparados; esta entrega no contiene resultados del piloto ni del experimento principal.

## Próxima actividad

Ejecutar el piloto de 20 repeticiones emparejadas (80 ejecuciones) con bloque aleatorio 100000. Revisar alternativas disponibles, saturación y variabilidad de los contrastes antes de cerrar el experimento principal. Los comandos están en el README del paquete de código.

