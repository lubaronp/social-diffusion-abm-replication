"""Run the verification suite and write a human-readable audit trail."""
import argparse
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import platform
import unittest

from article2 import __version__, SPEC_VERSION
from article2.experiment import source_fingerprint, write_csv


class AuditResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.audit=[]

    def row(self,test,status,observed):
        self.audit.append({"test_id":test.id(),"expected":test.shortDescription() or test.id(),
                           "observed":observed,"passed":int(status=="passed"),"status":status})

    def addSuccess(self,test):
        super().addSuccess(test)
        self.row(test,"passed","Todas las aserciones se cumplieron.")

    def addFailure(self,test,err):
        super().addFailure(test,err)
        self.row(test,"failed",self._exc_info_to_string(err,test))

    def addError(self,test,err):
        super().addError(test,err)
        self.row(test,"error",self._exc_info_to_string(err,test))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--out",type=Path,required=True,help="New directory; cannot overwrite")
    args=parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=False)
    root=Path(__file__).resolve().parent
    suite=unittest.defaultTestLoader.discover(str(root/"tests"),top_level_dir=str(root))
    stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=AuditResult).run(suite)
    log=stream.getvalue()
    print(log)
    (args.out/"test_output.txt").write_text(log,encoding="utf-8")
    write_csv(args.out/"verification_log.csv",["test_id","expected","observed","passed","status"],result.audit)
    summary={"executed_utc":datetime.now(timezone.utc).isoformat(),"model_version":__version__,
             "spec_version":SPEC_VERSION,"python_version":platform.python_version(),
             "code_sha256":source_fingerprint(),"tests_run":result.testsRun,
             "failures":len(result.failures),"errors":len(result.errors),"skipped":len(result.skipped),
             "successful":result.wasSuccessful(),"phase":"verification","pilot_executed":False}
    (args.out/"verification_summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__=="__main__":
    main()
