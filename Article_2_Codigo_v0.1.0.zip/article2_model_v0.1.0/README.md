# Article 2 — Modelo verificado v0.1.0

Modelo basado en agentes para estudiar concentración de clientes bajo difusión social y elección de vendedores. Implementa la especificación 0.1 de 25 de septiembre de 2026.

**Estado:** código implementado y verificado; piloto pendiente. No se calibró con datos reales. Los datos incluidos bajo `verification/` son controles técnicos y no constituyen el experimento del artículo.

## Entorno

- Implementación comprobada en Python 3.12.14.
- Solo biblioteca estándar: no requiere `pip install`, NetLogo, NetworkX, pandas ni NumPy.
- Para reproducir exactamente los archivos, conservar versión de Python, parámetros, semillas y código. No se afirma haber comprobado otras versiones.
- Ejecutar comandos desde la carpeta que contiene este README. En sistemas que usan `python3`, sustituir `python` por `python3`.

## Archivos

| Ruta | Contenido |
|---|---|
| `article2/network.py` | Red Watts–Strogatz, referencias G(N,M), componentes, agrupamiento y caminos. |
| `article2/model.py` | Reglas de mensajes, compra, selección, actualización y métricas. |
| `article2/experiment.py` | Ejecuciones emparejadas, exportación CSV y trazabilidad. |
| `article2/__main__.py` | Entrada desde la línea de comandos. |
| `configs/base_v01.json` | Parámetros base de la especificación. |
| `configs/verification_small.json` | Configuración pequeña para depuración. |
| `tests/test_model.py` | 33 pruebas de redes, elección, dinámica y exportación. |
| `verify.py` | Ejecuta pruebas y guarda bitácora e informe JSON. |
| `audit_outputs.py` | Recalcula verificaciones desde los CSV, sin ejecutar el modelo. |
| `docs/` | Especificación, decisiones de implementación y diccionario de salidas. |
| `verification/` | Evidencia técnica de esta entrega; carpeta presente en el paquete completo o en el ZIP de verificación. |

## Repetir las pruebas

```bash
python verify.py --out verification/recheck_01
```

La carpeta de salida debe ser nueva. El programa rechaza sobrescrituras. La ejecución devuelve código de salida 0 si todas las pruebas pasan y 1 si hay fallos. Revisar `verification_log.csv`, `verification_summary.json` y `test_output.txt`.

## Repetir el control a tamaño base

```bash
python -m article2 --config configs/base_v01.json --out verification/full_size_recheck --phase verification --repetitions 1 --block 900000 --config-id base_v01 --benchmarks 10
python audit_outputs.py verification/full_size_recheck --report verification/export_audit_recheck.json
```

Esto ejecuta A–D para una única repetición de verificación, con 500 personas y 60 períodos. Los diez grafos aleatorios son referencias de la red social, no diez simulaciones comerciales adicionales.

## Ejecutar el piloto en la fase siguiente

El piloto **no se ejecutó en esta entrega**. Su comando preparado es:

```bash
python -m article2 --config configs/base_v01.json --out outputs/pilot_v01 --phase pilot --repetitions 20 --block 100000 --config-id base_v01 --benchmarks 10
python audit_outputs.py outputs/pilot_v01 --report outputs/pilot_v01_audit.json
```

Produce 20 repeticiones emparejadas, 80 ejecuciones. Antes del experimento principal, revisar alternativas de elección disponibles, saturación temporal y variabilidad de los contrastes. No ajustar parámetros buscando que una hipótesis se confirme.

El experimento principal previsto utilizará `--phase main --repetitions 100 --block 200000` y otra carpeta. No iniciarlo hasta revisar el piloto. La sensibilidad usa configuraciones separadas; la reutilización eficiente de A/B entre configuraciones de β requiere identificar las ejecuciones fuente. El ejecutor actual siempre ejecuta A–D en cada llamada; no realiza automáticamente esa reutilización.

## Lectura de resultados

1. Verificar `execution.json`: debe indicar `status=completed` y la fase correcta.
2. Usar `experiment_manifest.csv` para unir archivos mediante `run_id` y recuperar parámetros y semillas.
3. `system_timeseries.csv` guarda t=0 y los cierres t=1,…,T; `seller_timeseries.csv` incluye vendedores con cero clientes.
4. `commercial_edges.csv` contiene una fila por compra; `choice_candidates.csv` permite inspeccionar alternativas y probabilidades.
5. `NA` significa no definido. En ausencia de clientes, la concentración no se transforma en cero.
6. Los contrastes son emparejados por repetición. Cada cliente o período no constituye una repetición independiente.

La igualdad de los tiempos de conocimiento y compra entre A–D es una consecuencia de las reglas y un control de implementación. Los resultados comerciales por vendedor pueden diferir. La estructura de estrellas es impuesta por los roles y una compra por cliente; su desigualdad es endógena. Esta versión no estima ingresos ni clasifica la red comercial como scale-free.

## Cómo trabajar con Drive

- `01_Modelo_y_especificacion`: guía histórica, especificación vigente y decisiones de implementación.
- `02_Codigo`: ZIP del código con pruebas y configuración.
- `03_Verificacion`: informe y ZIP de evidencia técnica.
- `04_Datos_crudos/01_Piloto`, `02_Principal`, `03_Sensibilidad`: datos de fases futuras, en carpetas separadas por versión.
- `05_Analisis`, `06_Figuras_y_tablas`, `07_Manuscrito`: productos posteriores.
- `00_Coordinacion`: índice y estado del trabajo.

La guía histórica se conserva como antecedente; la especificación 0.1 y las decisiones de implementación rigen esta versión. Cualquier modificación de reglas requiere versión nueva, pruebas pertinentes y separación de sus datos.
